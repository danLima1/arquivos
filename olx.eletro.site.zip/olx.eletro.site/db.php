<?php
$conn = mysqli_connect(
    "localhost",  // Nome do host
    "5ianoooi",     // Nome do usuário
    "a5wbdDKjEHTHyWAt",     // Senha
    "5ianoooi"      // Nome do banco de dados
) or die("Falha na conexão: " . mysqli_connect_error());
?>
