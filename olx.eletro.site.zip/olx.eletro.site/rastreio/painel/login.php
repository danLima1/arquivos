<?php
session_start();
require_once '../config/db.php'; // O arquivo db.php deve definir e inicializar a variável $conn

// Se o usuário já estiver logado, redireciona para home.php
if (isset($_SESSION['username'])) {
    header("Location: home");
    exit;
}

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitiza os dados enviados
    $username = trim($_POST["Usuario"]);
    $password = trim($_POST["Senha"]);

    // Prepara a consulta para evitar SQL injection
    $stmt = $conn->prepare("SELECT id, username, password, isAdmin FROM usuarios WHERE username = ?");
    if (!$stmt) {
        die("Erro na preparação da consulta: " . $conn->error);
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Verifica se foi encontrado um registro
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $username;
            $_SESSION['userId'] = $user['id'];
            $_SESSION['logado'] = true;
            
            if ($user['isAdmin'] == 1) {
                $_SESSION['isAdmin'] = true;
            }
            
            header("Location: home");
            exit;
        } else {
            $error_message = "Usuário ou senha inválidos.";
        }
    } else {
        $error_message = "Usuário ou senha inválidos.";
    }
    $stmt->close();
}

// Fecha a conexão (opcional, pois a conexão será encerrada ao final do script)
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - PTK NETWORK</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container">
    <div class="row justify-content-center mt-5">
      <div class="col-md-6">
        <div class="card shadow-sm">
          <div class="card-header bg-dark text-white text-center">
            <h4>Login</h4>
          </div>
          <div class="card-body">
            <?php if($error_message): ?>
              <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error_message); ?>
              </div>
            <?php endif; ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
              <div class="mb-3">
                <label for="Usuario" class="form-label">Usuário</label>
                <input type="text" class="form-control" id="Usuario" name="Usuario" required>
              </div>
              <div class="mb-3">
                <label for="Senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="Senha" name="Senha" required>
              </div>
              <div class="d-grid">
                <button type="submit" class="btn btn-primary">Entrar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap Bundle com Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
