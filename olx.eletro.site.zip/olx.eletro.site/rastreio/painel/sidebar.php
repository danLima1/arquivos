<!-- sidebar.php -->
<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-white sidebar collapse">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="home">
          <i class="fas fa-home"></i> Home
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="rastreio">
          <i class="fas fa-plus"></i> Criar Rastreio
        </a>
      </li>
                  <li class="nav-item">
        <a class="nav-link" href="movimentacao">
          <i class="fas fa-plus"></i> Criar Movimentação
        </a>
      </li>
              <?php if (!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] != 1): ?>
            <li class="nav-item">
        <a class="nav-link" href="creditos">
          <i class="fas fa-plus"></i> Comprar Créditos
        </a>
      </li>
              <?php endif; ?>
                            <?php if (!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] == 1): ?>
            <li class="nav-item">
        <a class="nav-link" href="usuarios">
          <i class="fas fa-plus"></i> Usuários
        </a>
      </li>
              <?php endif; ?>
                                <li class="nav-item">
        <a class="nav-link" href="integracao">
          <i class="fas fa-plus"></i> Integração
        </a>
      </li>
    </ul>
  </div>
</nav>
