<?php
// Função para obter o usuário pelo ID
function getUserById($conn, $id) {
    // Usa prepared statement para evitar SQL Injection
    $stmt = mysqli_prepare($conn, "SELECT * FROM usuarios WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Verifica se encontrou o usuário
    if (mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    } else {
        return null; // Retorna null caso o usuário não seja encontrado
    }

    mysqli_stmt_close($stmt); // Fecha o statement
}
?>
