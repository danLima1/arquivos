<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["username"])) {
    header("Location: /");
    exit();
}

// Processar exclusão
if (isset($_GET["delete"])) {
    $id = (int) $_GET["delete"];

    try {
        // Preparar consulta
        if ($_SESSION["isAdmin"]) {
            $stmt = $conn->prepare("DELETE FROM rastreios WHERE id = ?");
            $stmt->bind_param("i", $id);
        } else {
            $stmt = $conn->prepare("DELETE FROM rastreios WHERE id = ? AND userId = ?");
            $stmt->bind_param("ii", $id, $_SESSION["userId"]);
        }

        // Executar consulta
        $stmt->execute();

        // Fechar stmt após uso
        $stmt->close();
        unset($stmt); // Garantir que a variável não será usada após ser fechada

        header("Location: " . $_SERVER["PHP_SELF"]);
        exit();
    } catch (Exception $e) {
        die("Erro na exclusão: " . $e->getMessage());
    }
}

$mensagem = "";
$mensagem_tipo = "";
$imagem_path = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $dados = [
            "codigo" => strtoupper(substr(trim($_POST["codigo"]), 0, 8)),
            "cliente_nome" => trim($_POST["cliente_nome"]),
            "cliente_cpf" => preg_replace("/[^0-9]/", "", $_POST["cliente_cpf"]),
            "cliente_endereco" => trim($_POST["cliente_endereco"]),
            "userId" => $_SESSION["userId"]
        ];

        // Buscar valor do rastreio
        $config = $conn->query("SELECT rastreio_valor FROM configuracoes LIMIT 1")->fetch_assoc();

        if (!$config) throw new Exception("Configuração do sistema não encontrada");

        $rastreio_valor = $config["rastreio_valor"];

        // Verificar créditos
        $stmt = $conn->prepare("SELECT isAdmin, credito FROM usuarios WHERE username = ?");
        $stmt->bind_param("s", $_SESSION["username"]);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();

        // Fechar stmt após consulta de usuário
        $stmt->close();
        unset($stmt); // Garantir que a variável não será usada após ser fechada

        if (!$result["isAdmin"] && $result["credito"] < $rastreio_valor) {
            throw new Exception("Créditos insuficientes!");
        }

        // Gerar código
        $codigo_gerado = $dados["codigo"] . strtoupper(bin2hex(random_bytes(4))) . "BR";
        $codigo_gerado = substr($codigo_gerado, 0, 14);

        // Processar imagem
        if ($_FILES["imagem"]["error"] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES["imagem"]["name"], PATHINFO_EXTENSION));

            if (!in_array($ext, ["jpg", "jpeg", "png", "gif"])) {
                throw new Exception("Formato de imagem inválido!");
            }

            $nome_imagem = uniqid() . ".jpg";
            $pasta = "../public/";

            if (!is_dir($pasta) && !mkdir($pasta, 0755, true)) {
                throw new Exception("Falha ao criar diretório para imagens");
            }

            // Processar imagem com tratamento de erros
            $origem = @imagecreatefromstring(file_get_contents($_FILES['imagem']['tmp_name']));
            if (!$origem) throw new Exception("Falha ao processar imagem");

            $destino = imagecreatetruecolor(50, 50);
            imagecopyresampled(
                $destino,
                $origem,
                0, 0,
                0, 0,
                50, 50,
                imagesx($origem),
                imagesy($origem)
            );
            imagejpeg($destino, $pasta . $nome_imagem, 85);
            $imagem_path = $nome_imagem;

            imagedestroy($origem);
            imagedestroy($destino);
        }

        // Inserir rastreio
$stmt = $conn->prepare("INSERT INTO rastreios (codigo, cliente_nome, cliente_cpf, cliente_endereco, userId, img) 
                       VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param(
    "ssssis",
    $codigo_gerado,
    $dados["cliente_nome"],
    $dados["cliente_cpf"],
    $dados["cliente_endereco"],
    $dados["userId"],
    $imagem_path
);

if (!$stmt->execute()) {
    throw new Exception("Erro ao criar rastreio: " . $stmt->error);
}

// Inserir movimentação: Seu pacote foi postado
$rastreio_id = $stmt->insert_id; // Pega o id do rastreio recém-inserido
$titulo = "Seu pacote foi postado";
$descricao = "Seu pacote foi entregue ao centro de distribuição";
$de = "Centro de Distribuição";
$para = NULL;

// Inserir movimentação na tabela 'movimentacoes'
$stmt_mov = $conn->prepare("INSERT INTO movimentacoes (rastreio_id, titulo, descricao, `de`, `para`) 
                           VALUES (?, ?, ?, ?, ?)");
$stmt_mov->bind_param("issss", $rastreio_id, $titulo, $descricao, $de, $para);

if (!$stmt_mov->execute()) {
    throw new Exception("Erro ao criar movimentação: " . $stmt_mov->error);
}

// Atualizar créditos se não for admin
if (!$result["isAdmin"]) {
    $novo_credito = $result["credito"] - $rastreio_valor;
    $stmt_update = $conn->prepare("UPDATE usuarios SET credito = ? WHERE id = ?");
    $stmt_update->bind_param("ii", $novo_credito, $dados["userId"]);
    $stmt_update->execute();

    // Fechar o stmt_update após uso
    $stmt_update->close();
    unset($stmt_update); // Garantir que a variável não será usada após ser fechada
}

// Mensagem de sucesso
$mensagem = "Rastreio e movimentação criados com sucesso!";
$mensagem_tipo = "success";

// Fechar stmt após inserção do rastreio
$stmt->close();
unset($stmt); // Garantir que a variável não será usada após ser fechada

// Fechar stmt após inserção da movimentação
$stmt_mov->close();
unset($stmt_mov); // Garantir que a variável não será usada após ser fechada


    } catch (Exception $e) {
        $mensagem = $e->getMessage();
        $mensagem_tipo = "danger";
    }
}

// Buscar rastreios
$rastreios = [];
try {
    if ($_SESSION["isAdmin"]) {
        $result = $conn->query("
            SELECT r.id, r.codigo, u.username 
            FROM rastreios r
            JOIN usuarios u ON r.userId = u.id
            ORDER BY r.id DESC
        ");
    } else {
        $stmt = $conn->prepare("
            SELECT r.id, r.codigo, u.username 
            FROM rastreios r
            JOIN usuarios u ON r.userId = u.id
            WHERE r.userId = ?
            ORDER BY r.id DESC
        ");
        $stmt->bind_param("i", $_SESSION["userId"]);
        $stmt->execute();
        $result = $stmt->get_result();
    }

    if ($result) {
        $rastreios = $result->fetch_all(MYSQLI_ASSOC);
    }

    // Fechar stmt após busca de rastreios
    if (isset($stmt)) {
        $stmt->close();
        unset($stmt); // Garantir que a variável não será usada após ser fechada
    }
} catch (Exception $e) {
    die("Erro ao buscar rastreios: " . $e->getMessage());
}
?>





<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PTK - Rastreio</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">    <style>
        body { background: #f8f9fa; }
        .table-actions { width: 100px; }
        .codigo-col { min-width: 200px; }
    </style>
</head>
<body>

<?php include "navbar.php"; ?>

<div class="container-fluid">
    <div class="row">
        <?php include "sidebar.php"; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <!-- Formulário de cadastro -->
            <div class="card shadow-sm mb-4">
                    <div class="card-header text-center bg-white">
          <img src="ptk2.png" alt="Logo" style="width: 200px; height: 140px;">
        </div>
                <div class="card-body">
                    <?php if ($mensagem): ?>
                        <div class="alert alert-<?= $mensagem_tipo ?>"><?= $mensagem ?></div>
                    <?php endif; ?>

                    <form method="post" enctype="multipart/form-data">
                                 <form action="<?php echo htmlspecialchars(
                                     $_SERVER["PHP_SELF"]
                                 ); ?>" method="post" enctype="multipart/form-data">
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="codigo" class="form-label">Código de Rastreio:</label>
                <input type="text" class="form-control" id="codigo" name="codigo" placeholder="Digite parte do código (ex: OLX123456)" oninput="this.value = this.value.toUpperCase()" required>
              </div>
              <div class="col-md-6">
                <label for="cliente_nome" class="form-label">Nome do Cliente:</label>
                <input type="text" class="form-control" id="cliente_nome" name="cliente_nome" required>
              </div>
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="cliente_cpf" class="form-label">CPF do Cliente:</label>
                <input type="text" class="form-control" id="cliente_cpf" name="cliente_cpf" oninput="mascaraCPF(this)" required>
              </div>
              <div class="col-md-6">
                <label for="cliente_endereco" class="form-label">Endereço do Cliente:</label>
                <input type="text" class="form-control" id="cliente_endereco" name="cliente_endereco" required>
              </div>
            </div>
            
            <div class="row mb-3">
  <div class="col-md-6">
    <label for="imagem" class="form-label">Imagem do Cliente (50x50px):</label>
    <input type="file" class="form-control" id="imagem" name="imagem" accept="image/*">
  </div>
</div>


            <button type="submit" class="btn btn-primary">Criar Rastreio</button>
          </form>

                    </form>
                </div>
            </div>

            <!-- Lista de rastreios -->
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title mb-4">Rastreios Cadastrados</h5>
                    
                    <?php if (empty($rastreios)): ?>
                        <div class="alert alert-info">Nenhum rastreio encontrado</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th class="codigo-col">Código</th>
                                        <th>Usuário</th>
                                        <th class="table-actions text-end">Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($rastreios as $r): ?>
                                    <tr>
                                        <td><?= htmlspecialchars(
                                            $r["codigo"]
                                        ) ?></td>
                                        <td><?= htmlspecialchars(
                                            $r["username"]
                                        ) ?></td>
                                        <td class="text-end">
                                            <a href="../encomenda?tracking=<?= $r["codigo"] ?>" 
                                               class="btn btn-success btn-sm">Link
</a>
                                            </a>
                                                                                        <a href="?delete=<?= $r["id"] ?>" 
                                               class="btn btn-danger btn-sm"
                                               onclick="return confirm('Tem certeza que deseja excluir?')">
                  <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Função para formatar o CPF
function mascaraCPF(cpf) {
    var cpfValue = cpf.value;
    cpfValue = cpfValue.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
    cpfValue = cpfValue.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4'); // Aplica a máscara
    cpf.value = cpfValue;
}
</script>

</body>
</html>
