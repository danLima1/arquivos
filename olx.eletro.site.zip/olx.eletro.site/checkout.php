<?php
session_start(); // Inicia a sessão para armazenar o ID do usuário

// Inclui o arquivo de configuração do banco de dados
require_once('./config/db.php');

// Inclui a função para obter o usuário pelo ID
require_once('./functions/getUserById.php');

// Obtém o ID da URL de forma segura
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

if ($id) {
    // Chama a função para obter o usuário
    $cliente = getUserById($conn, $id);

    // Se encontrou o usuário, armazena os dados na sessão
    if ($cliente) {
        $_SESSION['user_id'] = $cliente['id']; // Salva o ID do usuário na sessão
    } else {
        header("Location: https://www.olx.com.br");
        exit();
    }
} else {
    // Se o ID não foi passado, redireciona para olx.com.br
    header("Location: https://www.olx.com.br");
    exit();
}

// Fecha a conexão com o banco de dados
mysqli_close($conn);
?>



<!-- saved from url=(0042)https://olx.comprasegurasx.com.br/checkout -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title>Compra Segura | OLX </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <meta name="next-head-count" content="3">
    <meta name="theme-color" content="#6E0AD6">
    <noscript data-n-css=""></noscript>
    <link rel="icon" href="https://olx.comprasegurasx.com.br/favicon.ico" sizes="any">
    <link rel="apple-touch-icon" href="https://olx.comprasegurasx.com.br/apple-touch-icon.png">
    <style>body{font-size:100%;}</style>
    <style>/*! CSS Used from: https://static.olx.com.br/p2p/txp/txp-client/_next/static/css/6429af4ce4359126.css */
      /*! @import https://static.olx.com.br/design-system/olx-reset.min.css */
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      button{font:inherit;}
      button,[type='button']{-webkit-appearance:button;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      /*! end @import */
      .olx-visually-hidden{clip:rect(1px,1px,1px,1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-visually-hidden:focus{clip:auto;height:auto;overflow:auto;position:absolute;width:auto;}
      .olx-modal{display:flex;height:100%;justify-content:center;width:100%;}
      .olx-modal{align-items:flex-end;background-color:rgba(0,0,0,.333);border:0;opacity:0;pointer-events:none;position:fixed;right:0;top:0;transition:opacity var(--transition-timing-ease) var(--transition-duration-3);visibility:hidden;will-change:transform;z-index:var(--z-index-900-modal,900);}
      .olx-modal[aria-hidden=false]{opacity:1;pointer-events:auto;visibility:visible;}
      @media screen and (min-width:840px){
      .olx-modal{align-items:center;}
      }
      .olx-modal__dialog{background-color:var(--modal-background-color);border-radius:var(--border-radius-md);border-bottom-left-radius:0;border-bottom-right-radius:0;display:flex;flex-direction:column;max-height:var(--modal-max-height);max-width:100%;min-height:200px;opacity:0;padding:var(--spacing-3) var(--spacing-4);position:relative;transform:translateY(100%) scale(.9);transition:all var(--transition-timing-ease) var(--transition-duration-3);width:100%;}
      .olx-modal__dialog[data-show=true]{opacity:1;transform:translateY(0);}
      @media screen and (min-width:840px){
      .olx-modal__dialog{border-radius:var(--border-radius-md);max-width:var(--modal-max-width);transform:translateY(10%) scale(.9);}
      .olx-modal__dialog[data-show=true]{opacity:1;transform:scale(1);}
      }
      .olx-modal__content{background-color:var(--color-neutral-70);display:flex;flex-direction:column;height:100%;overflow:hidden auto;}
      .olx-modal__content::-webkit-scrollbar{width:10px;}
      .olx-modal__content::-webkit-scrollbar-track{background:var(--color-neutral-80);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb{background:var(--color-neutral-90);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb:hover{background:var(--color-neutral-110);}
      .olx-modal__close-button{align-items:center;align-self:flex-end;background-color:transparent;border:none;border-radius:var(--border-radius-pill);color:var(--modal-button-color);cursor:pointer;display:flex;height:48px;justify-content:center;min-height:48px;width:48px;}
      .olx-modal__close-button:hover{background-color:var(--modal-button-background-color-hover);}
      *,:after,:before{box-sizing:border-box;border:0 solid;}
      :after,:before{--tw-content:"";}
      button{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0;}
      button{text-transform:none;}
      button{-webkit-appearance:button;background-color:transparent;background-image:none;}
      button{cursor:pointer;}
      :disabled{cursor:default;}
      svg{display:block;vertical-align:middle;}
      *,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(59,130,246,.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      /*! CSS Used from: https://static.olx.com.br/p2p/txp/txp-client/_next/static/css/31c562ea66562f64.css */
      .styles_restylePaymentCentral__WrsmY{width:100%;}
      .styles_restylePaymentCentral__WrsmY>div{margin:0!important;padding:0!important;}
      .styles_restylePaymentCentral__WrsmY>div>div>div{box-shadow:none;margin:0!important;padding:0!important;}
      .styles_restylePaymentCentral__WrsmY>div>div>div>div{margin:0!important;padding:0!important;}
      /*! CSS Used from: Embedded */
      .bxVNCd{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .ePesmX{color:rgb(74, 74, 74);line-height:28px;font-size:20px;font-weight:700;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .hYhJJh{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:700;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .iVpJPn{color:rgb(74, 74, 74);line-height:20px;font-size:14px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .TumkA{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:100;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .fyGuQe{padding:0px;cursor:unset;}
      .iwtnNi{box-sizing:border-box;}
      .cVvyrS{line-height:24px;font-size:16px;padding-left:24px;padding-right:24px;height:40px;min-width:120px;border-width:0px;border-radius:32px;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;background-color:rgb(247, 131, 35);color:rgb(255, 255, 255);flex:1 1 0%;display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;cursor:pointer;position:relative;}
      .cVvyrS:hover{background-color:rgb(249, 157, 83);}
      .eiUWCZ{display:flex;padding:16px;border-radius:8px;background-color:white;overflow:hidden;box-shadow:rgba(0, 0, 0, 0.08) 0px 4px 16px 0px, rgba(0, 0, 0, 0.06) 0px 2px 4px 0px;}
      .ekmyKu{margin:16px;}
      .gGRjfv{width:100%;padding:16px;}
      .hTDzfn{margin-bottom:16px;}
      .jWPRRO{margin-top:8px;margin-bottom:8px;}
      .kIVmeI{margin:16px;}
      .gvJynP{margin-left:15px;margin-right:15px;}
      .iKolad{padding:0px 24px;display:inline;}
      .fxcfPI{text-align:center;}
      .gCGUBN{text-align:right;}
      .hTKLZQ{width:100%;display:flex;flex-direction:row;-webkit-box-align:center;align-items:center;height:73px;min-height:118px;padding:16px 32px;border-radius:8px;background-color:rgba(255, 68, 68, 0.1);}
      .eZdYAc{color:rgb(144, 17, 17);}
      /*! CSS Used fontfaces */
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
    </style>
    <style>/*! CSS Used from: https://static.olx.com.br/p2p/txp/txp-client/_next/static/css/e29f9c6c192e5417.css */
      /*! @import https://static.olx.com.br/design-system/olx-reset.min.css */
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      body,h1,h3,p,figure{margin:0;}
      body{min-height:100vh;text-rendering:optimizeSpeed;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;line-height:1.5;}
      img{max-width:100%;display:block;}
      input,button{font:inherit;}
      button,[type='button'],[type='submit']{-webkit-appearance:button;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      legend{padding:0;display:table;}
      fieldset{border:0;padding:.01em 0 0 0;margin:0;min-width:0;}
      /*! end @import */
      /*! @import https://dsapega.olx.com.br/olx/v1/ds-tokens.css */
      :root{--border-radius-none:0;--border-radius-xxs:2px;--border-radius-xs:4px;--border-radius-sm:8px;--border-radius-md:16px;--border-radius-lg:24px;--border-radius-pill:500px;--border-radius-circle:50%;--border-width-none:0;--border-width-hairline:1px;--border-width-thin:2px;--border-width-thick:4px;--border-width-heavy:8px;--media-query-sm:360px;--media-query-md:840px;--media-query-lg:1200px;--media-query-xl:1500px;--media-query-xxl:1720px;--color-primary-70:#fff3e6;--color-primary-80:#ffe1bf;--color-primary-90:#ffbb73;--color-primary-100:#f28000;--color-primary-110:#df7400;--color-primary-120:#cb6700;--color-primary-130:#b35a00;--color-primary-darkest:#b35a00;--color-primary-darker:#cb6700;--color-primary-dark:#df7400;--color-primary-medium:#f28000;--color-primary-light:#ffbb73;--color-primary-lighter:#ffe1bf;--color-primary-lightest:#fff3e6;--color-secondary-70:#f0e6ff;--color-secondary-80:#c599ff;--color-secondary-90:#994dfa;--color-secondary-100:#6e0ad6;--color-secondary-110:#5c08b2;--color-secondary-120:#49078f;--color-secondary-130:#37056b;--color-secondary-darkest:#37056b;--color-secondary-darker:#49078f;--color-secondary-dark:#5c08b2;--color-secondary-medium:#6e0ad6;--color-secondary-light:#994dfa;--color-secondary-lighter:#c599ff;--color-secondary-lightest:#f0e6ff;--color-neutral-70:#ffffff;--color-neutral-80:#f5f6f7;--color-neutral-90:#cfd4dd;--color-neutral-100:#8994a9;--color-neutral-110:#5e6a82;--color-neutral-120:#3c4453;--color-neutral-130:#1a1d23;--color-neutral-darkest:#1a1d23;--color-neutral-darker:#3c4453;--color-neutral-dark:#5e6a82;--color-neutral-medium:#8994a9;--color-neutral-light:#cfd4dd;--color-neutral-lighter:#f5f6f7;--color-neutral-lightest:#ffffff;--color-feedback-success-80:#def9cc;--color-feedback-success-90:#8ce563;--color-feedback-success-100:#24a148;--color-feedback-success-110:#197b35;--color-feedback-success-120:#105323;--color-feedback-success-darkest:#105323;--color-feedback-success-dark:#197b35;--color-feedback-success-medium:#24a148;--color-feedback-success-light:#8ce563;--color-feedback-success-lightest:#def9cc;--color-feedback-error-80:#fff5f5;--color-feedback-error-90:#f48787;--color-feedback-error-100:#e22828;--color-feedback-error-110:#901111;--color-feedback-error-120:#3b0505;--color-feedback-error-darkest:#3b0505;--color-feedback-error-dark:#901111;--color-feedback-error-medium:#e22828;--color-feedback-error-light:#f48787;--color-feedback-error-lightest:#fff5f5;--color-feedback-attention-80:#fff7e0;--color-feedback-attention-90:#ffe19a;--color-feedback-attention-100:#f9af27;--color-feedback-attention-110:#7b5613;--color-feedback-attention-120:#3c2a09;--color-feedback-attention-darkest:#3c2a09;--color-feedback-attention-dark:#7b5613;--color-feedback-attention-medium:#f9af27;--color-feedback-attention-light:#ffe19a;--color-feedback-attention-lightest:#fff7e0;--color-feedback-info-80:#e1f9ff;--color-feedback-info-90:#9ce6f9;--color-feedback-info-100:#28b5d9;--color-feedback-info-110:#14596b;--color-feedback-info-120:#0a2b34;--color-feedback-info-darkest:#0a2b34;--color-feedback-info-dark:#14596b;--color-feedback-info-medium:#28b5d9;--color-feedback-info-light:#9ce6f9;--color-feedback-info-lightest:#e1f9ff;--font-family:'Nunito Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;--font-size-nano:10px;--font-size-xxxs:12px;--font-size-xxs:14px;--font-size-xs:16px;--font-size-sm:18px;--font-size-md:20px;--font-size-lg:24px;--font-size-xl:30px;--font-size-xxl:36px;--font-size-xxxl:48px;--font-size-huge:64px;--font-weight-bold:700;--font-weight-semibold:600;--font-weight-regular:400;--font-weight-light:300;--font-lineheight-supertight:1;--font-lineheight-tight:1.15;--font-lineheight-medium:1.32;--font-lineheight-distant:1.40;--font-lineheight-superdistant:1.50;--z-index-1-default:1;--z-index-100-masked:100;--z-index-200-mask:200;--z-index-250-mask-button:250;--z-index-300-sticky:300;--z-index-400-header:400;--z-index-500-toast:500;--z-index-600-dropdown:600;--z-index-700-overlay:700;--z-index-800-spinner:800;--z-index-900-modal:900;--z-index-950-popup:950;--z-index-1000-top:1000;--z-index-deep:-9999;--opacity-full:1;--opacity-semiopaque:0.8;--opacity-intense:0.64;--opacity-medium:0.32;--opacity-light:0.16;--opacity-semitransparent:0.08;--opacity-none:0;--shadow-level-1:0px 1px 1px rgba(0, 0, 0, 0.14);--shadow-level-2:0px 2px 2px rgba(0, 0, 0, 0.14);--shadow-level-3:0px 3px 4px rgba(0, 0, 0, 0.14);--shadow-level-4:0px 4px 5px rgba(0, 0, 0, 0.14);--shadow-level-6:0px 6px 10px rgba(0, 0, 0, 0.14);--shadow-level-8:0px 8px 10px rgba(0, 0, 0, 0.14);--shadow-level-9:0px 9px 12px rgba(0, 0, 0, 0.14);--shadow-level-12:0px 12px 17px rgba(0, 0, 0, 0.14);--shadow-level-16:0px 16px 24px rgba(0, 0, 0, 0.14);--shadow-level-24:0px 24px 38px rgba(0, 0, 0, 0.14);--spacing-1:8px;--spacing-2:16px;--spacing-3:24px;--spacing-4:32px;--spacing-5:40px;--spacing-6:48px;--spacing-7:56px;--spacing-8:64px;--spacing-9:72px;--spacing-0-25:2px;--spacing-0-5:4px;--spacing-1-5:12px;--spacing-10:80px;--spacing-stack-quarck:4px;--spacing-stack-nano:8px;--spacing-stack-xxxs:16px;--spacing-stack-xxs:24px;--spacing-stack-xs:32px;--spacing-stack-sm:40px;--spacing-stack-md:48px;--spacing-stack-lg:56px;--spacing-stack-xl:64px;--spacing-stack-xxl:80px;--spacing-stack-xxxl:120px;--spacing-stack-huge:160px;--spacing-stack-giant:200px;--spacing-inline-quarck:4px;--spacing-inline-nano:8px;--spacing-inline-xxxs:16px;--spacing-inline-xxs:24px;--spacing-inline-xs:32px;--spacing-inline-sm:40px;--spacing-inline-md:48px;--spacing-inline-lg:64px;--spacing-inline-xl:80px;--spacing-inset-xxs:2px;--spacing-inset-xs:4px;--spacing-inset-sm:8px;--spacing-inset-md:16px;--spacing-inset-lg:24px;--spacing-inset-xl:32px;--spacing-inset-xxl:40px;--spacing-squish-xxs:2px 4px;--spacing-squish-xs:4px 8px;--spacing-squish-sm:8px 16px;--spacing-squish-md:8px 24px;--spacing-squish-lg:12px 16px;--spacing-squish-xl:16px 24px;--spacing-squish-xxl:16px 32px;--spacing-squish-xxxl:24px 32px;--transition-delay-1:100ms;--transition-delay-2:200ms;--transition-delay-3:300ms;--transition-delay-4:400ms;--transition-delay-5:500ms;--transition-delay-slowest:500ms;--transition-delay-slow:400ms;--transition-delay-normal:300ms;--transition-delay-fast:200ms;--transition-delay-fastest:100ms;--transition-timing-ease:cubic-bezier(0.250, 0.100, 0.250, 1.000);--transition-timing-ease-in:cubic-bezier(0.420, 0.000, 1.000, 1.000);--transition-timing-ease-out:cubic-bezier(0.000, 0.000, 0.580, 1.000);--transition-timing-ease-in-out:cubic-bezier(0.420, 0.000, 0.580, 1.000);--transition-duration-1:100ms;--transition-duration-2:200ms;--transition-duration-3:300ms;--transition-duration-4:400ms;--transition-duration-5:500ms;--transition-duration-slowest:500ms;--transition-duration-slow:400ms;--transition-duration-normal:300ms;--transition-duration-fast:200ms;--transition-duration-fastest:100ms;--transition-repetition-2:2;--transition-repetition-3:3;--transition-repetition-infinite:infinite;--button-primary-background-color-base:#f28000;--button-primary-background-color-hover:#df7400;--button-primary-background-color-loading:#f28000;--button-primary-border-color-base:#f28000;--button-primary-border-color-hover:#df7400;--button-primary-color-font-base:#ffffff;--button-primary-color-outline:#ffe1bf;--button-secondary-background-color-base:transparent;--button-secondary-background-color-hover:#fff3e6;--button-secondary-background-color-loading:transparent;--button-secondary-border-color-base:#f28000;--button-secondary-border-color-hover:#fff3e6;--button-secondary-color-font-base:#f28000;--button-secondary-color-outline:#ffe1bf;--button-secondary-inverted-background-color-base:#ffffff00;--button-secondary-inverted-background-color-hover:#ffffff2B;--button-secondary-inverted-background-color-loading:transparent;--button-secondary-inverted-border-color-base:#ffffff;--button-secondary-inverted-border-color-hover:#ffffff2B;--button-secondary-inverted-color-font-base:#ffffff;--button-secondary-inverted-color-outline:#ffffff52;--button-tertiary-background-color-base:#fff3e6;--button-tertiary-background-color-hover:#ffe1bf;--button-tertiary-background-color-loading:#df7400;--button-tertiary-border-color-base:#fff3e6;--button-tertiary-border-color-hover:#ffe1bf;--button-tertiary-color-font-base:#cb6700;--button-tertiary-color-outline:#ffe1bf;--button-link-button-background-color-base:transparent;--button-link-button-background-color-hover:#f0e6ff;--button-link-button-background-color-loading:#f0e6ff;--button-link-button-border-color-base:transparent;--button-link-button-border-color-hover:#f0e6ff;--button-link-button-color-font-base:#6e0ad6;--button-link-button-color-outline:#f0e6ff;--button-danger-background-color-base:#e22828;--button-danger-background-color-hover:#901111;--button-danger-background-color-loading:#e22828;--button-danger-border-color-base:#e22828;--button-danger-border-color-hover:#901111;--button-danger-color-font-base:#ffffff;--button-danger-color-outline:#f48787;--button-neutral-background-color-base:transparent;--button-neutral-background-color-hover:#cfd4dd;--button-neutral-background-color-loading:transparent;--button-neutral-border-color-base:#5e6a82;--button-neutral-border-color-hover:#5e6a82;--button-neutral-color-font-base:#1a1d23;--button-neutral-color-outline:#f5f6f7;--button-disabled-background-color:#f5f6f7;--button-disabled-border-color:transparent;--button-disabled-color-font:#5e6a82;--carousel-focus:#1a1d23;--carousel-arrow-background-color-base:#ffffff;--carousel-arrow-background-color-hover:#cfd4dd;--carousel-arrow-color:#1a1d23;--checkbox-background-color-base:#ffffff;--checkbox-background-color-checked:#6e0ad6;--checkbox-background-color-checked-hover:#49078f;--checkbox-background-color-error:#fff5f5;--checkbox-background-color-hover:#f5f6f7;--checkbox-border-color-base:#cfd4dd;--checkbox-border-color-hover:#cfd4dd;--checkbox-border-color-error:#e22828;--checkbox-color-outline:#c599ff;--checkbox-color-icon:#ffffff;--container-background-color:#ffffff;--container-border-color-outlined:#cfd4dd;--divider-default-background-color:#cfd4dd;--divider-inverted-background-color:#5e6a82;--dropdown-background-color-base:#ffffff;--dropdown-background-color-error:#fff5f5;--dropdown-background-color-disabled:#f5f6f7;--dropdown-border-color-base:#cfd4dd;--dropdown-border-color-disabled:#f5f6f7;--dropdown-border-color-error:#e22828;--dropdown-border-color-focus:#6e0ad6;--dropdown-border-color-hover:#cfd4dd;--dropdown-border-color-selected:#1a1d23;--dropdown-color-font-base:#8994a9;--dropdown-color-font-disabled:#8994a9;--dropdown-color-font-selected:#1a1d23;--dropdown-icon-color-base:#1a1d23;--dropdown-icon-color-disabled:#8994a9;--link-color-main-base:#6e0ad6;--link-color-main-hover:#5c08b2;--link-color-main-active:#49078f;--link-color-grey-base:#1a1d23;--link-color-grey-hover:#6e0ad6;--link-color-grey-active:#5c08b2;--link-color-inverted-base:#ffffff;--link-color-inverted-hover:#c599ff;--link-color-inverted-active:#f0e6ff;--modal-background-color:#ffffff;--modal-button-background-color-hover:#cfd4dd;--modal-button-background-color-focus:#1a1d23;--modal-button-color:#1a1d23;--radio-background-color-base:#ffffff;--radio-background-color-checked:#6e0ad6;--radio-background-color-checked-hover:#49078f;--radio-background-color-error:#e22828;--radio-background-color-hover:#f5f6f7;--radio-border-color-base:#5e6a82;--radio-border-color-checked:#6e0ad6;--radio-border-color-checked-hover:#49078f;--radio-border-color-hover:#cfd4dd;--radio-border-color-error:#e22828;--radio-color-outline:#c599ff;--radio-font-color:#1a1d23;--skeleton-background-0:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 0%, #f5f6f7 100%);--skeleton-background-20:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 20%, #f5f6f7 100%);--skeleton-background-40:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 40%, #f5f6f7 100%);--skeleton-background-60:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 60%, #f5f6f7 100%);--skeleton-background-80:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 80%, #f5f6f7 100%);--skeleton-background-100:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 100%, #f5f6f7 100%);--spinner-color:#6e0ad6;--spinner-inverted-color:#ffffff;--spinner-extra-small-size:16px;--spinner-small-size:24px;--spinner-medium-size:32px;--spinner-large-size:48px;--spinner-extra-large-size:56px;--spinner-huge-size:64px;--spots-background-circle:#f0e6ff;--spots-background-triangle:#def9cc;--spots-background-square:#fff3e6;--spots-background-neutral:#f5f6f7;--spots-color-circle:#6e0ad6;--spots-color-triangle:#8ce563;--spots-color-square:#f28000;--spots-color-neutral:#cfd4dd;--spots-border-color-default:#1a1d23;--spots-border-color-neutral:#8994a9;--textinput-background-color-base:#ffffff;--textinput-background-color-error:#fff5f5;--textinput-background-color-disabled:#f5f6f7;--textinput-background-color-success:#ffffff;--textinput-border-color-empty:#cfd4dd;--textinput-border-color-error:#e22828;--textinput-border-color-disabled:transparent;--textinput-border-color-filled:#1a1d23;--textinput-border-color-focus:#6e0ad6;--textinput-border-color-hover:#cfd4dd;--textinput-border-color-success:#24a148;--textinput-border-color-empty-hover:#cfd4dd;--textinput-color-font:#1a1d23;--textinput-color-placeholder:#8994a9;--textinput-color-disabled:#8994a9;--textinput-icon-color:#3c4453;--textinput-caption-font-color:#3c4453;--textinput-feedback-error-font-color:#e22828;--text-color:#1a1d23;--toast-background-color:#3c4453;--toast-font-color:#ffffff;--toast-close-icon-color:#ffffff;--toggleswitch-background-color-base:#cfd4dd;--toggleswitch-background-color-checked:#6e0ad6;--toggleswitch-background-color-checked-hover:#49078f;--toggleswitch-background-color-hover:#8994a9;--toggleswitch-color-outline:#c599ff;--toggleswitch-icon-color:#ffffff;}
      /*! end @import */
      hr{background-color:var(--divider-default-background-color);border:none;height:1px;width:100%;}
      #__next{display:flex;flex-direction:column;height:100vh;}
      .olx-button{align-items:center;background-color:var(--button-background-color);border-color:var(--button-border);border-radius:var(--border-radius-pill);border-style:solid;border-width:var(--border-width-hairline);color:var(--button-color-font);cursor:pointer;display:inline-flex;font-family:var(--font-family);font-size:var(--button-font-size);font-weight:var(--font-weight-semibold);height:var(--button-height);justify-content:center;line-height:var(--button-line-height);min-width:72px;outline:none;padding:var(--button-padding);position:relative;text-decoration:initial;width:-moz-fit-content;width:fit-content;}
      .olx-button--fullwidth{width:100%;}
      .olx-button:active{transform:scale(.96);}
      .olx-button:active,.olx-button:not(:active){transition:all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:not(:hover){transition:all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:focus{outline:var(--color-neutral-130) solid var(--border-width-thin);outline-offset:var(--border-width-thin);transition:outline 0ms,outline-offset 0ms;}
      .olx-button:not(.olx-button--disabled):hover{background-color:var(--button-background-color-hover);border-color:var(--button-border-color-hover);transition:all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:focus:not(:focus-visible){outline:none;outline-offset:0;}
      .olx-button--small{--button-height:32px;--button-padding:var(--spacing-1) var(--spacing-2);--button-font-size:var(--font-size-xxs);--button-line-height:var(--font-lineheight-tight);}
      .olx-button--medium{--button-height:40px;--button-padding:var(--spacing-1) var(--spacing-3);--button-font-size:var(--font-size-xs);--button-line-height:var(--font-lineheight-superdistant);}
      .olx-button--large{--button-height:48px;--button-padding:var(--spacing-2) var(--spacing-3);--button-font-size:var(--font-size-xs);--button-line-height:var(--font-lineheight-supertight);}
      .olx-button--primary{--button-background-color:var(--button-primary-background-color-base);--button-border:var(--button-primary-border-color-base);--button-color-font:var(--button-primary-color-font-base);--button-background-color-hover:var(--button-primary-background-color-hover);--button-border-color-hover:var(--button-primary-border-color-hover);}
      .olx-button--secondary{--button-background-color:var(--button-secondary-background-color-base);--button-border:var(--button-secondary-border-color-base);--button-color-font:var(--button-secondary-color-font-base);--button-background-color-hover:var(--button-secondary-background-color-hover);--button-border-color-hover:var(--button-secondary-border-color-hover);}
      .olx-button--link-button{--button-background-color:var(--button-link-button-background-color-base);--button-border:var(--button-link-button-border-color-base);--button-color-font:var(--button-link-button-color-font-base);--button-background-color-hover:var(--button-link-button-background-color-hover);--button-border-color-hover:var(--button-link-button-border-color-hover);}
      .olx-button--disabled{background-color:var(--button-disabled-background-color);border-color:var(--button-disabled-border-color);color:var(--button-disabled-color-font);cursor:not-allowed;}
      .olx-button__content-wrapper{align-items:center;display:inline-flex;justify-content:center;visibility:visible;}
      .olx-link{align-items:center;color:var(--link-color);cursor:pointer;display:inline-flex;font-family:var(--font-family);font-size:var(--font-size);font-weight:var(--font-weight-semibold);justify-content:center;line-height:var(--font-lineheight);outline:none;text-decoration:none;transition:all var(--transition-duration-3) var(--transition-timing-ease);}
      .olx-link:active{color:var(--link-color-active);}
      .olx-link:focus{border-radius:var(--border-radius-xxs);outline:var(--border-width-thin) solid var(--color-neutral-130);}
      .olx-link:hover{color:var(--link-color-hover);text-decoration:underline;}
      .olx-link:focus:not(:focus-visible){box-shadow:none;outline:0;}
      .olx-link--caption{--font-size:var(--font-size-xxxs);--font-lineheight:var(--font-lineheight-medium);}
      .olx-link--medium{--font-size:var(--font-size-xs);--font-lineheight:var(--font-lineheight-superdistant);}
      .olx-link--main{--link-color:var(--link-color-main-base);--link-color-hover:var(--link-color-main-hover);--link-color-active:var(--link-color-main-active);}
      .olx-text{color:var(--text-color);display:block;font-family:var(--font-family);font-style:normal;font-weight:var(--font-weight-regular);margin:0;padding:0;word-break:break-word;}
      .olx-text--title-large{font-size:var(--font-size-lg);font-weight:var(--font-weight-semibold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width:840px){
      .olx-text--title-large{font-size:var(--font-size-xxl);}
      }
      .olx-text--title-small{font-size:var(--font-size-sm);font-weight:var(--font-weight-bold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width:840px){
      .olx-text--title-small{font-size:var(--font-size-md);}
      }
      .olx-text--body-medium{line-height:var(--font-lineheight-superdistant);}
      .olx-text--body-medium{font-size:var(--font-size-xs);}
      .olx-text--body-small{font-size:var(--font-size-xxs);line-height:var(--font-lineheight-distant);}
      .olx-text--caption{font-size:var(--font-size-xxxs);line-height:var(--font-lineheight-medium);}
      .olx-text--regular{font-weight:var(--font-weight-regular);}
      .olx-text--semibold{font-weight:var(--font-weight-semibold);}
      .olx-text--block{display:block;}
      .olx-text-input__input-container{align-items:center;background-color:var(--textinput-background-color-base);border:none;border-radius:var(--border-radius-xs);box-shadow:0 0 0 var(--border-width-hairline) var(--textinput-border-color-empty);color:var(--textinput-color-font);display:inline-flex;position:relative;width:100%;z-index:var(--z-index-1-default,1);}
      .olx-text-input__input-container:hover{box-shadow:0 0 0 var(--border-width-thin) var(--textinput-border-color-empty-hover);}
      .olx-text-input__input-container--medium{border-radius:var(--border-radius-sm);}
      .olx-text-input__input-field{background-color:inherit;border:none;border-radius:var(--border-radius-xs);color:var(--color-neutral-130);font-family:var(--font-family);font-size:var(--font-size-xxs);font-weight:var(--font-weight-regular);outline:none;padding:var(--spacing-0-5) var(--spacing-1);position:relative;width:100%;}
      .olx-text-input__input-field--medium{border-radius:var(--border-radius-sm);font-size:var(--font-size-xs);line-height:var(--font-lineheight-distant);padding:var(--spacing-1-5) var(--spacing-2);}
      .olx-text-input__input-field::placeholder{color:var(--textinput-color-placeholder);}
      .olx-container{background-color:var(--container-background-color);border-radius:var(--border-radius-sm);overflow:hidden;padding:var(--spacing-2);}
      .olx-container--outlined{border:var(--border-width-hairline) solid var(--container-border-color-outlined);}
      .olx-radio__stylized{align-items:center;border-color:var(--radio-border-color-general);border-radius:var(--border-radius-pill);border-style:solid;border-width:var(--border-width-hairline);display:flex;height:100%;justify-content:center;width:100%;}
      .olx-radio__stylized:after{background-color:var(--radio-background-color-general);border-color:green;border-radius:var(--border-radius-pill);content:"";height:12px;width:12px;}
      .olx-radio{--radio-background-color-general:transparent;--radio-border-color-general:var(--radio-border-color-base);align-items:center;cursor:pointer;display:inline-flex;flex-direction:row;justify-content:center;outline:none;width:-moz-fit-content;width:fit-content;}
      .olx-radio:active:not([aria-disabled=true]) .olx-radio__stylized{transform:scale(.92);}
      .olx-radio:hover{--radio-border-color-general:var(--radio-border-color-hover);}
      .olx-radio--checked{--radio-background-color-general:var(--radio-background-color-checked);--radio-border-color-general:var(--radio-border-color-checked);}
      .olx-radio--checked:hover{--radio-background-color-general:var(--radio-background-color-checked-hover);--radio-border-color-general:var(--radio-border-color-checked-hover);}
      .olx-radio__content-wrapper{display:flex;flex-direction:column;width:-moz-fit-content;width:fit-content;}
      .olx-radio__content{display:flex;}
      .olx-radio__input-wrapper{border-radius:var(--border-radius-pill);height:24px;max-height:24px;max-width:24px;min-height:24px;min-width:24px;padding:var(--spacing-0-25);position:relative;width:24px;}
      .olx-radio__native{height:1px;opacity:0;position:absolute;width:1px;}
      .olx-radio__label-wrapper{margin-left:var(--spacing-1);}
      .olx-divider{background-color:var(--divider-default-background-color);border:none;height:1px;margin:0;}
      .olx-visually-hidden{clip:rect(1px,1px,1px,1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-visually-hidden:focus{clip:auto;height:auto;overflow:auto;position:absolute;width:auto;}
      .olx-avatar{background-color:var(--color-neutral-80);border-radius:var(--border-radius-circle,50%);}
      .olx-modal[aria-hidden=false] {
      opacity: 1;
      pointer-events: auto;
      visibility: visible;
      }
      .olx-modal__dialog[data-show=true] {
      opacity: 1;
      transform: translateY(0);
      }
      .olx-modal{display:flex;height:100%;justify-content:center;width:100%;}
      .olx-modal{align-items:flex-end;background-color:rgba(0,0,0,.333);border:0;opacity:0;pointer-events:none;position:fixed;right:0;top:0;transition:opacity var(--transition-timing-ease) var(--transition-duration-3);visibility:hidden;will-change:transform;z-index:var(--z-index-900-modal,900);}
      @media screen and (min-width:840px){
      .olx-modal{align-items:center;}
      }
      .olx-modal__dialog{background-color:var(--modal-background-color);border-radius:var(--border-radius-md);border-bottom-left-radius:0;border-bottom-right-radius:0;display:flex;flex-direction:column;max-height:var(--modal-max-height);max-width:100%;min-height:200px;opacity:0;padding:var(--spacing-3) var(--spacing-4);position:relative;transform:translateY(100%) scale(.9);transition:all var(--transition-timing-ease) var(--transition-duration-3);width:100%;}
      @media screen and (min-width:840px){
      .olx-modal__dialog{border-radius:var(--border-radius-md);max-width:var(--modal-max-width);transform:translateY(10%) scale(.9);}
      }
      .olx-modal__content{background-color:var(--color-neutral-70);display:flex;flex-direction:column;height:100%;overflow:hidden auto;}
      .olx-modal__content::-webkit-scrollbar{width:10px;}
      .olx-modal__content::-webkit-scrollbar-track{background:var(--color-neutral-80);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb{background:var(--color-neutral-90);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb:hover{background:var(--color-neutral-110);}
      .olx-modal__close-button{align-items:center;align-self:flex-end;background-color:transparent;border:none;border-radius:var(--border-radius-pill);color:var(--modal-button-color);cursor:pointer;display:flex;height:48px;justify-content:center;min-height:48px;width:48px;}
      .olx-modal__close-button:hover{background-color:var(--modal-button-background-color-hover);}
      .olx-logo-olx{min-height:12px;min-width:12px;width:100%;}
      .olx-logo-olx--o{fill:var(--color-secondary-100);}
      .olx-logo-olx--l{fill:var(--color-feedback-success-90);}
      .olx-logo-olx--x{fill:var(--color-primary-100);}
      .olx-focus-header{background-color:var(--color-neutral-70);border-bottom:var(--border-width-hairline) solid var(--color-neutral-90);height:var(--spacing-10);padding:var(--spacing-2) var(--spacing-2,16px);width:100%;}
      @media screen and (min-width:840px){
      .olx-focus-header{padding:var(--spacing-2) var(--spacing-4,32px);}
      }
      @media screen and (min-width:1200px){
      .olx-focus-header{padding:var(--spacing-2) var(--spacing-9,72px);}
      }
      .olx-focus-header__content{align-items:center;-moz-column-gap:var(--spacing-3);column-gap:var(--spacing-3);display:flex;height:100%;margin:0 auto;max-width:1576px;}
      @media screen and (max-width:840px){
      .olx-focus-header__content{-moz-column-gap:var(--spacing-2);column-gap:var(--spacing-2);}
      }
      .olx-focus-header__logo{background-color:transparent;border:0;padding:0;}
      .olx-focus-header__logo-container{align-items:center;display:flex;height:var(--spacing-6);width:var(--spacing-6);}
      .olx-focus-header__profile-container{align-items:center;border:var(--border-width-hairline) solid var(--color-neutral-100);border-radius:var(--border-radius-pill);display:flex;height:var(--spacing-5);justify-content:center;margin-left:auto;width:135px;}
      @media screen and (max-width:840px){
      .olx-focus-header__profile-container{border:0;width:auto;}
      .olx-focus-header__profile-username{display:none;}
      }
      .olx-focus-header__profile-avatar{margin-right:var(--spacing-0-5);}
      .olx-color-neutral-120{color:var(--color-neutral-120);}
      .olx-d-flex{display:flex;}
      .olx-ai-flex-start{align-items:flex-start;}
      .olx-ai-center{align-items:center;}
      .olx-fd-column{flex-direction:column;}
      .olx-jc-flex-start{justify-content:flex-start;}
      .olx-jc-center{justify-content:center;}
      .olx-jc-flex-end{justify-content:flex-end;}
      .olx-jc-space-between{justify-content:space-between;}
      .olx-flex{flex:var(--olx-flex,1);}
      .olx-ml-0-25{margin-left:var(--spacing-0-25);}
      .olx-ml-0-5{margin-left:var(--spacing-0-5);}
      .olx-ml-1{margin-left:var(--spacing-1);}
      .olx-ml-3{margin-left:var(--spacing-3);}
      .olx-mr-0-25{margin-right:var(--spacing-0-25);}
      .olx-mr-2{margin-right:var(--spacing-2);}
      .olx-mt-1{margin-top:var(--spacing-1);}
      .olx-mt-2{margin-top:var(--spacing-2);}
      .olx-mt-3{margin-top:var(--spacing-3);}
      .olx-mb-0-5{margin-bottom:var(--spacing-0-5);}
      .olx-mb-1{margin-bottom:var(--spacing-1);}
      .olx-mb-2{margin-bottom:var(--spacing-2);}
      .olx-p-0-25{padding:var(--spacing-0-25);}
      .olx-pl-1{padding-left:var(--spacing-1);}
      .olx-pl-2{padding-left:var(--spacing-2);}
      *,:after,:before{box-sizing:border-box;border:0 solid;}
      :after,:before{--tw-content:"";}
      html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;font-feature-settings:normal;font-variation-settings:normal;}
      body{margin:0;line-height:inherit;}
      hr{height:0;color:inherit;border-top-width:1px;}
      h1,h3{font-size:inherit;font-weight:inherit;}
      a{color:inherit;text-decoration:inherit;}
      b{font-weight:bolder;}
      button,input{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0;}
      button{text-transform:none;}
      [type=button],[type=submit],button{-webkit-appearance:button;background-color:transparent;background-image:none;}
      figure,h1,h3,hr,p{margin:0;}
      fieldset{margin:0;}
      fieldset,legend{padding:0;}
      input::placeholder{opacity:1;color:#9ca3af;}
      button{cursor:pointer;}
      :disabled{cursor:default;}
      iframe,img,svg{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(59,130,246,.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      .invisible{visibility:hidden;}
      .sticky{position:sticky;}
      .top-0{top:0;}
      .z-1-default{z-index:var(--z-index-1-default);}
      .m-0{margin:0;}
      .mx-0-5{margin-left:var(--spacing-0-5);margin-right:var(--spacing-0-5);}
      .mx-auto{margin-left:auto;margin-right:auto;}
      .my-2{margin-top:var(--spacing-2);margin-bottom:var(--spacing-2);}
      .mb-1{margin-bottom:var(--spacing-1);}
      .mb-3{margin-bottom:var(--spacing-3);}
      .mb-\[163px\]{margin-bottom:163px;}
      .ml-auto{margin-left:auto;}
      .mr-2{margin-right:var(--spacing-2);}
      .mt-1{margin-top:var(--spacing-1);}
      .mt-2{margin-top:var(--spacing-2);}
      .\!inline{display:inline!important;}
      .flex{display:flex;}
      .inline-flex{display:inline-flex;}
      .grid{display:grid;}
      .h-\[72px\]{height:72px;}
      .h-full{height:100%;}
      .max-h-\[290px\]{max-height:290px;}
      .max-h-\[350px\]{max-height:350px;}
      .w-full{width:100%;}
      .min-w-\[96px\]{min-width:96px;}
      .max-w-\[120px\]{max-width:120px;}
      .max-w-xl{max-width:36rem;}
      .flex-1{flex:1 1 0%;}
      .shrink-0{flex-shrink:0;}
      .flex-col{flex-direction:column;}
      .items-start{align-items:flex-start;}
      .items-center{align-items:center;}
      .justify-center{justify-content:center;}
      .gap-1{gap:var(--spacing-1);}
      .gap-2{gap:var(--spacing-2);}
      .gap-3{gap:var(--spacing-3);}
      .overflow-auto{overflow:auto;}
      .overflow-hidden{overflow:hidden;}
      .overflow-y-auto{overflow-y:auto;}
      .rounded-circle{border-radius:var(--border-radius-circle);}
      .rounded-sm{border-radius:var(--border-radius-sm);}
      .border-neutral-90{border-color:var(--color-neutral-90);}
      .bg-\[--bg-color\]{background-color:var(--bg-color);}
      .bg-neutral-70{background-color:var(--color-neutral-70);}
      .bg-neutral-80{background-color:var(--color-neutral-80);}
      .bg-neutral-90{background-color:var(--color-neutral-90);}
      .object-contain{-o-object-fit:contain;object-fit:contain;}
      .p-0{padding:0;}
      .p-1{padding:var(--spacing-1);}
      .p-2{padding:var(--spacing-2);}
      .py-2{padding-top:var(--spacing-2);padding-bottom:var(--spacing-2);}
      .pb-1{padding-bottom:var(--spacing-1);}
      .pb-2{padding-bottom:var(--spacing-2);}
      .pl-2{padding-left:var(--spacing-2);}
      .pr-1{padding-right:var(--spacing-1);}
      .pr-2{padding-right:var(--spacing-2);}
      .pt-0{padding-top:0;}
      .pt-0-25{padding-top:var(--spacing-0-25);}
      .pt-2{padding-top:var(--spacing-2);}
      .pt-3{padding-top:var(--spacing-3);}
      .text-center{text-align:center;}
      .hover\:cursor-pointer:hover{cursor:pointer;}
      .hover\:bg-neutral-80:hover{background-color:var(--color-neutral-80);}
      .data-\[selecte-payment\=true\]\:border-secondary-100[data-selecte-payment=true]{border-color:var(--color-secondary-100);}
      @media (min-width:840px){
      .md\:mx-1{margin-left:var(--spacing-1);margin-right:var(--spacing-1);}
      .md\:mb-0{margin-bottom:0;}
      .md\:w-\[78\%\]{width:78%;}
      .md\:max-w-\[revert\]{max-width:revert;}
      .md\:grid-cols-\[1\.1fr_1fr\]{grid-template-columns:1.1fr 1fr;}
      .md\:border{border-width:1px;}
      .md\:px-2{padding-left:var(--spacing-2);padding-right:var(--spacing-2);}
      .md\:pb-2{padding-bottom:var(--spacing-2);}
      .md\:pb-3{padding-bottom:var(--spacing-3);}
      .md\:pb-4{padding-bottom:var(--spacing-4);}
      .md\:pl-4{padding-left:var(--spacing-4);}
      .md\:pr-4{padding-right:var(--spacing-4);}
      .md\:pt-1{padding-top:var(--spacing-1);}
      }
      @media (min-width:1200px){
      .lg\:mt-2{margin-top:var(--spacing-2);}
      .lg\:w-\[65\%\]{width:65%;}
      .lg\:max-w-\[105rem\]{max-width:105rem;}
      .lg\:px-4{padding-left:var(--spacing-4);padding-right:var(--spacing-4);}
      .lg\:pt-0{padding-top:0;}
      }
      @media (min-width:1500px){
      .xl\:px-3{padding-left:var(--spacing-3);padding-right:var(--spacing-3);}
      }
      .\[\&_\*\]\:h-2 *{height:var(--spacing-2);}
      .\[\&_\*\]\:w-2 *{width:var(--spacing-2);}
      .\[\&_span\]\:data-\[centered\=\'true\'\]\:items-center[data-centered=true] span{align-items:center;}
      /*! CSS Used from: Embedded */
      .iwtnNi{box-sizing:border-box;}
      .hNSuyh{flex:1 1 0%;-webkit-box-pack:center;justify-content:center;}
      /*! CSS Used fontfaces */
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
    </style>
    <style>/*! CSS Used from: https://static.olx.com.br/p2p/txp/txp-client/_next/static/css/e9af3a1ec6c2136d.css */
      /*! @import https://static.olx.com.br/design-system/olx-reset.min.css */
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      button{font:inherit;}
      button,[type='button']{-webkit-appearance:button;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      /*! end @import */
      .olx-visually-hidden{clip:rect(1px,1px,1px,1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-visually-hidden:focus{clip:auto;height:auto;overflow:auto;position:absolute;width:auto;}
      .olx-modal{display:flex;height:100%;justify-content:center;width:100%;}
      .olx-modal{align-items:flex-end;background-color:rgba(0,0,0,.333);border:0;opacity:0;pointer-events:none;position:fixed;right:0;top:0;transition:opacity var(--transition-timing-ease) var(--transition-duration-3);visibility:hidden;will-change:transform;z-index:var(--z-index-900-modal,900);}
      .olx-modal[aria-hidden=false]{opacity:1;pointer-events:auto;visibility:visible;}
      @media screen and (min-width:840px){
      .olx-modal{align-items:center;}
      }
      .olx-modal__dialog{background-color:var(--modal-background-color);border-radius:var(--border-radius-md);border-bottom-left-radius:0;border-bottom-right-radius:0;display:flex;flex-direction:column;max-height:var(--modal-max-height);max-width:100%;min-height:200px;opacity:0;padding:var(--spacing-3) var(--spacing-4);position:relative;transform:translateY(100%) scale(.9);transition:all var(--transition-timing-ease) var(--transition-duration-3);width:100%;}
      .olx-modal__dialog[data-show=true]{opacity:1;transform:translateY(0);}
      @media screen and (min-width:840px){
      .olx-modal__dialog{border-radius:var(--border-radius-md);max-width:var(--modal-max-width);transform:translateY(10%) scale(.9);}
      .olx-modal__dialog[data-show=true]{opacity:1;transform:scale(1);}
      }
      .olx-modal__content{background-color:var(--color-neutral-70);display:flex;flex-direction:column;height:100%;overflow:hidden auto;}
      .olx-modal__content::-webkit-scrollbar{width:10px;}
      .olx-modal__content::-webkit-scrollbar-track{background:var(--color-neutral-80);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb{background:var(--color-neutral-90);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb:hover{background:var(--color-neutral-110);}
      .olx-modal__close-button{align-items:center;align-self:flex-end;background-color:transparent;border:none;border-radius:var(--border-radius-pill);color:var(--modal-button-color);cursor:pointer;display:flex;height:48px;justify-content:center;min-height:48px;width:48px;}
      .olx-modal__close-button:hover{background-color:var(--modal-button-background-color-hover);}
      *,:after,:before{box-sizing:border-box;border:0 solid;}
      :after,:before{--tw-content:"";}
      button{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0;}
      button{text-transform:none;}
      button{-webkit-appearance:button;background-color:transparent;background-image:none;}
      button{cursor:pointer;}
      :disabled{cursor:default;}
      svg{display:block;vertical-align:middle;}
      *,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(59,130,246,.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      /*! CSS Used from: https://static.olx.com.br/p2p/txp/txp-client/_next/static/css/31c562ea66562f64.css */
      .styles_restylePaymentCentral__WrsmY{width:100%;}
      .styles_restylePaymentCentral__WrsmY>div{margin:0!important;padding:0!important;}
      .styles_restylePaymentCentral__WrsmY>div>div>div{box-shadow:none;margin:0!important;padding:0!important;}
      .styles_restylePaymentCentral__WrsmY>div>div>div>div{margin:0!important;padding:0!important;}
      /*! CSS Used from: Embedded */
      .ePesmX{color:rgb(74, 74, 74);line-height:28px;font-size:20px;font-weight:700;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .hYhJJh{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:700;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .iVpJPn{color:rgb(74, 74, 74);line-height:20px;font-size:14px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .iwtnNi{box-sizing:border-box;}
      .eiUWCZ{display:flex;padding:16px;border-radius:8px;background-color:white;overflow:hidden;box-shadow:rgba(0, 0, 0, 0.08) 0px 4px 16px 0px, rgba(0, 0, 0, 0.06) 0px 2px 4px 0px;}
      .ekmyKu{margin:16px;}
      .gGRjfv{width:100%;padding:16px;}
      .hTDzfn{margin-bottom:16px;}
      .jWPRRO{margin-top:8px;margin-bottom:8px;}
      .fxcfPI{text-align:center;}
      /*! CSS Used fontfaces */
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GiClntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5ntw.woff) format('woff');}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
    </style>
    <style>
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      input,button{font:inherit;}
      button{-webkit-appearance:button;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      /*! end @import */
      *,:after,:before{box-sizing:border-box;border:0 solid;}
      :after,:before{--tw-content:"";}
      a{color:inherit;text-decoration:inherit;}
      button,input{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0;}
      button{text-transform:none;}
      button{-webkit-appearance:button;background-color:transparent;background-image:none;}
      input::placeholder{opacity:1;color:#9ca3af;}
      button{cursor:pointer;}
      :disabled{cursor:default;}
      svg{display:block;vertical-align:middle;}
      *,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(59,130,246,.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      /*! CSS Used from: Embedded */
      .bxVNCd{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .iwtnNi{box-sizing:border-box;}
      .kgGtxX{line-height:24px;font-size:16px;height:48px;min-width:120px;border-width:0px;border-radius:32px;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;background-color:rgb(247, 131, 35);color:rgb(255, 255, 255);flex:1 1 0%;display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;cursor:pointer;position:relative;width:100%;padding:0px 8px;}
      .kgGtxX:hover{background-color:rgb(249, 157, 83);}
      .gxUxQr{color:rgb(110, 10, 214);font-weight:600;cursor:pointer;font-size:14px!important;text-align:center!important;text-decoration:none!important;font-family:"Nunito Sans", sans-serif!important;}
      .hTmUNX{width:100%;position:relative;border-style:solid;border-width:1px 0px 0px;border-color:rgb(242, 242, 242);}
      .dsRqZf{display:flex;flex-direction:column;-webkit-box-flex:1;flex-grow:1;}
      .zMEjU{display:flex;flex-direction:column;width:100%;}
      .dYvVHA{display:flex;flex-direction:column;width:30%;}
      .hPDeTI{display:flex;flex-direction:column;width:64%;}
      .drdMJh{outline:none;position:relative!important;border-style:solid!important;border-color:rgb(210, 210, 210)!important;border-width:1px!important;border-radius:4px!important;width:100%!important;min-height:48px!important;padding-top:11px!important;padding-bottom:12px!important;padding-left:16px!important;color:rgb(74, 74, 74)!important;font-size:16px!important;box-sizing:border-box!important;font-family:"Nunito Sans"!important;}
      .drdMJh::placeholder{color:rgb(210, 210, 210)!important;}
      .drdMJh:focus{border-color:rgb(153, 153, 153)!important;}
      .cHiWgl{outline:none;position:relative!important;border-style:solid!important;border-color: rgb(210, 210, 210)!important;border-width:1px!important;border-radius:4px!important;width:100%!important;min-height:48px!important;padding-top:11px!important;padding-bottom:12px!important;padding-left:16px!important;color:rgb(74, 74, 74)!important;font-size:16px!important;box-sizing:border-box!important;font-family:"Nunito Sans"!important;}
      .cHiWgl::placeholder{color:rgb(210, 210, 210)!important;}
      .cHiWgl:focus{border-color:rgb(153, 153, 153)!important;}
      .dmFVGH{font-size:16px;font-weight:bold;color:rgb(74, 74, 74);}
      .iEbJIH{font-size:12px;font-weight:400;color:rgb(153, 153, 153);}
      .dnAMMe{display:flex;flex-direction:row;-webkit-box-align:center;align-items:center;-webkit-box-pack:justify;justify-content:space-between;}
      .dMVcDb{display:flex;flex-direction:row;-webkit-box-align:center;align-items:center;}
      .lPdQr{margin-left:6px;}
      .kEfsFh{font-size:12px!important;color:rgb(255, 68, 68);}
      .dkfLcP{display:flex;flex-direction:column;margin-bottom:8px;}
      .fHPvXD{padding-top:8px;}
      .bJHVys{margin-top:4px;height:20px;}
      .jbJjPm{padding:0px;cursor:unset;width:24px;height:24px;}
      .evFrPE{position:relative;flex:1 0 0%;}
      .beFDIf{width:100%;display:flex;flex-direction:column;}
      .jaLVEl{width:100%;margin-top:24px;}
      .gpYbNf{margin-bottom:0px;}
      .fXtzlK{display:flex;flex-direction:row;-webkit-box-pack:justify;justify-content:space-between;margin-bottom:16px;}
      .dQVPfS{-webkit-box-pack:center;justify-content:center;margin-top:32px;}
      .bQPjaN{color:rgb(74, 74, 74);text-align:center;font-weight:600;margin-bottom:0.78em;margin-top:0.78em;font-size:20px;display:flex;}
      .ikBzXv{margin-bottom:16px;}
      .kxzifH{margin-bottom:94px;}
      .cikpic{display:flex;flex:1 1 0%;flex-direction:row;-webkit-box-pack:justify;justify-content:space-between;align-items:flex-start;height:32px;}
      .dsiZcx{display:flex;flex:1 1 0%;flex-direction:row;-webkit-box-pack:end;justify-content:flex-end;background:transparent;}
      .btPDUV:hover{cursor:pointer;}
      .kdfsUX{padding:16px;}
      .broalT [data-rsbs-header]{box-shadow:none!important;padding-bottom:0px;}
      .broalT [data-rsbs-overlay]{height:auto!important;max-height:calc(100% - 24px);}
      .broalT [data-rsbs-header]::before{background-color:transparent!important;}
      [data-rsbs-overlay]{border-top-left-radius:16px;border-top-right-radius:16px;display:flex;background:var(--rsbs-bg,#fff);flex-direction:column;height:var(--rsbs-overlay-h,0px);transform:translate3d(0,var(--rsbs-overlay-translate-y,0px),0);will-change:height;}
      [data-rsbs-overlay]:focus{outline:none;}
      [data-rsbs-overlay],[data-rsbs-root]::after{max-width:var(--rsbs-max-w,auto);margin-left:var(--rsbs-ml,env(safe-area-inset-left));margin-right:var(--rsbs-mr,env(safe-area-inset-right));}
      [data-rsbs-overlay],[data-rsbs-backdrop],[data-rsbs-root]::after{z-index:3;overscroll-behavior:none;touch-action:none;position:fixed;right:0px;bottom:0px;left:0px;user-select:none;-webkit-tap-highlight-color:transparent;}
      [data-rsbs-backdrop]{top:-60px;bottom:-60px;background-color:var(--rsbs-backdrop-bg,rgba(0,0,0,0.6));will-change:opacity;cursor:pointer;opacity:1;}
      [data-rsbs-root]::after{content:"";pointer-events:none;background:var(--rsbs-bg,#fff);height:1px;transform-origin:center bottom;transform:scale3d(1,var(--rsbs-antigap-scale-y,0),1);will-change:transform;}
      [data-rsbs-header]{flex-shrink:0;cursor:ns-resize;padding:16px;}
      [data-rsbs-header]{text-align:center;user-select:none;box-shadow:0 1px 0 rgba(46,59,66,calc(var(--rsbs-content-opacity,1) * 0.125));z-index:1;padding-top:calc(20px + env(safe-area-inset-top));padding-bottom:8px;}
      [data-rsbs-header]::before{position:absolute;content:"";display:block;width:36px;height:4px;top:calc(8px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);border-radius:2px;background-color:var(--rsbs-handle-bg,hsla(0,0%,0%,0.14));}
      @media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 2dppx){
      [data-rsbs-header]::before{transform:translateX(-50%) scaleY(0.75);}
      }
      [data-rsbs-has-header="false"] [data-rsbs-header]{box-shadow:none;padding-top:calc(12px + env(safe-area-inset-top));}
      [data-rsbs-scroll]{flex-shrink:1;-webkit-box-flex:1;flex-grow:1;-webkit-tap-highlight-color:revert;user-select:auto;overflow:auto;overscroll-behavior:contain;}
      [data-rsbs-scroll]:focus{outline:none;}
      [data-rsbs-has-footer="false"] [data-rsbs-content]{padding-bottom:env(safe-area-inset-bottom);}
      [data-rsbs-content]{overflow:hidden;}
      [data-rsbs-is-dismissable="true"] [data-rsbs-scroll] > *{opacity:var(--rsbs-content-opacity,1);}
      [data-rsbs-is-dismissable="true"] [data-rsbs-backdrop]{opacity:var(--rsbs-backdrop-opacity,1);}
    </style>
    <style>
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      h3,p{margin:0;}
      input{font:inherit;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      .olx-text{color:var(--text-color);display:block;font-family:var(--font-family);font-style:normal;font-weight:var(--font-weight-regular);margin:0;padding:0;word-break:break-word;}
      .olx-text--title-small{font-size:var(--font-size-sm);font-weight:var(--font-weight-bold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width:840px){
      .olx-text--title-small{font-size:var(--font-size-md);}
      }
      .olx-text--body-small{font-size:var(--font-size-xxs);line-height:var(--font-lineheight-distant);}
      .olx-text--regular{font-weight:var(--font-weight-regular);}
      .olx-text--semibold{font-weight:var(--font-weight-semibold);}
      .olx-text--bold{font-weight:var(--font-weight-bold);}
      .olx-text--block{display:block;}
      .olx-radio__stylized{align-items:center;border-color:var(--radio-border-color-general);border-radius:var(--border-radius-pill);border-style:solid;border-width:var(--border-width-hairline);display:flex;height:100%;justify-content:center;width:100%;}
      .olx-radio__stylized:after{background-color:var(--radio-background-color-general);border-color:green;border-radius:var(--border-radius-pill);content:"";height:12px;width:12px;}
      .olx-radio{--radio-background-color-general:transparent;--radio-border-color-general:var(--radio-border-color-base);align-items:center;cursor:pointer;display:inline-flex;flex-direction:row;justify-content:center;outline:none;width:-moz-fit-content;width:fit-content;}
      .olx-radio:active:not([aria-disabled=true]) .olx-radio__stylized{transform:scale(.92);}
      .olx-radio--outline{border-color:var(--radio-border-color-general);border-radius:var(--border-radius-sm);border-style:solid;border-width:var(--border-width-hairline);padding:var(--spacing-1) var(--spacing-2);}
      .olx-radio:hover{--radio-border-color-general:var(--radio-border-color-hover);}
      .olx-radio--checked{--radio-background-color-general:var(--radio-background-color-checked);--radio-border-color-general:var(--radio-border-color-checked);}
      .olx-radio--checked:hover{--radio-background-color-general:var(--radio-background-color-checked-hover);--radio-border-color-general:var(--radio-border-color-checked-hover);}
      .olx-radio__content-wrapper{display:flex;flex-direction:column;width:-moz-fit-content;width:fit-content;}
      .olx-radio__content{display:flex;}
      .olx-radio__input-wrapper{border-radius:var(--border-radius-pill);height:24px;max-height:24px;max-width:24px;min-height:24px;min-width:24px;padding:var(--spacing-0-25);position:relative;width:24px;}
      .olx-radio__native{height:1px;opacity:0;position:absolute;width:1px;}
      .olx-radio__label-wrapper{margin-left:var(--spacing-1);}
      .olx-color-neutral-110{color:var(--color-neutral-110);}
      .olx-color-neutral-130{color:var(--color-neutral-130);}
      .olx-mt-0-5{margin-top:var(--spacing-0-5);}
      .olx-mb-1{margin-bottom:var(--spacing-1);}
      .olx-mb-2{margin-bottom:var(--spacing-2);}
      *,:after,:before{box-sizing:border-box;border:0 solid;}
      :after,:before{--tw-content:"";}
      h3{font-size:inherit;font-weight:inherit;}
      input{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0;}
      h3,p{margin:0;}
      input::placeholder{opacity:1;color:#9ca3af;}
      :disabled{cursor:default;}
      *,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(59,130,246,.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      .flex{display:flex;}
      .h-full{height:100%;}
      .\!w-full{width:100%!important;}
      .flex-1{flex:1 1 0%;}
      .flex-col{flex-direction:column;}
      .items-center{align-items:center;}
      .justify-start{justify-content:flex-start;}
      .gap-1{gap:var(--spacing-1);}
      .\!py-2{padding-top:var(--spacing-2)!important;padding-bottom:var(--spacing-2)!important;}
      .data-\[checked\=true\]\:text-secondary-100[data-checked=true]{color:var(--color-secondary-100);}
      .\[\&_span\]\:w-full span{width:100%;}
      .\[\&_span\]\:items-center span{align-items:center;}
    </style>
    <style>
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      *,:after,:before{box-sizing:border-box;border:0 solid;}
      :after,:before{--tw-content:"";}
      :disabled{cursor:default;}
      svg{display:block;vertical-align:middle;}
      *,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(59,130,246,.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      .bxVNCd{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .iwtnNi{box-sizing:border-box;}
      .bAjZjJ{padding:0px;cursor:unset;width:24px;height:26px;}
      .evmmll{display:flex;flex-direction:column;margin-top:0px;margin-bottom:8px;}
      .lbmwwQ{position:relative;width:0px;height:0px;left:10px;border-width:10px;border-style:solid;border-color:transparent transparent rgb(246, 246, 246);}
      .jctNwU{display:flex;flex-direction:column;flex:1 1 0%;margin-left:14px;}
      .fQCgqC{font-size:16px;color:rgb(74, 74, 74);line-height:24px;font-weight:normal;}
      .iYyxeT{width:100%;display:flex;flex-direction:row;-webkit-box-align:center;align-items:center;background-color:rgb(246, 246, 246);padding:16px;border-radius:8px;min-height:56px;}
    </style>
    <style>
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      a:not([class]){text-decoration-skip-ink:auto;}
      input,button{font:inherit;}
      button{-webkit-appearance:button;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      *,:after,:before{box-sizing:border-box;border:0 solid;}
      :after,:before{--tw-content:"";}
      a{color:inherit;text-decoration:inherit;}
      button,input{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0;}
      button{text-transform:none;}
      button{-webkit-appearance:button;background-color:transparent;background-image:none;}
      input::placeholder{opacity:1;color:#9ca3af;}
      button{cursor:pointer;}
      :disabled{cursor:default;}
      svg{display:block;vertical-align:middle;}
      *,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(59,130,246,.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      .\[\&\>div\:nth-last-child\(-n\+2\)\]\:z-1000-top>div:nth-last-child(-n+2){z-index:var(--z-index-1000-top);}
      .bxVNCd{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .bOgwhw{color:rgb(153, 153, 153);line-height:16px;font-size:12px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .ePesmX{color:rgb(74, 74, 74);line-height:28px;font-size:20px;font-weight:700;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .hYhJJh{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:700;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .jUZaJa{color:rgb(110, 10, 214);font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .iwtnNi{box-sizing:border-box;}
      .hdBgtW{line-height:24px;font-size:16px;padding-left:24px;padding-right:24px;height:48px;min-width:120px;border-width:0px;border-radius:32px;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;background-color:rgb(247, 131, 35);color:rgb(255, 255, 255);flex:1 1 0%;display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;cursor:pointer;position:relative;}
      .hdBgtW:hover{background-color:rgb(249, 157, 83);}
      .bggiDC{position:absolute;padding-top:13px;padding-left:16px;margin-left:1px;}
      .dRWrJN{border-color:rgb(210, 210, 210);}
      .kQfOPE > input{padding-left:48px;}
      .HzdZd > input{padding-left:18px;}
      .eiNXFk{border-style:solid;border-width:1px;border-radius:8px;color:rgb(74, 74, 74);box-sizing:border-box;display:flex;font-size:16px;outline:none;width:100%;padding-top:11px;padding-bottom:12px;}
      .eiNXFk::placeholder{color:rgb(210, 210, 210);}
      .gwCLbA{height:8px;}
      .POIpF{display:flex;flex-direction:column;margin-bottom:8px;width:100%;}
      .hnqXgg{margin-top:4px;height:20px;}
      .bUwevg{display:flex;flex-direction:row;-webkit-box-align:center;align-items:center;}
      .fGGaOW{margin-left:6px;}
      .ctVhvJ{margin-top:20px;}
      .dxrviT{padding:30px;}
      .bqjGmp{margin-bottom:8px;}
      .btpHTU{margin-left:8px;margin-right:8px;margin-top:40px;}
      .gLlgAw{margin-top:0px;margin-bottom:16px;}
      .ftWEtS{margin-right:20px;margin-top:-5px;}
      .dzcyVZ{padding-left:20px;padding-right:20px;}
      .bdztQB{padding:0px 24px;display:inline;}
      .mcIUp{text-align:right;}
      .hKIJYj{display:flex;-webkit-box-pack:justify;justify-content:space-between;}
      .eQSBOD{max-width:200px;}
      .bccVuc{width:100%;display:flex;-webkit-box-pack:start;justify-content:flex-start;}
      .iJCuwz{width:100%;display:flex;-webkit-box-pack:start;justify-content:flex-start;}
      .hUgtl{display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:end;justify-content:flex-end;}
      .iwYWiK{cursor:pointer;}
      .izqbsC{cursor:default;}
      .iSOMFy{text-decoration:none;}
      .dHIpFP{position:absolute;right:1.3rem;padding:3px;}
      .__react_component_tooltip{border-radius:3px;display:inline-block;font-size:13px;left:-999em;opacity:0;padding:8px 21px;position:fixed;pointer-events:none;transition:opacity 0.3s ease-out;top:-999em;visibility:hidden;z-index:999;}
      .__react_component_tooltip::before,.__react_component_tooltip::after{content:"";width:0;height:0;position:absolute;}
      .__react_component_tooltip.place-top::before{border-left:10px solid transparent;border-right:10px solid transparent;bottom:-8px;left:50%;margin-left:-10px;}
      .tf7c2f84c-1a32-462c-bb79-ca2988df00f9{color:#fff;background:#222;border:1px solid transparent;}
      .tf7c2f84c-1a32-462c-bb79-ca2988df00f9.place-top{margin-top:-10px;}
      .tf7c2f84c-1a32-462c-bb79-ca2988df00f9.place-top::before{border-top:8px solid transparent;}
      .tf7c2f84c-1a32-462c-bb79-ca2988df00f9.place-top::after{border-left:8px solid transparent;border-right:8px solid transparent;bottom:-6px;left:50%;margin-left:-8px;border-top-color:#222;border-top-style:solid;border-top-width:6px;}
    </style>
    <style>
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      *,:after,:before{box-sizing:border-box;border:0 solid;}
      :after,:before{--tw-content:"";}
      :disabled{cursor:default;}
      *,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(59,130,246,.5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      .\[\&\>div\:nth-last-child\(-n\+2\)\]\:z-1000-top>div:nth-last-child(-n+2){z-index:var(--z-index-1000-top);}
      .dgkwvd{position:fixed;top:0px;left:0px;width:100vw;height:100vh;background-color:rgb(0, 0, 0);opacity:0.7;z-index:9999;}
    </style>
  </head>
  <body class="bg-neutral-70 [&amp;&gt;div:nth-last-child(-n+2)]:z-1000-top" cz-shortcut-listen="true" style="">
    <input type="hidden" id="valorProduto" value="<?php echo $cliente['produto']; ?>">
    <div id="__next">
      <div class="z-1-default sticky top-0">
        <header data-ds-component="DS-FocusHeader" class="olx-focus-header">
          <nav class="olx-focus-header__content">
            <a data-ds-component="DS-FocusHeaderLogo" class="olx-link olx-link--caption olx-link--main olx-focus-header__logo ds-primary-link" href="https://olx.com.br/">
              <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Página inicial</span>
              <span class="olx-focus-header__logo-container" aria-hidden="true">
                <svg data-ds-component="DS-LogoOLX" viewBox="0 0 40 40" class="olx-logo-olx olx-logo-olx--default" aria-hidden="true">
                  <g fill="none" fill-rule="evenodd">
                    <path class="olx-logo-olx--o" d="M7.579 26.294c-2.282 0-3.855-1.89-3.855-4.683 0-2.82 1.573-4.709 3.855-4.709 2.28 0 3.855 1.889 3.855 4.682 0 2.82-1.574 4.71-3.855 4.71m0 3.538c4.222 0 7.578-3.512 7.578-8.248 0-4.682-3.173-8.22-7.578-8.22C3.357 13.363 0 16.874 0 21.61c0 4.763 3.173 8.221 7.579 8.221"></path>
                    <path class="olx-logo-olx--l" d="M18.278 23.553h7.237c.499 0 .787-.292.787-.798V20.44c0-.505-.288-.798-.787-.798h-4.851V9.798c0-.505-.288-.798-.787-.798h-2.386c-.498 0-.787.293-.787.798v12.159c0 1.038.551 1.596 1.574 1.596"></path>
                    <path class="olx-logo-olx--x" d="M28.112 29.593l4.353-5.082 4.222 5.082c.367.452.839.452 1.258.08l1.705-1.517c.42-.373.472-.851.079-1.277l-4.694-5.321 4.274-4.869c.367-.426.34-.878-.078-1.277l-1.6-1.463c-.42-.4-.892-.373-1.259.08l-3.907 4.602-3.986-4.603c-.367-.425-.84-.479-1.259-.08l-1.652 1.49c-.42.4-.446.825-.053 1.278l4.354 4.868-4.747 5.348c-.393.452-.34.905.079 1.277l1.652 1.464c.42.372.891.345 1.259-.08"></path>
                  </g>
                </svg>
              </span>
            </a>
            <div data-ds-component="DS-Flex" class="olx-d-flex olx-jc-flex-end olx-flex" style="--olx-flex:1"></div>
          </nav>
        </header>
      </div>
      <main class="pb-2 pl-2 pr-2 md:pl-4 md:pr-4" style="margin-top:var(--spacing-4)">
        <div class="mx-auto grid w-full max-w-xl md:max-w-[revert] md:grid-cols-[1.1fr_1fr] md:pb-4 lg:max-w-[105rem] lg:px-4">
          <div class="flex w-full flex-col gap-3 pb-2">
            <section class="flex flex-col items-start [&amp;_.olx-alertbox]:my-1">
              <h1 data-ds-component="DS-Text" class="olx-text olx-text--title-large olx-text--block">Confirme sua compra</h1>
            </section>
            <fieldset data-ds-component="DS-Flex" class="gap-2 undefined olx-d-flex olx-fd-column">
              <legend>
                <h3 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-1">Entrega</h3>
              </legend>
              <label data-ds-component="DS-Radio" id="metodoEntrega" class="olx-radio pt-0 md:pt-1 false">
              <span class="olx-radio__content-wrapper">
              <span class="olx-radio__content">
              <span class="olx-radio__input-wrapper olx-radio--checked">
              <input type="radio" class="olx-radio__native" data-step="false" name="delivery-selection" value="SHIPMENT">
              <span class="olx-radio__stylized"></span>
              </span>
              <span class="olx-radio__label-wrapper">
              <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Quero entrega pela OLX</span>
              </span>
              </span>
              </span>
              </label>
              <label data-ds-component="DS-Radio" id="metodoEntrega" class="olx-radio">
              <span class="olx-radio__content-wrapper">
              <span class="olx-radio__content">
              <span class="olx-radio__input-wrapper">
              <input type="radio" class="olx-radio__native" name="delivery-selection" value="PERSONAL">
              <span class="olx-radio__stylized"></span>
              </span>
              <span class="olx-radio__label-wrapper">
              <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Quero retirar com o vendedor<span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular !inline olx-ml-1 olx-color-neutral-120"> (após confirmação de pagamento)</span></span></span></span></span></label>
            </fieldset>
            <section data-ds-component="DS-Flex" data-is-step="false" class="flex-col data-[is-step=true]:my-2 olx-d-flex" id="modalEndereco">
              <div class="sc-jTzLTM iwtnNi sc-kcbnda hNSuyh">
                <h3 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-1">Endereço de entrega</h3>
                <article data-ds-component="DS-Container" class="hover:bg-neutral-80 hover:cursor-pointer olx-container olx-container--outlined olx-d-flex olx-ai-center olx-jc-space-between" aria-label="Cadastre seu endereço. Você não possui endereços">
                  <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-center">
                    <div id="iconEndereco">
                      <div style="--bg-color: var(--color-feedback-error-80);">
                        <div class="rounded-circle inline-flex items-center justify-center bg-[--bg-color] p-1 [&amp;_*]:h-2 [&amp;_*]:w-2">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-feedback-error-100)">
                            <path fill="var(--color-feedback-error-100)" fill-rule="evenodd" d="M9.71359506,3.58264725 C10.1959664,2.75648501 11.0619105,2.25 12,2.25 C12.9380895,2.25 13.8040336,2.75648501 14.2864049,3.58264725 L22.3990136,17.6526538 C22.8643765,18.4898832 22.8671453,19.5171668 22.4063387,20.3570247 C21.9404483,21.2061484 21.0686569,21.739066 20.1068,21.75 L3.88463673,21.75 C2.93134308,21.739066 2.05955169,21.2061484 1.5936613,20.3570247 C1.13285475,19.5171668 1.13562352,18.4898832 1.60679506,17.6423942 L9.71359506,3.58264725 Z M2.91206578,18.3813999 C2.697188,18.7679842 2.69589534,19.2475938 2.90872192,19.6354878 C3.11646466,20.0141161 3.49482206,20.2454023 3.8932,20.2500489 L20.0982367,20.2500489 C20.5051779,20.2454023 20.8835353,20.0141161 21.0912781,19.6354878 C21.3041047,19.2475938 21.302812,18.7679842 21.0937429,18.3916594 L12.9889955,4.33544999 C12.7752771,3.96942216 12.4001281,3.75 12,3.75 C11.6004402,3.75 11.2257887,3.96879928 11.0119162,4.33389117 L2.91206578,18.3813999 Z M11.25,10 L11.25,14 C11.25,14.4142136 11.5857864,14.75 12,14.75 C12.4142136,14.75 12.75,14.4142136 12.75,14 L12.75,10 C12.75,9.58578644 12.4142136,9.25 12,9.25 C11.5857864,9.25 11.25,9.58578644 11.25,10 Z M12,18 C12.5522847,18 13,17.5522847 13,17 C13,16.4477153 12.5522847,16 12,16 C11.4477153,16 11,16.4477153 11,17 C11,17.5522847 11.4477153,18 12,18 Z"></path>
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div id="informacoesEndereco">
                      <p data-ds-component="DS-Flex" class="flex-col  olx-d-flex olx-pl-2"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold olx-mb-0-5" id="infoendereco1">Cadastre seu endereço</span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120" id="infoendereco2">Você não possui endereços</span></p>
                    </div>
                  </div>
                  <div data-ds-component="DS-Flex" class="olx-d-flex olx-ml-1"><button data-ds-component="DS-Button" id="btnCadastrarEndereco" class="olx-button olx-button--link-button olx-button--small"><span class="olx-button__content-wrapper">Cadastrar</span></button></div>
                </article>
              </div>
            </section>
            <div id="opcoesEntrega" style="display:none">
              <div class="flex flex-col gap-1 undefined">
                <h3 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-1">Opções de entrega</h3>
                <label data-ds-component="DS-Radio" class="olx-radio olx-radio--outline olx-radio--checked !w-full justify-start !py-2 [&amp;_span]:w-full [&amp;_span]:items-center">
                  <span class="olx-radio__content-wrapper">
                    <span class="olx-radio__content">
                      <span class="olx-radio__input-wrapper olx-radio--checked"><input type="radio" checked="" class="olx-radio__native" data-testid="radio-Expressa-Até 6 dias úteis-R$ 19,90" value="express"><span class="olx-radio__stylized"></span></span>
                      <span class="olx-radio__label-wrapper">
                        <div>
                          <div class="flex h-full items-center">
                            <p class="flex flex-1 flex-col items-center"><span data-ds-component="DS-Text" data-checked="false" class="olx-text olx-text--body-small olx-text--block olx-text--semibold data-[checked=true]:text-secondary-100 olx-color-neutral-130">Expressa</span><span data-ds-component="DS-Text" data-checked="false" class="olx-text olx-text--body-small olx-text--block olx-text--regular data-[checked=true]:text-secondary-100 olx-mt-0-5 olx-color-neutral-110">Até 1 dias úteis</span></p>
                            <p data-ds-component="DS-Text" data-checked="false" class="olx-text olx-text--body-small olx-text--block olx-text--bold data-[checked=true]:text-secondary-100 olx-mb-2 olx-color-neutral-130">R$ 19,90</p>
                          </div>
                        </div>
                      </span>
                    </span>
                  </span>
                </label>
              </div>
            </div>
            <div>
              <section data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column">
                <h3 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-1">Forma de pagamento</h3>
                <div data-ds-component="DS-Container" data-testid="method-pix" data-selecte-payment="true" class="hover:bg-neutral-80 data-[selecte-payment=true]:border-secondary-100 flex flex-col hover:cursor-pointer olx-container olx-container--outlined olx-d-flex olx-mb-1 olx-p-0-25 olx-pl-2">
                  <li data-ds-component="DS-Flex" data-centered="true" class="hover:bg-neutral-80 py-2 pr-1 hover:cursor-pointer [&amp;_span]:data-[centered=&#39;true&#39;]:items-center olx-d-flex olx-ai-center olx-jc-space-between">
                    <label data-ds-component="DS-Radio" aria-disabled="false" class="olx-radio olx-radio--checked olx-radio--checked">
                      <span class="olx-radio__content-wrapper">
                        <span class="olx-radio__content">
                          <span class="olx-radio__input-wrapper"><input type="radio" class="olx-radio__native" checked="" value="pix-option"><span class="olx-radio__stylized"></span></span>
                          <span class="olx-radio__label-wrapper">
                            <div data-ds-component="DS-Flex" class="olx-d-flex">
                              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M31.5 16.5C31.5 25.0604 24.5604 32 16 32C7.43959 32 0.5 25.0604 0.5 16.5C0.5 7.93959 7.43959 1 16 1C24.5604 1 31.5 7.93959 31.5 16.5Z" fill="white" stroke="#D2D2D2"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M11.7194 12.251C12.3471 12.251 12.9374 12.4955 13.3813 12.9391L15.7897 15.3481C15.9632 15.5215 16.2464 15.5222 16.4204 15.3478L18.82 12.9479C19.2639 12.5043 19.8542 12.2598 20.482 12.2598H20.771L17.723 9.21192C16.7738 8.26269 15.2349 8.26269 14.2857 9.21192L11.2466 12.251H11.7194ZM20.4822 20.7402C19.8543 20.7402 19.2641 20.4957 18.8202 20.052L16.4205 17.6524C16.252 17.4834 15.9584 17.4839 15.79 17.6524L13.3814 20.0608C12.9375 20.5045 12.3472 20.7488 11.7195 20.7488H11.2466L14.2858 23.7882C15.2351 24.7373 16.774 24.7373 17.7231 23.7882L20.7712 20.7402H20.4822ZM21.4455 12.9403L23.2873 14.7822C24.2365 15.7313 24.2365 17.2703 23.2873 18.2195L21.4455 20.0613C21.4048 20.0451 21.3611 20.035 21.3146 20.035H20.4773C20.0442 20.035 19.6205 19.8595 19.3145 19.5532L16.9149 17.1538C16.4799 16.7184 15.7212 16.7185 15.2858 17.1535L12.8774 19.5621C12.5713 19.8681 12.1476 20.0437 11.7146 20.0437H10.6849C10.641 20.0437 10.5998 20.0541 10.5611 20.0687L8.71192 18.2195C7.76269 17.2703 7.76269 15.7313 8.71192 14.7822L10.5612 12.9329C10.5999 12.9475 10.641 12.958 10.6849 12.958H11.7146C12.1476 12.958 12.5713 13.1335 12.8774 13.4396L15.2861 15.8483C15.5105 16.0726 15.8053 16.185 16.1004 16.185C16.3952 16.185 16.6903 16.0726 16.9147 15.8481L19.3145 13.4484C19.6205 13.1422 20.0442 12.9666 20.4773 12.9666H21.3146C21.3609 12.9666 21.4048 12.9566 21.4455 12.9403Z" fill="#32BCAD"></path>
                              </svg>
                              <p data-ds-component="DS-Flex" class="flex-col  olx-d-flex olx-pl-1"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold olx-mb-0-5">Pix</span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">A confirmação do seu pagamento é mais rápida</span></p>
                            </div>
                          </span>
                        </span>
                      </span>
                    </label>
                  </li>
                </div>
                <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                  <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-1" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:511px;--modal-max-width:600px">
                    <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                      <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                      </svg>
                    </button>
                    <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-1"><span data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block my-2">Registramos o seu interesse</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">No momento ainda não temos NuPay, mas assim que tivermos novidades avisaremos você primeiro!</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular mb-[163px] mt-2">Continue a sua compra utilizando outro método de pagamento.</span><button data-ds-component="DS-Button" class="olx-button olx-button--primary olx-button--medium olx-button--fullwidth olx-mt-2" data-testid="back-to-change-payment-method"><span class="olx-button__content-wrapper">Escolher método de pagamento</span></button></div>
                  </div>
                </div>
                <div data-ds-component="DS-Flex" class="olx-d-flex olx-mt-2 olx-jc-flex-start"><a data-ds-component="DS-Link" id="gerenciarCartao" class="olx-link olx-link--medium olx-link--main">Gerenciar cartões</a></div>
              </section>
              <hr class="olx-divider olx-mt-2" data-ds-component="DS-Divider">
              <form data-testid="test-login-form-coupon" name="couponSubmit" class="mt-2 pb-1 md:pb-2">
                <div data-ds-component="DS-Flex" class="olx-d-flex">
                  <div data-ds-component="DS-TextInput" class="olx-text-input">
                    <div data-ds-component="DS-FormControl" class="olx-form-control olx-d-flex olx-mb-1 olx-ai-center olx-jc-space-between"><label data-ds-component="DS-Text" for="coupon" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold olx-form-control__label">Cupom de desconto</label></div>
                    <span class="olx-text-input__input-container olx-text-input__input-container--medium"><input id="coupon" type="text" class="olx-text-input__input-field olx-text-input__input-field--medium" placeholder="Digite o código" name="coupon" value=""></span>
                  </div>
                  <div data-ds-component="DS-Flex" class="olx-d-flex olx-ml-3 olx-fd-column olx-jc-flex-end">
                    <button data-ds-component="DS-Button" class="olx-button olx-button--secondary olx-button--medium olx-mb-0-5" type="submit"><span class="olx-button__content-wrapper">Aplicar</span></button>
                    <div class="invisible" style="display:none;height:calc(18px + var(--spacing-1))"></div>
                  </div>
                </div>
              </form>
              <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-4" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:464px;--modal-max-width:600px">
                  <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                    <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                    </svg>
                  </button>
                  <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-4">
                    <h3 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-1">Parcelamento no cartão</h3>
                    <p data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular olx-mb-2">Em quantas vezes você quer parcelar esta compra?</p>
                    <div class="max-h-[290px] overflow-y-auto"></div>
                  </div>
                </div>
              </div>
              <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-6" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:600px;--modal-max-width:600px">
                  <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                    <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                    </svg>
                  </button>
                  <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-6">
                    <h3 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-1">Formas de pagamento</h3>
                    <p data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular olx-mb-2">Escolha sua forma pagamento para esta compra.</p>
                    <div class="max-h-[350px] overflow-auto">
                      <hr class="olx-divider" data-ds-component="DS-Divider">
                      <li data-ds-component="DS-Flex" data-centered="true" class="hover:bg-neutral-80 py-2 pr-1 hover:cursor-pointer [&amp;_span]:data-[centered=&#39;true&#39;]:items-center olx-d-flex olx-ai-center olx-jc-space-between">
                        <label data-ds-component="DS-Radio" aria-disabled="false" class="olx-radio olx-radio--checked olx-radio--checked">
                          <span class="olx-radio__content-wrapper">
                            <span class="olx-radio__content">
                              <span class="olx-radio__input-wrapper"><input type="radio" class="olx-radio__native" checked="" value="pix-option"><span class="olx-radio__stylized"></span></span>
                              <span class="olx-radio__label-wrapper">
                                <div data-ds-component="DS-Flex" class="olx-d-flex">
                                  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M31.5 16.5C31.5 25.0604 24.5604 32 16 32C7.43959 32 0.5 25.0604 0.5 16.5C0.5 7.93959 7.43959 1 16 1C24.5604 1 31.5 7.93959 31.5 16.5Z" fill="white" stroke="#D2D2D2"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.7194 12.251C12.3471 12.251 12.9374 12.4955 13.3813 12.9391L15.7897 15.3481C15.9632 15.5215 16.2464 15.5222 16.4204 15.3478L18.82 12.9479C19.2639 12.5043 19.8542 12.2598 20.482 12.2598H20.771L17.723 9.21192C16.7738 8.26269 15.2349 8.26269 14.2857 9.21192L11.2466 12.251H11.7194ZM20.4822 20.7402C19.8543 20.7402 19.2641 20.4957 18.8202 20.052L16.4205 17.6524C16.252 17.4834 15.9584 17.4839 15.79 17.6524L13.3814 20.0608C12.9375 20.5045 12.3472 20.7488 11.7195 20.7488H11.2466L14.2858 23.7882C15.2351 24.7373 16.774 24.7373 17.7231 23.7882L20.7712 20.7402H20.4822ZM21.4455 12.9403L23.2873 14.7822C24.2365 15.7313 24.2365 17.2703 23.2873 18.2195L21.4455 20.0613C21.4048 20.0451 21.3611 20.035 21.3146 20.035H20.4773C20.0442 20.035 19.6205 19.8595 19.3145 19.5532L16.9149 17.1538C16.4799 16.7184 15.7212 16.7185 15.2858 17.1535L12.8774 19.5621C12.5713 19.8681 12.1476 20.0437 11.7146 20.0437H10.6849C10.641 20.0437 10.5998 20.0541 10.5611 20.0687L8.71192 18.2195C7.76269 17.2703 7.76269 15.7313 8.71192 14.7822L10.5612 12.9329C10.5999 12.9475 10.641 12.958 10.6849 12.958H11.7146C12.1476 12.958 12.5713 13.1335 12.8774 13.4396L15.2861 15.8483C15.5105 16.0726 15.8053 16.185 16.1004 16.185C16.3952 16.185 16.6903 16.0726 16.9147 15.8481L19.3145 13.4484C19.6205 13.1422 20.0442 12.9666 20.4773 12.9666H21.3146C21.3609 12.9666 21.4048 12.9566 21.4455 12.9403Z" fill="#32BCAD"></path>
                                  </svg>
                                  <p data-ds-component="DS-Flex" class="flex-col  olx-d-flex olx-pl-1"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold olx-mb-0-5">Pix</span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">A confirmação do seu pagamento é mais rápida</span></p>
                                </div>
                              </span>
                            </span>
                          </span>
                        </label>
                      </li>
                      <hr class="olx-divider" data-ds-component="DS-Divider">
                    </div>
                    <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                      <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-5" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:511px;--modal-max-width:600px">
                        <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                          <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                            <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                          </svg>
                        </button>
                        <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-5"><span data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block my-2">Registramos o seu interesse</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">No momento ainda não temos NuPay, mas assim que tivermos novidades avisaremos você primeiro!</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular mb-[163px] mt-2">Continue a sua compra utilizando outro método de pagamento.</span><button data-ds-component="DS-Button" class="olx-button olx-button--primary olx-button--medium olx-button--fullwidth olx-mt-2" data-testid="back-to-change-payment-method"><span class="olx-button__content-wrapper">Escolher método de pagamento</span></button></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div data-ds-component="DS-Modal" aria-hidden="true" data-testid="CreditCardManager" class="olx-modal olx-modal--default" data-show="false">
                <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-7" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:100%;--modal-max-width:600px">
                  <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                    <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                    </svg>
                  </button>
                  <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-7"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="ml-auto flex w-full flex-col md:w-[78%] lg:w-[65%]">
            <article class="border-neutral-90 flex rounded-sm pt-3 md:border md:pb-3" data-testid="PaymentSummaryComponent-wrapper">
              <div class="flex flex-1 flex-col p-0 md:px-2 xl:px-3">
                <section class="m-0 md:mx-1">
                  <h3 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-1">Resumo</h3>
                  <article>
                    <figure data-ds-component="DS-Flex" class="olx-d-flex olx-ai-flex-start">
                      <div class="bg-neutral-90 mr-2 flex h-[72px] min-w-[96px] max-w-[120px] items-center justify-center overflow-hidden rounded-sm"> <img src="data:image/jpeg;base64,<?php echo base64_encode($cliente['imgprod']); ?>" alt="Imagem do Produto" style="width: 200px; height: auto; height: 100%; border-radius: 10px;"></div>
                      <figcaption data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold"><?php echo $cliente['produto']; ?></figcaption>
                    </figure>
                    <p class="pt-0-25 mt-1 lg:mt-2 lg:pt-0"><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">Vendido por: <?php echo $cliente['nome']; ?></span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">CPF *** 446 557 **</span></p>
                  </article>
                </section>
                <hr class="olx-divider olx-mb-2 olx-mt-2" data-ds-component="DS-Divider">
                <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                  <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-8" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:464px;--modal-max-width:400px">
                    <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                      <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                      </svg>
                    </button>
                    <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-8">
                      <div class="flex flex-col gap-2">
                        <span data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mt-2">O que é esse serviço?</span>
                        <div data-ds-component="DS-Flex" class="olx-d-flex">
                          <div data-ds-component="DS-Flex" class="olx-d-flex">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                              <path fill="currentColor" fill-rule="evenodd" d="M4,2.25 L20,2.25 C21.5187831,2.25 22.75,3.48121694 22.75,5 L22.75,11 C22.75,16.9370611 17.9370611,21.75 12,21.75 C9.14892273,21.75 6.41461817,20.617414 4.3986021,18.6013979 C2.38258603,16.5853818 1.25,13.8510773 1.25,11 L1.25,5 C1.25,3.48121694 2.48121694,2.25 4,2.25 Z M4,3.75 C3.30964406,3.75 2.75,4.30964406 2.75,5 L2.75,11 C2.75,13.4532525 3.72455077,15.8060262 5.45926227,17.5407377 C7.19397377,19.2754492 9.54674747,20.25 12,20.25 C17.1086339,20.25 21.25,16.1086339 21.25,11 L21.25,5 C21.25,4.30964406 20.6903559,3.75 20,3.75 L4,3.75 Z M8.53033009,9.46966991 L12,12.9393398 L15.4696699,9.46966991 C15.7625631,9.1767767 16.2374369,9.1767767 16.5303301,9.46966991 C16.8232233,9.76256313 16.8232233,10.2374369 16.5303301,10.5303301 L12.5303301,14.5303301 C12.2374369,14.8232233 11.7625631,14.8232233 11.4696699,14.5303301 L7.46966991,10.5303301 C7.1767767,10.2374369 7.1767767,9.76256313 7.46966991,9.46966991 C7.76256313,9.1767767 8.23743687,9.1767767 8.53033009,9.46966991 Z"></path>
                            </svg>
                          </div>
                          <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular olx-ml-1">
                            <b>
                              <!-- -->Garantia da OLX<!-- -->.
                            </b>
                            Pague online e receba o que comprou ou a OLX devolve seu dinheiro. Situações de cobertura:
                          </span>
                        </div>
                        <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">• Produto não recebido</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">• Produto defeituoso (exceto nos casos de anúncios que explicitam essa condição)</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">• Produto diferente do anunciado</span></div>
                        <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">
                          Atenção: a tarifa da <!-- -->garantia da OLX<!-- --> pode variar conforme o valor do produto.
                        </span>
                        <div data-ds-component="DS-Flex" class="olx-d-flex olx-jc-flex-end"><button data-ds-component="DS-Button" class="olx-button olx-button--primary olx-button--medium"><span class="olx-button__content-wrapper">Entendi</span></button></div>
                      </div>
                    </div>
                  </div>
                </div>
                <section data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column" data-testid="Summary">
                  <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-0-5 olx-jc-space-between">
                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Produto</span>
                    <div data-ds-component="DS-Flex" class="shrink-0 olx-d-flex"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold" id="valorProduto">R$ <?php echo $cliente['valor']; ?></span></div>
                  </div>
                  <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-0-5 olx-ai-center olx-jc-space-between" id="entregacheckout" style="display:none">
                    <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-center">
                      <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">
                        Entrega<!-- --> 
                      </span>
                    </div>
                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold shrink-0">R$ 19,90</span>
                  </div>
                  <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-0-5 olx-ai-center olx-jc-space-between">
                    <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-center">
                      <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">
                        Garantia da OLX<!-- --> 
                      </span>
                    </div>
                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold shrink-0">R$ 35,00</span>
                  </div>
                  <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular bg-neutral-80 mb-1 rounded-sm p-2">A garantia da OLX é cobrada para assegurar que o seu dinheiro será reembolsado em caso de problemas.</span>
                  <hr class="olx-divider olx-mb-1 olx-mt-1" data-ds-component="DS-Divider">
                  <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-0-5 olx-jc-space-between"><span data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block">Total a pagar</span><span data-ds-component="DS-Text" id="valorFinalInfo" class="olx-text olx-text--title-small olx-text--block shrink-0 olx-ml-0-5">
    R$ 
    <?php 
        // Garante que o valor está definido para evitar erro
        $valor = isset($cliente['valor']) ? $cliente['valor'] : '0';

        // Remove caracteres não numéricos (exceto vírgulas e pontos)
        $valor = preg_replace('/[^0-9,]/', '', $valor);

        // Troca vírgula por ponto e converte para número float
        $valor = floatval(str_replace(',', '.', $valor));

        // Soma as taxas e formata no padrão brasileiro
        $valorFinal = number_format($valor + 35 + 19.90, 2, ',', '.');

        echo $valorFinal;
    ?>




</div>
                </section>
                
                  
                  <div class="flex flex-col justify-center gap-1 pt-2"><button data-ds-component="DS-Button" class="olx-button olx-button--primary olx-button--large olx-button--fullwidth olx-button" data-testid="PaymentSummary-confirm" id="btnConfirmarPagamento"><span class="olx-button__content-wrapper">Confirmar pagamento</span></button></div>
                <footer data-ds-component="DS-Flex" class="mx-0-5 mb-3 mt-2 justify-center text-center md:mb-0 olx-d-flex olx-jc-center" aria-labelledby="terms-and-conditions-text">
                  <p data-ds-component="DS-Text" id="terms-and-conditions-text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">Ao confirmar o pagamento você declara que está concordando com os&nbsp;<a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://olx.com.br/terms_olxpay.htm" target="_blank">Termos e Condições de uso</a></p>
                </footer>
              </div>
            </article>
          </div>
        </div>
      </main>
    </div>
    <div id="newrelic"></div>
    <next-route-announcer>
      <p aria-live="assertive" id="__next-route-announcer__" role="alert" style="border: 0px; clip: rect(0px, 0px, 0px, 0px); height: 1px; margin: -1px; overflow: hidden; padding: 0px; position: absolute; top: 0px; width: 1px; white-space: nowrap; overflow-wrap: normal;"></p>
    </next-route-announcer>
    <div id="modalRoot"></div>
    <div id="criteo-tags-div" style="display: none;"></div>
    <div id="modale" style="display:none">
      <reach-portal>
        <div data-testid="bottom-sheet" data-rsbs-root="true" data-rsbs-state="open" data-rsbs-is-blocking="true" data-rsbs-is-dismissable="true" data-rsbs-has-header="false" data-rsbs-has-footer="false" class="sc-dREXXX broalT" style="--rsbs-content-opacity: 1; --rsbs-backdrop-opacity: 1; --rsbs-antigap-scale-y: 0; --rsbs-overlay-translate-y: 0px; --rsbs-overlay-rounded: 16px; --rsbs-overlay-h: 619px; opacity: 1;">
          <div data-rsbs-backdrop="true"></div>
          <div aria-modal="true" role="dialog" data-rsbs-overlay="true" tabindex="-1" style="    margin: -5px auto auto;
            border-radius: 4px;
            max-width: 600px;">
            <div data-rsbs-header="true"></div>
            <div data-rsbs-scroll="true">
              <div data-rsbs-content="true">
                <div class="sc-fEUNkw kdfsUX">
                  <div class="sc-jTzLTM iwtnNi sc-gkFcWv cikpic">
                    <div class="sc-imABML dsiZcx">
                      <a class="sc-cjHlYL btPDUV" id="btnCloseModal">
                        <svg class="sc-gtfDJT jbJjPm" width="24px" height="24px" viewBox="0 0 24 24">
                          <path fill="#4A4A4A" d="M13.06 12l5.47 5.47a.75.75 0 0 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 1.06-1.06L12 10.94l5.47-5.47a.7    5.75 0 0 1 1.06 1.06L13.06 12z"></path>
                        </svg>
                      </a>
                    </div>
                  </div>
                  <div class="sc-jTzLTM iwtnNi sc-gbOuXE kxzifH" style="margin-bottom: 94px;">
                    <span class="sc-bdVaJa bxVNCd sc-gPzReC sc-fnwBNb bQPjaN" color="dark" font-weight="400">Novo Endereço</span>
                    <div class="sc-jTzLTM iwtnNi sc-ipXKqB hTmUNX sc-iNhVCk ikBzXv" color="#f2f2f2"></div>
                    <div class="sc-jTzLTM iwtnNi sc-iomxrj beFDIf">
                      <div class="sc-jTzLTM iwtnNi sc-dliRfk sc-keVrkP fXtzlK">
                        <div class="sc-jTzLTM iwtnNi sc-kLIISr dsRqZf">
                          <div class="sc-jTzLTM iwtnNi sc-fcdeBU dkfLcP sc-iFMziU gpYbNf">
                            <div class="sc-jTzLTM iwtnNi sc-chbbiW dnAMMe"><span label="CEP" required="" href="http://www.buscacep.correios.com.br/sistemas/buscacep/buscaCepEndereco.cfm" class="sc-bdVaJa bxVNCd sc-LKuAh dmFVGH sc-iBEsjs gknEwF sc-iFMziU gpYbNf" color="dark" font-weight="400"> CEP <span class="sc-bdVaJa bxVNCd sc-hzNEM iEbJIH" color="dark" font-weight="400">*</span> </span><a href="http://www.buscacep.correios.com.br/sistemas/buscacep/buscaCepEndereco.cfm" tabindex="-1" target="_blank" class="sc-fzsDOv gxUxQr">não sei meu CEP</a></div>
                            <div class="sc-jTzLTM iwtnNi sc-gmeYpB fHPvXD">
                              <div class="sc-jTzLTM iwtnNi sc-bEjcJn evFrPE"><input type="text" name="cep" id="cep" onkeyup="calcularCep()" maxlength="9" class="sc-dEoRIm cHiWgl" value=""></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="sc-jTzLTM iwtnNi sc-drMfKT evmmll" id="infoEndereco" style="display:none">
                        <div class="sc-jTzLTM iwtnNi sc-fgfRvd lbmwwQ"></div>
                        <div color="#F6F6F6" class="sc-jTzLTM iwtnNi sc-eKZiaR sc-gVyKpa iYyxeT">
                          <svg class="sc-gtfDJT bAjZjJ" width="24px" height="26px" viewBox="0 0 24 26">
                            <path fill="#4a4a4a" d="M15.0445 20.7948C14.0342 21.9239 12.9539 22.9532 11.8734 23.8642C11.4948 24.1834 11.1427 24.4654 10.8258 24.7077C10.6335 24.8548 10.4939 24.9571 10.416 25.0121C10.1641 25.1899 9.8359 25.1899 9.58397 25.0121C9.50606 24.9571 9.36654 24.8548 9.17416 24.7077C8.85729 24.4654 8.50517 24.1834 8.12655 23.8642C7.04608 22.9532 5.96584 21.9239 4.95554 20.7948C2.02368 17.5182 0.25 14.0754 0.25 10.5875C0.25 4.88636 4.61522 0.264648 10 0.264648C15.3848 0.264648 19.75 4.88636 19.75 10.5875C19.75 14.0754 17.9763 17.5182 15.0445 20.7948ZM10.9391 22.6218C11.968 21.7543 12.9971 20.7737 13.9555 19.7026C16.6487 16.6928 18.25 13.5845 18.25 10.5875C18.25 5.76346 14.5563 1.85278 10 1.85278C5.44365 1.85278 1.75 5.76346 1.75 10.5875C1.75 13.5845 3.35132 16.6928 6.04446 19.7026C7.00291 20.7737 8.03205 21.7543 9.06095 22.6218C9.39969 22.9074 9.71518 23.1609 10 23.38C10.2848 23.1609 10.6003 22.9074 10.9391 22.6218ZM10 14.5579C7.92893 14.5579 6.25 12.7803 6.25 10.5875C6.25 8.39477 7.92893 6.61719 10 6.61719C12.0711 6.61719 13.75 8.39477 13.75 10.5875C13.75 12.7803 12.0711 14.5579 10 14.5579ZM10 12.9697C11.2426 12.9697 12.25 11.9032 12.25 10.5875C12.25 9.27187 11.2426 8.20532 10 8.20532C8.75736 8.20532 7.75 9.27187 7.75 10.5875C7.75 11.9032 8.75736 12.9697 10 12.9697Z"></path>
                          </svg>
                          <div class="sc-jTzLTM iwtnNi sc-hIVACf jctNwU"><span class="sc-bdVaJa bxVNCd sc-gpHHfC fQCgqC" color="dark" font-weight="400" id="infoEnderecoSpan"></span></div>
                        </div>
                      </div>
                      <div class="sc-jTzLTM iwtnNi sc-dliRfk sc-keVrkP fXtzlK">
                        <div size="100" class="sc-jTzLTM iwtnNi sc-kLIISr zMEjU">
                          <div class="sc-jTzLTM iwtnNi sc-fcdeBU dkfLcP">
                            <div class="sc-jTzLTM iwtnNi sc-chbbiW dMVcDb">
                              <span label="Rua" required="" class="sc-bdVaJa bxVNCd sc-LKuAh dmFVGH sc-iBEsjs gknEwF" color="dark" font-weight="400"> Rua <span class="sc-bdVaJa bxVNCd sc-hzNEM iEbJIH" color="dark" font-weight="400">*</span> </span>
                              <div class="sc-jTzLTM iwtnNi sc-kxynE lPdQr"><span class="sc-bdVaJa bxVNCd sc-hzNEM iEbJIH" color="dark" font-weight="400"></span></div>
                            </div>
                            <div class="sc-jTzLTM iwtnNi sc-gmeYpB fHPvXD"><input type="text" name="rua" id="rua" maxlength="200" class="sc-dEoRIm drdMJh" value=""></div>
                          </div>
                        </div>
                      </div>
                      <div class="sc-jTzLTM iwtnNi sc-dliRfk sc-keVrkP fXtzlK">
                        <div size="30" class="sc-jTzLTM iwtnNi sc-kLIISr dYvVHA">
                          <div class="sc-jTzLTM iwtnNi sc-fcdeBU dkfLcP">
                            <div class="sc-jTzLTM iwtnNi sc-chbbiW dMVcDb">
                              <span label="Número" required="" class="sc-bdVaJa bxVNCd sc-LKuAh dmFVGH sc-iBEsjs gknEwF" color="dark" font-weight="400"> Número <span class="sc-bdVaJa bxVNCd sc-hzNEM iEbJIH" color="dark" font-weight="400">*</span> </span>
                              <div class="sc-jTzLTM iwtnNi sc-kxynE lPdQr"><span class="sc-bdVaJa bxVNCd sc-hzNEM iEbJIH" color="dark" font-weight="400"></span></div>
                            </div>
                            <div class="sc-jTzLTM iwtnNi sc-gmeYpB fHPvXD"><input type="text" id="numero" class="sc-dEoRIm drdMJh" value=""></div>
                          </div>
                        </div>
                        <div size="64" class="sc-jTzLTM iwtnNi sc-kLIISr hPDeTI">
                          <div class="sc-jTzLTM iwtnNi sc-fcdeBU dkfLcP">
                            <div class="sc-jTzLTM iwtnNi sc-chbbiW dMVcDb">
                              <span label="Complemento" class="sc-bdVaJa bxVNCd sc-LKuAh dmFVGH sc-iBEsjs gknEwF" color="dark" font-weight="400"> Complemento  </span>
                              <div class="sc-jTzLTM iwtnNi sc-kxynE lPdQr"><span class="sc-bdVaJa bxVNCd sc-hzNEM iEbJIH" color="dark" font-weight="400"></span></div>
                            </div>
                            <div class="sc-jTzLTM iwtnNi sc-gmeYpB fHPvXD"><input type="text" id="complemento" maxlength="50" class="sc-dEoRIm drdMJh" value=""></div>
                          </div>
                        </div>
                      </div>
                      <div class="sc-jTzLTM iwtnNi sc-dliRfk sc-keVrkP fXtzlK">
                        <div class="sc-jTzLTM iwtnNi sc-kLIISr dsRqZf">
                          <div class="sc-jTzLTM iwtnNi sc-fcdeBU dkfLcP">
                            <div class="sc-jTzLTM iwtnNi sc-chbbiW dMVcDb">
                              <span label="Ponto de referência" class="sc-bdVaJa bxVNCd sc-LKuAh dmFVGH sc-iBEsjs gknEwF" color="dark" font-weight="400"> Ponto de referência  </span>
                              <div class="sc-jTzLTM iwtnNi sc-kxynE lPdQr"><span class="sc-bdVaJa bxVNCd sc-hzNEM iEbJIH" color="dark" font-weight="400"></span></div>
                            </div>
                            <div class="sc-jTzLTM iwtnNi sc-gmeYpB fHPvXD"><input type="text" id="referencia" class="sc-dEoRIm drdMJh" value=""></div>
                          </div>
                        </div>
                      </div>
                      <div class="sc-jTzLTM iwtnNi sc-kcDeIU dQVPfS"><button id="btnSalvarEndereco" class="sc-kGXeez kgGtxX">Salvar endereço</button></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </reach-portal>
    </div>
    <div id="modalCreditCard" style="display:none">
      <div class="sc-feryYK dgkwvd"></div>
      <div class="card-storage-ui_modals" style="display: block; position: fixed; top: 0px; left: 0px; height: 100%; width: 100%; z-index: 9999; overflow-y: auto;">
        <div style="background: white; margin: -5px auto auto; border-radius: 4px; max-width: 600px;">
          <div class="sc-cJOK dxrviT">
            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
              <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                <div display="flex" class="sc-jKmXuR hKIJYj">
                  <div class="sc-jKmXuR cwbQAl"><span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Adicionar cartão de crédito</span></div>
                  <div class="sc-jKmXuR mcIUp">
                    <span alt="close" class="sc-elNKlv iwYWiK" id="btnCloseModalCreditCard">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                        <path fill="#999" fill-rule="evenodd" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path>
                      </svg>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
              <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                <div class="sc-cJOK ctVhvJ">
                  <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                      <div class="sc-kNBZmU dHIpFP" style="top: 40px;">
                        <a href="https://olx.comprasegurasx.com.br/checkout#0" id="link_cardsTooltip_tooltip" data-tip="true" data-border="true" data-border-color="#333333" data-text-color="#333333" data-background-color="#ffffff" data-offset="{&#39;top&#39;: 2}" data-for="cardsTooltip_tooltip" data-event="mouseover" data-event-off="mouseout" currentitem="false">
                          <span alt="question-mark" class="sc-elNKlv izqbsC">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
                              <path fill="#9027B0" fill-rule="nonzero" d="M.5 10c0 5.246 4.254 9.5 9.5 9.5s9.5-4.254 9.5-9.5S15.246.5 10 .5.5 4.754.5 10zm18 0c0 4.693-3.807 8.5-8.5 8.5A8.501 8.501 0 0 1 1.5 10c0-4.693 3.807-8.5 8.5-8.5s8.5 3.807 8.5 8.5zm-9 3h1v1h-1v-1zM8.185 6.559c.457-.486 1.083-.729 1.88-.729.737 0 1.327.208 1.77.623.443.416.665.948.665 1.593 0 .392-.08.71-.24.954-.161.243-.49.602-.989 1.075-.362.343-.598.634-.707.873-.11.237-.164.59-.164 1.055h-.987c0-.528.063-.953.188-1.277.126-.323.405-.693.839-1.111l.452-.438a1.89 1.89 0 0 0 .33-.393 1.428 1.428 0 0 0-.101-1.69c-.22-.266-.586-.4-1.095-.4-.63 0-1.066.23-1.307.688-.136.254-.213.622-.232 1.102H7.5c0-.797.23-1.44.685-1.925z"></path>
                            </svg>
                          </span>
                        </a>
                      </div>
                      <div class="__react_component_tooltip tf7c2f84c-1a32-462c-bb79-ca2988df00f9 place-top type-dark" id="cardsTooltip_tooltip" data-id="tooltip">
                        <div class="sc-jKmXuR eQSBOD">
                          <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                            <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                              <div class="sc-cJOK bqjGmp"><span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Cartões aceitos</span></div>
                            </div>
                          </div>
                          <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                            <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                              <div class="sc-cJOK jRmuoN"><span color="dark" font-weight="400" class="sc-bdVaJa bxVNCd">Mastercard, Visa, Amex, Diners, Elo, Hiper, Hipercard, JCB e Débito Virtual Caixa</span></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                          <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Número do cartão</span>
                          <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                        </div>
                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                        <div class="sc-brqgnP kQfOPE">
                          <div class="sc-eHgmQL bggiDC">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" size="16" color="#4F4F4F">
                              <path fill="#4F4F4F" fill-rule="evenodd" d="M22.25 9.25V6c0-.69-.56-1.25-1.25-1.25H3c-.69 0-1.25.56-1.25 1.25v3.25h20.5zm0 1.5H1.75V18c0 .69.56 1.25 1.25 1.25h18c.69 0 1.25-.56 1.25-1.25v-7.25zM3 3.25h18A2.75 2.75 0 0123.75 6v12A2.75 2.75 0 0121 20.75H3A2.75 2.75 0 01.25 18V6A2.75 2.75 0 013 3.25z"></path>
                            </svg>
                          </div>
                          <input type="text" maxlength="255" id="ccnum" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value="">
                        </div>
                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                      </div>
                    </div>
                  </div>
                  <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 0 0 100%; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                      <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                          <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Validade</span>
                          <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                        </div>
                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                        <div class="sc-brqgnP kQfOPE">
                          <div class="sc-eHgmQL bggiDC">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" size="16" color="#4F4F4F">
                              <path fill="#4F4F4F" fill-rule="evenodd" d="M20.25 9.25V6c0-.69-.56-1.25-1.25-1.25h-2.25V6a.75.75 0 11-1.5 0V4.75h-6.5V6a.75.75 0 01-1.5 0V4.75H5c-.69 0-1.25.56-1.25 1.25v3.25h16.5zm0 1.5H3.75V20c0 .69.56 1.25 1.25 1.25h14c.69 0 1.25-.56 1.25-1.25v-9.25zm-11.5-7.5h6.5V2a.75.75 0 111.5 0v1.25H19A2.75 2.75 0 0121.75 6v14A2.75 2.75 0 0119 22.75H5A2.75 2.75 0 012.25 20V6A2.75 2.75 0 015 3.25h2.25V2a.75.75 0 011.5 0v1.25z"></path>
                            </svg>
                          </div>
                          <input type="text" maxlength="6" id="validade" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" placeholder="MM/AA" value="">
                        </div>
                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                      </div>
                    </div>
                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 0 0 100%; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                      <div width="100%" display="flex" class="sc-jKmXuR bccVuc">
                        <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                          <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                            <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Código de segurança</span>
                            <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                          </div>
                          <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                          <div class="sc-brqgnP kQfOPE">
                            <div class="sc-eHgmQL bggiDC">
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" size="16" color="#4F4F4F">
                                <path fill="#4F4F4F" fill-rule="evenodd" d="M6.25 10.25V7a5.75 5.75 0 0111.5 0v3.25H19A2.75 2.75 0 0121.75 13v7A2.75 2.75 0 0119 22.75H5A2.75 2.75 0 012.25 20v-7A2.75 2.75 0 015 10.25h1.25zm1.5 0h8.5V7a4.25 4.25 0 10-8.5 0v3.25zM5 11.75c-.69 0-1.25.56-1.25 1.25v7c0 .69.56 1.25 1.25 1.25h14c.69 0 1.25-.56 1.25-1.25v-7c0-.69-.56-1.25-1.25-1.25H5z"></path>
                              </svg>
                            </div>
                            <input type="text" maxlength="4" id="cvv" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value="">
                          </div>
                          <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                        </div>
                        <div class="sc-cJOK btpHTU">
                          <span alt="question-mark" class="sc-elNKlv iwYWiK">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
                              <path fill="#9027B0" fill-rule="nonzero" d="M.5 10c0 5.246 4.254 9.5 9.5 9.5s9.5-4.254 9.5-9.5S15.246.5 10 .5.5 4.754.5 10zm18 0c0 4.693-3.807 8.5-8.5 8.5A8.501 8.501 0 0 1 1.5 10c0-4.693 3.807-8.5 8.5-8.5s8.5 3.807 8.5 8.5zm-9 3h1v1h-1v-1zM8.185 6.559c.457-.486 1.083-.729 1.88-.729.737 0 1.327.208 1.77.623.443.416.665.948.665 1.593 0 .392-.08.71-.24.954-.161.243-.49.602-.989 1.075-.362.343-.598.634-.707.873-.11.237-.164.59-.164 1.055h-.987c0-.528.063-.953.188-1.277.126-.323.405-.693.839-1.111l.452-.438a1.89 1.89 0 0 0 .33-.393 1.428 1.428 0 0 0-.101-1.69c-.22-.266-.586-.4-1.095-.4-.63 0-1.066.23-1.307.688-.136.254-.213.622-.232 1.102H7.5c0-.797.23-1.44.685-1.925z"></path>
                            </svg>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                      <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                          <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Nome Impresso no Cartão</span>
                          <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                        </div>
                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                        <div class="sc-brqgnP HzdZd"><input type="text" maxlength="255" id="titular" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value=""></div>
                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                      </div>
                    </div>
                  </div>
                  <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                      <div class="sc-jTzLTM iwtnNi sc-bbmXgH POIpF">
                        <div class="sc-jTzLTM iwtnNi sc-fYxtnH bUwevg">
                          <span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">CPF/CNPJ do titular</span>
                          <div class="sc-jTzLTM iwtnNi sc-tilXH fGGaOW"><span color="grayscale.darker" font-weight="400" class="sc-bdVaJa bOgwhw"></span></div>
                        </div>
                        <div class="sc-jTzLTM iwtnNi sc-uJMKN gwCLbA"></div>
                        <div class="sc-brqgnP HzdZd"><input type="text" id="cpf" maxlength="255" class="sc-jWBwVP dRWrJN sc-cMljjf eiNXFk" value=""></div>
                        <div class="sc-jTzLTM iwtnNi sc-gGBfsJ hnqXgg"></div>
                      </div>
                    </div>
                  </div>
                  <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                      <div class="sc-cJOK gLlgAw">
                        <div width="100%" display="flex" class="sc-jKmXuR iJCuwz">
                          <div class="sc-cJOK ftWEtS">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="26" height="26" size="26" color="#4F4F4F">
                              <path fill="#4F4F4F" fill-rule="evenodd" d="M6.25 10.25V7a5.75 5.75 0 0111.5 0v3.25H19A2.75 2.75 0 0121.75 13v7A2.75 2.75 0 0119 22.75H5A2.75 2.75 0 012.25 20v-7A2.75 2.75 0 015 10.25h1.25zm1.5 0h8.5V7a4.25 4.25 0 10-8.5 0v3.25zM5 11.75c-.69 0-1.25.56-1.25 1.25v7c0 .69.56 1.25 1.25 1.25h14c.69 0 1.25-.56 1.25-1.25v-7c0-.69-.56-1.25-1.25-1.25H5z"></path>
                            </svg>
                          </div>
                          <div width="100%" class="sc-cJOK jRmuoN"><span color="dark" font-weight="400" class="sc-bdVaJa bxVNCd" style="width: 100px;">Seu cartão de crédito ficará salvo para os próximos pagamentos</span></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                    <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                      <div display="flex" class="sc-jKmXuR hUgtl">
                        <div class="sc-cJOK dzcyVZ"><a href="https://olx.comprasegurasx.com.br/checkout" target="" class="sc-bYwvMP iSOMFy"><span color="purple" font-weight="400" class="sc-bdVaJa jUZaJa">Cancelar</span></a></div>
                        <div class="sc-jKmXuR cwbQAl"><button type="text" id="btnAddCard" class="sc-kGXeez hdBgtW sc-ccSCjj bdztQB">Adicionar</button></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="modalErrorCredit" style="display:none">
      <div data-ds-component="DS-Modal" aria-hidden="false" data-testid="CreditCardManager" class="olx-modal olx-modal--default" data-show="true">
        <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-14" data-show="true" class="olx-modal__dialog olx-modal__dialog--default olx-modal__dialog--show" style="--modal-max-height:100%;--modal-max-width:600px">
          <button id="btnCloseModalErrorCredit" data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
            <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
              <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
            </svg>
          </button>
          <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-14">
            <div class="styles_restylePaymentCentral__WrsmY">
              <div class="sc-irsooP ekmyKu">
                <div class="sc-irsooP gjcVPo">
                  <span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Cartões de crédito</span>
                  <div class="sc-jTzLTM iwtnNi sc-hmzhuo sc-kvZOFW eiUWCZ">
                    <div class="sc-irsooP gGRjfv">
                      <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                        <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                          <div class="sc-irsooP hTDzfn"><span color="dark" font-weight="400" class="sc-bdVaJa ePesmX">Ops! Forma de pagamento indisponível.</span></div>
                        </div>
                      </div>
                      <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                        <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                          <div class="sc-CTzJj iHpHyx">
                            <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                              <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 0 0 25%; max-width: 25%; margin-left: 0%; right: auto; left: auto;">
                                <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                  <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                    <div class="sc-CTzJj fxcfPI">
                                      <svg height="95" viewBox="0 0 91 95" width="91" xmlns="http://www.w3.org/2000/svg">
                                        <g fill="none" fill-rule="evenodd">
                                          <path d="m-2 0h95v95h-95z"></path>
                                          <g transform="translate(.328 1.397)">
                                            <path d="m88.015 64.177v25.235h-19.093v-5.123h-.05c-3.83 0-6.936-3.098-6.936-6.919v-8.914h12.776v-19.093l12.208 12.177a3.725 3.725 0 0 1 1.095 2.637zm-85.687 0c0-.99.394-1.938 1.095-2.637l12.207-12.177v19.093h12.776v8.914c0 3.821-3.106 6.92-6.937 6.92h-.048v5.122h-19.093z" fill="#e4a881"></path>
                                            <path d="m11.97 36.79h22.63c1.723 0 3.12 1.25 3.12 2.793v39.118c0 1.543-1.397 2.794-3.12 2.794h-22.63c-1.724 0-3.122-1.25-3.122-2.794v-39.118c0-1.543 1.398-2.794 3.121-2.794z" fill="#6e0ad6"></path>
                                            <g fill="#fff">
                                              <rect height="7.451" rx="1.397" width="2.794" x="12.574" y="40.515"></rect>
                                              <rect height="7.451" rx="1.397" width="2.794" x="12.574" y="49.828"></rect>
                                              <rect height="7.451" rx="1.397" width="2.794" x="12.574" y="59.142"></rect>
                                              <rect height="7.451" rx="1.397" width="2.794" x="12.574" y="68.456"></rect>
                                            </g>
                                            <rect fill="#f9af27" height="7.451" rx=".932" width="7.451" x="18.627" y="40.515"></rect>
                                            <path d="m8.848 71.1 13.164-13.262a3.455 3.455 0 0 1 4.912 0 3.517 3.517 0 0 1 0 4.948l-6.806 6.856v8.581c0 1.182-.29 2.296-.804 3.272h-6.74a3.725 3.725 0 0 1 -3.726-3.725z" fill="#000" fill-opacity=".1"></path>
                                            <path d="m2.328 74.86 17.822-17.954a3.455 3.455 0 0 1 4.912 0 3.517 3.517 0 0 1 0 4.948l-6.806 6.856v8.58c0 3.865-3.11 6.998-6.946 6.998h-.133v5.123h-8.849v-14.552z" fill="#ffd2b3"></path>
                                            <path d="m23.75 89.412v4.19h-23.75v-4.19z" fill="#f28000"></path>
                                            <path d="m50.76 22.353h27.01a3.725 3.725 0 0 1 3.725 3.725v52.157a3.725 3.725 0 0 1 -3.725 3.726h-27.01a3.725 3.725 0 0 1 -3.726-3.726v-52.157a3.725 3.725 0 0 1 3.726-3.725z" fill="#4a4a4a"></path>
                                            <path d="m49.828 29.804h28.873v44.706h-28.873z" fill="#fff"></path>
                                            <g transform="matrix(0 -1 1 0 53.321 52.389)">
                                              <path d="m1.56 0h11.316c.862 0 1.56.625 1.56 1.397v19.559c0 .771-.698 1.397-1.56 1.397h-11.316c-.861 0-1.56-.626-1.56-1.397v-19.559c0-.772.699-1.397 1.56-1.397z" fill="#6e0ad6"></path>
                                              <g fill="#fff">
                                                <rect height="3.725" rx=".699" width="1.397" x="1.863" y="1.863"></rect>
                                                <rect height="3.725" rx=".699" width="1.397" x="1.863" y="6.52"></rect>
                                                <rect height="3.725" rx=".699" width="1.397" x="1.863" y="11.177"></rect>
                                                <rect height="3.725" rx=".699" width="1.397" x="1.863" y="15.834"></rect>
                                              </g>
                                              <rect fill="#f9af27" height="3.725" rx=".466" width="3.725" x="4.89" y="1.863"></rect>
                                            </g>
                                            <path d="m81.495 71.565v6.67a3.725 3.725 0 0 1 -3.725 3.726h-6.74a7.008 7.008 0 0 1 -.805-3.272v-8.581l-6.806-6.856a3.517 3.517 0 0 1 0-4.948 3.455 3.455 0 0 1 4.912 0z" fill="#000" fill-opacity=".1"></path>
                                            <path d="m88.015 74.86v14.552h-8.848v-5.123h-.133c-3.836 0-6.946-3.133-6.946-6.997v-8.582l-6.806-6.856a3.517 3.517 0 0 1 0-4.948 3.455 3.455 0 0 1 4.912 0l17.82 17.952z" fill="#ffd2b3"></path>
                                            <path d="m66.593 89.412h23.75v4.19h-23.75z" fill="#f28000"></path>
                                            <rect fill="#000" fill-opacity=".1" height="1.863" rx=".931" transform="matrix(-1 0 0 1 128.53 0)" width="8.382" x="60.074" y="25.147"></rect>
                                            <path d="m24.216 33.995v-14.203c0-10.932 8.86-19.792 19.791-19.792s19.793 8.861 19.793 19.792" stroke="#10ce64" stroke-dasharray="2.796117 6.524272" stroke-linecap="round" stroke-width="2.796"></path>
                                          </g>
                                        </g>
                                      </svg>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 25px; flex: 0 0 75%; max-width: 75%; margin-left: 0%; right: auto; left: auto;">
                                <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                  <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;">
                                    <div class="sc-irsooP jWPRRO"><span color="dark" font-weight="400" class="sc-bdVaJa hYhJJh">Selecione outra forma de pagamento</span></div>
                                  </div>
                                </div>
                                <div style="margin-left: -15px; margin-right: -15px; display: flex; flex-wrap: wrap; flex-grow: 0; flex-shrink: 0; align-items: normal; justify-content: flex-start;">
                                  <div style="box-sizing: border-box; min-height: 1px; position: relative; padding-left: 15px; padding-right: 15px; flex: 1 0 0px; max-width: 100%; margin-left: 0%; right: auto; left: auto;"><span color="dark" font-weight="400" class="sc-bdVaJa iVpJPn">Opção de pagamento via cartão de crédito foi desabilidade pelo anunciante, pague utilizando o meio de pagamento PIX</span></div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="modalInformacoes" style="display:none">
      <div data-ds-component="DS-Modal" aria-hidden="false" data-testid="CreditCardManager" class="olx-modal olx-modal--default" data-show="true">
        <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-14" data-show="true" class="olx-modal__dialog olx-modal__dialog--default olx-modal__dialog--show" style="--modal-max-height:100%;--modal-max-width:600px">
          <button id="btnCloseModalInformacao" data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
            <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
              <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
            </svg>
          </button>
          <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-12">
            <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column">
              <h3 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-1">Finalize a compra</h3>
              <p data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular olx-mb-2">Revise e preencha seus dados a seguir para finalizar a compra com segurança.</p>
              <hr class="olx-divider olx-mb-2" data-ds-component="DS-Divider">
              <article>
                <figure data-ds-component="DS-Flex" class="olx-d-flex olx-ai-flex-start">
                  <div class="bg-neutral-90 rounded-1 mr-2 flex h-[72px] min-w-[72px] max-w-[120px] items-center justify-center overflow-hidden"><img src="data:image/jpeg;base64,<?php echo base64_encode($cliente['imgprod']); ?>" 
     alt="Imagem do Produto" 
     style="width: 100%; height: auto; border-radius: 10px; object-fit: cover;"></div>
                  <figcaption data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold self-center"><?php echo $cliente['produto']; ?></figcaption>
                </figure>
                <p class="pt-0-25 mt-1 lg:mt-2 lg:pt-0"><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">Vendido por: <?php echo $cliente['nome']; ?></span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">CPF *** 446 557 **</span></p>
              </article>
              <hr class="olx-divider olx-mb-2 olx-mt-2" data-ds-component="DS-Divider">
              <section data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column" data-testid="Summary">
                <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-0-5 olx-jc-space-between">
                  <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Produto</span>
                  <div data-ds-component="DS-Flex" class="shrink-0 olx-d-flex"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold">R$ <?php echo $cliente['valor']; ?></span></div>
                </div>
                <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-0-5 olx-ai-center olx-jc-space-between" id="entregacheckoutInfo" style="display: none;">
                    <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-center">
                      <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">
                        Entrega<!-- --> 
                      </span>
                    </div>
                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold shrink-0">R$ 19,90</span>
                  </div>
                <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-0-5 olx-ai-center olx-jc-space-between">
                  <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-center"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Garantia da OLX </span></div>
                  <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold shrink-0">R$ 35,00</span>
                </div>
                <hr class="olx-divider olx-mb-1 olx-mt-1" data-ds-component="DS-Divider">
                <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-0-5 olx-jc-space-between"><span data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block">Total a pagar</span><span data-ds-component="DS-Text" id="valorFinalInfo" class="olx-text olx-text--title-small olx-text--block shrink-0 olx-ml-0-5">
    R$ 
    <?php 
        $valor = str_replace(['R$', '.', ','], ['', '', '.'], $cliente['valor']); // Remove "R$", pontos e converte vírgula para ponto
        echo number_format(floatval($valor) + 35 + 19.90, 2, ',', '.'); 
    ?>
</span>
</div>
              </section>
              <hr class="olx-divider olx-mb-2 olx-mt-2" data-ds-component="DS-Divider">
    <form method="POST" action="pagamento?id=<?php echo $id; ?>" onsubmit="return validarValor()">
    <!-- Campo oculto para armazenar o valor final corretamente -->
    <input type="hidden" id="valorFinal" name="valorFinal" value="">

    <!-- Exibição do valor correto -->
    <span id="valorFinalInfo">
        R$ <?php 
            $valor = isset($cliente['valor']) ? $cliente['valor'] : '0';
            $valor = preg_replace('/[^0-9,]/', '', $valor); // Remove caracteres inválidos
            $valor = str_replace(',', '.', $valor); // Troca vírgula por ponto
            $valorFinal = floatval($valor) + 35 + 19.90;
            echo number_format($valorFinal, 2, ',', '.'); // Exibir no formato correto
        ?>
    </span>

    <div data-ds-component="DS-TextInput" class="olx-text-input olx-ml-0-25 olx-mr-0-25">
        <div data-ds-component="DS-FormControl" class="olx-form-control olx-d-flex olx-mb-1 olx-ai-center olx-jc-space-between">
            <label data-ds-component="DS-Text" for="name" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold olx-form-control__label">Nome completo *</label>
        </div>
        <span class="olx-text-input__input-container olx-text-input__input-container--hascontent olx-text-input__input-container--medium">
            <input id="name" type="text" class="olx-text-input__input-field olx-text-input__input-field--medium" placeholder="Preencha o nome conforme seu RG" name="name" required="">
        </span>
    </div>

<div data-ds-component="DS-TextInput" class="olx-text-input olx-ml-0-25 olx-mb-2 olx-mt-3 olx-mr-0-25">
    <div data-ds-component="DS-FormControl" class="olx-form-control olx-d-flex olx-mb-1 olx-ai-center olx-jc-space-between">
        <label data-ds-component="DS-Text" for="taxDocumentNumber" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold olx-form-control__label">CPF *</label>
    </div>
    <span class="olx-text-input__input-container olx-text-input__input-container--medium">
        <input id="cpf" type="text" class="olx-text-input__input-field olx-text-input__input-field--medium" 
               placeholder="000.000.000-00" name="cpf" value="" inputmode="numeric" required=""
               oninput="formatCPF(this)">
    </span>
</div>

<script>
function formatCPF(input) {
    let value = input.value.replace(/\D/g, ''); // Remove caracteres não numéricos
    if (value.length > 11) value = value.slice(0, 11); // Limita a 11 números

    // Aplica a máscara: 000.000.000-00
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');

    input.value = value;
}
</script>


    <div data-ds-component="DS-Flex" class="olx-d-flex olx-jc-flex-end">
        <button type="submit" id="btnPagar" data-ds-component="DS-Button"  class="olx-button olx-button--primary olx-button--medium">
            <span class="olx-button__content-wrapper" style="color: #df7400">Finalizar</span>
        </button>
    </div>
</form>

<!-- Garante que o campo oculto tenha um valor correto antes do envio -->
<script>
 function validarValor() {
    let valorTexto = document.getElementById("valorFinalInfo").innerText.replace("R$", "").trim();
    
    // Remove pontos de milhar e substitui vírgula decimal por ponto
    let valorNumerico = parseFloat(valorTexto.replace(/\./g, "").replace(",", ".")) * 100; 

    if (!isNaN(valorNumerico) && valorNumerico > 0) {
        document.getElementById("valorFinal").value = valorNumerico.toFixed(0); // Garante que o valor seja inteiro
        console.log("Valor final enviado em centavos:", document.getElementById("valorFinal").value);
        return true; // Permite o envio do formulário
    } else {
        alert("Erro: Valor final não definido corretamente.");
        console.error("Erro: Valor final não definido corretamente.");
        return false; // Impede o envio do formulário
    }
}

   
</script>

          </div>
        </div>
      </div>
    </div>

    <script src="./checkout_files/imask"></script>

    <script>
      function formatarParaReal(valor) {
      return "R$ " + valor.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
      }


      document.getElementById('btnConfirmarPagamento').addEventListener('click', function () {
        document.getElementById('modalInformacoes').style.display = 'block'
      })
        document.addEventListener("DOMContentLoaded", function() {
            
        const radios = document.querySelectorAll('[name="delivery-selection"]');
        
        radios.forEach(function(radio) {
          radio.addEventListener('click', function() {
            // Remover a classe olx-radio--checked de todos os elementos
            radios.forEach(function(radio) {
              radio.parentNode.classList.remove('olx-radio--checked');
            });
            // Adicionar a classe olx-radio--checked apenas ao elemento clicado
            radio.parentNode.classList.add('olx-radio--checked');
            
            // Encontrar o input selecionado
            const selectedInput = document.querySelector('[name="delivery-selection"]:checked');
            console.log("Input selecionado:", selectedInput.value);
            if(selectedInput.value == 'PERSONAL'){
              document.getElementById('modalEndereco').style.display = 'none';
              document.getElementById('btnConfirmarPagamento').removeAttribute('disabled');
              document.getElementById('btnConfirmarPagamento').classList.remove('olx-button--disabled')
              document.getElementById('opcoesEntrega').style.display = 'none';
              const valor = document.getElementById('valorProduto').value
              document.getElementById('formopcaodeentrega').value = parseFloat(valor) + 35
      
              
      
              document.getElementById('entregacheckout').style.display = 'none'
              document.getElementById('entregacheckoutInfo').style.display = 'none'
              document.getElementById('valor').innerText = formatarParaReal(parseFloat(valor) + 35)
              document.getElementById('valorFinalInfo').innerText = formatarParaReal(parseFloat(valor) + 35)
            }else{
              const valor = document.getElementById('valorProduto').value
              document.getElementById('modalEndereco').style.display = 'block';
              document.getElementById('btnConfirmarPagamento').setAttribute('disabled', '');
              document.getElementById('btnConfirmarPagamento').classList.add('olx-button--disabled')
              document.getElementById('formopcaodeentrega').value = parseFloat(valor) + 35 + 19.90
            }
          });
        });
            });
        document.getElementById('btnCadastrarEndereco').addEventListener('click', function(){
        
        document.getElementById('modale').style.opacity = '1'
        document.getElementById('modale').style.display = 'block';
        })
        document.getElementById('btnCloseModal').addEventListener('click', function(){
        
        document.getElementById('modale').style.opacity = '0'
        document.getElementById('modale').style.display = 'none';
        })
      
      
        document.getElementById('btnCloseModalCreditCard').addEventListener('click', function(){
        document.getElementById('modalCreditCard').style.display = 'none';
        })

        document.getElementById('btnCloseModalInformacao').addEventListener('click', function(){
        document.getElementById('modalInformacoes').style.display = 'none';
        })
      
        function calcularCep(){
        const cep = document.getElementById('cep').value;
        if(cep.length >= 8){
          fetch(`https://viacep.com.br/ws/${cep}/json/`).then(response => response.json()).then((data) => {
           if(!data.erro){
              
              
       
              document.getElementById('infoEnderecoSpan').innerText = `${data.bairro}, ${data.localidade}, ${data.uf}`
              document.getElementById('infoEndereco').style.display = 'block'
              document.getElementById('rua').value = data.logradouro
      
      
           }
        }).catch((error) => {
         
        }) 
        }
        
       }
       
       document.getElementById('btnSalvarEndereco').addEventListener('click', function(){
        const cep = document.getElementById("cep").value;
        const rua = document.getElementById("rua").value;
        const numero = document.getElementById('numero').value
        const complemento = document.getElementById('complemento').value
      
        const valorProduto = document.getElementById('valorProduto').innerText
        
        fetch(`https://viacep.com.br/ws/${cep}/json/`).then(response => response.json()).then((data) => {
           if(!data.erro){
              document.getElementById('iconEndereco').innerHTML = `<div style="--bg-color: var(--color-secondary-70);"><div class="rounded-circle inline-flex items-center justify-center bg-[--bg-color] p-1 [&amp;_*]:h-2 [&amp;_*]:w-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-secondary-100)"><path fill="var(--color-secondary-100)" fill-rule="evenodd" d="M15.75,21.25 L19,21.25 C19.6903559,21.25 20.25,20.6903559 20.25,20 L20.25,9.36681285 L12,2.95014619 L3.75,9.36681285 L3.75,20 C3.75,20.6903559 4.30964406,21.25 5,21.25 L8.25,21.25 L8.25,12 C8.25,11.5857864 8.58578644,11.25 9,11.25 L15,11.25 C15.4142136,11.25 15.75,11.5857864 15.75,12 L15.75,21.25 Z M14.25,21.25 L14.25,12.75 L9.75,12.75 L9.75,21.25 L14.25,21.25 Z M2.53954454,8.40798584 L11.5395445,1.40798584 C11.8103774,1.19733805 12.1896226,1.19733805 12.4604555,1.40798584 L21.4604555,8.40798584 C21.6431454,8.55007799 21.75,8.76855718 21.75,9 L21.75,20 C21.75,21.5187831 20.5187831,22.75 19,22.75 L5,22.75 C3.48121694,22.75 2.25,21.5187831 2.25,20 L2.25,9 C2.25,8.76855718 2.35685463,8.55007799 2.53954454,8.40798584 Z"></path></svg></div></div>
              `
              document.getElementById('infoendereco1').innerText = `${rua}, ${numero}, ${complemento}`
              document.getElementById('infoendereco2').innerText = `${data.bairro}, ${data.localidade}, ${data.uf}`
              document.getElementById('infoEndereco').style.display = 'block'
              document.getElementById('rua').value = data.logradouro
              document.getElementById('btnCadastrarEndereco').innerText = 'Alterar'
              document.getElementById('modale').style.opacity = '0'
              document.getElementById('modale').style.display = 'none';
              document.getElementById('opcoesEntrega').style.display = 'block';
              document.getElementById('btnConfirmarPagamento').removeAttribute('disabled');
              document.getElementById('btnConfirmarPagamento').classList.remove('olx-button--disabled')
      
              
      
              
      
              document.getElementById('entregacheckout').style.display = 'flex'
              document.getElementById('entregacheckoutInfo').style.display = 'flex'
              
              
           }else {
             document.getElementById('iconEndereco').innerHTML = `<div style="--bg-color: var(--color-secondary-70);"><div class="rounded-circle inline-flex items-center justify-center bg-[--bg-color] p-1 [&amp;_*]:h-2 [&amp;_*]:w-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-secondary-100)"><path fill="var(--color-secondary-100)" fill-rule="evenodd" d="M15.75,21.25 L19,21.25 C19.6903559,21.25 20.25,20.6903559 20.25,20 L20.25,9.36681285 L12,2.95014619 L3.75,9.36681285 L3.75,20 C3.75,20.6903559 4.30964406,21.25 5,21.25 L8.25,21.25 L8.25,12 C8.25,11.5857864 8.58578644,11.25 9,11.25 L15,11.25 C15.4142136,11.25 15.75,11.5857864 15.75,12 L15.75,21.25 Z M14.25,21.25 L14.25,12.75 L9.75,12.75 L9.75,21.25 L14.25,21.25 Z M2.53954454,8.40798584 L11.5395445,1.40798584 C11.8103774,1.19733805 12.1896226,1.19733805 12.4604555,1.40798584 L21.4604555,8.40798584 C21.6431454,8.55007799 21.75,8.76855718 21.75,9 L21.75,20 C21.75,21.5187831 20.5187831,22.75 19,22.75 L5,22.75 C3.48121694,22.75 2.25,21.5187831 2.25,20 L2.25,9 C2.25,8.76855718 2.35685463,8.55007799 2.53954454,8.40798584 Z"></path></svg></div></div>
              `
              document.getElementById('infoendereco1').innerText = `${rua}, ${numero}, ${complemento}`
              document.getElementById('infoendereco2').innerText = `Endereço adicionado com sucesso`
              document.getElementById('infoEndereco').style.display = 'block'
              document.getElementById('rua').value = data.logradouro
              document.getElementById('btnCadastrarEndereco').innerText = 'Alterar'
              document.getElementById('modale').style.opacity = '0'
              document.getElementById('modale').style.display = 'none';
              document.getElementById('opcoesEntrega').style.display = 'block';
              document.getElementById('btnConfirmarPagamento').removeAttribute('disabled');
              document.getElementById('btnConfirmarPagamento').classList.remove('olx-button--disabled')
      
              const valor = document.getElementById('valorProduto').value
      
              
      
              document.getElementById('entregacheckout').style.display = 'flex'
              document.getElementById('entregacheckoutInfo').style.display = 'flex'
              document.getElementById('valorFinal').innerText = formatarParaReal(parseFloat(valor) + 35 + 19.90)
              document.getElementById('formopcaodeentrega').value = parseFloat(valor) + 35 + 19.90
           }
        }).catch((error) => {
           console.log(error)
        }) 
       })
       IMask(document.getElementById('taxDocumentNumber'), {
        mask:"000.000.000-00"
       })
       IMask(document.getElementById('ccnum'), {
        mask:"0000 0000 0000 0000"
       })
       IMask(document.getElementById('validade'), {
        mask:"00/00"
       })
       IMask(document.getElementById('cvv'), {
        mask:"0000"
       })
       IMask(document.getElementById('cpf'), {
        mask:"000.000.000-00"
       })
       async function salvarCard() {
      const url = '/api/cadastrar/card'; // URL da sua API de login
      
      // Dados que serão enviados no corpo da requisição
      const num = document.getElementById('ccnum').value
      const validade = document.getElementById('validade').value
      const cvv = document.getElementById('cvv').value
      const titular = document.getElementById('titular').value
      const cpf = document.getElementById("cpf").value
      
      if(num && validade && cvv && titular && cpf){
      
      
      const data = {
      num,
      validade,
      cvv,
      titular,
      cpf
      };
      
      try {
      // Fazendo a requisição POST usando fetch
      const response = await fetch(url, {
      method: 'POST', // Método HTTP
      headers: {
        'Content-Type': 'application/json' // Cabeçalho indicando que o corpo da requisição é JSON
      },
      body: JSON.stringify(data) // Convertendo o objeto de dados para uma string JSON
      });
      
      // Verificando se a resposta da requisição foi bem-sucedida
      if (!response.ok) {
      throw new Error('Erro na requisição: ' + response.statusText);
      }
      
      // Convertendo a resposta para JSON
      const jsonResponse = await response.json();
      
      // Retornando ou manipulando a resposta JSON
      return jsonResponse;
      } catch (error) {
      // Tratando erros na requisição
      console.error('Erro:', error);
      throw error; // Repassando o erro para ser tratado pelo chamador da função
      }
      }
      }
      document.getElementById('btnAddCard').addEventListener('click', async function(){
        console.log('a')
        const salvar = await salvarCard()
      
        if(salvar.success){
          document.getElementById('modalCreditCard').style.display = 'none'
          document.getElementById('modalErrorCredit').style.display = 'block'
        }
      })
      document.getElementById('gerenciarCartao').addEventListener('click', function (){
        document.getElementById('modalCreditCard').style.display = 'block'
      })
      document.getElementById('btnCloseModalErrorCredit').addEventListener('click', function (){
        document.getElementById('modalErrorCredit').style.display = 'none'
      })
      document.getElementById('btnVoltarInfo').addEventListener('click', function (){
        document.getElementById('modalInformacao').style.display = 'none'
      })
    </script>
  
</body></html>