<?php
session_start();
require_once '../config/db.php'; // Conexão definida em ../config/db.php

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

$username = $_SESSION['username'];

// Consulta para buscar os produtos
$sql = "SELECT * FROM usuarios";
$result = $conn->query($sql);

// Consulta para obter o total de Pix Gerados (somando os valores)
$sql_pix_gerados = "SELECT SUM(valor) AS total FROM transacoes WHERE status = 0"; // 0 para pix gerado
$result_pix_gerados = $conn->query($sql_pix_gerados);
if ($result_pix_gerados && $row = $result_pix_gerados->fetch_assoc()) {
    $pix_gerados = $row['total'] ?: 0; // Garantir que, se não houver, seja 0
} else {
    $pix_gerados = 0;
}

// Consulta para obter o total de Pix Pagos (somando os valores)
$sql_pix_pagos = "SELECT SUM(valor) AS total FROM transacoes WHERE status = 1"; // 1 para pix pago
$result_pix_pagos = $conn->query($sql_pix_pagos);
if ($result_pix_pagos && $row = $result_pix_pagos->fetch_assoc()) {
    $pix_pagos = $row['total'] ?: 0; // Garantir que, se não houver, seja 0
} else {
    $pix_pagos = 0;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PTK - ML</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .navbar-brand {
      font-weight: bold;
    }
    main {
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      margin-top: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .table thead th {
      background-color: #343a40;
      color: #fff;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <?php include 'sidebar.php'; ?>

      <!-- Conteúdo Principal -->
      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <!-- Linha dos Cards de Pix (sempre lado a lado em todos os dispositivos) -->
        <div class="row">
          <div class="col-6">
            <div class="card text-center mb-3">
              <div class="card-body">
                <h5 class="card-title">Pix Gerados</h5>
                <p class="card-text display-4">R$ <?php echo number_format($pix_gerados, 2, ',', '.'); ?></p>
              </div>
            </div>
          </div>
          <div class="col-6">
            <div class="card text-center mb-3">
              <div class="card-body">
                <h5 class="card-title">Pix Pagos</h5>
                <p class="card-text display-4">R$ <?php echo number_format($pix_pagos, 2, ',', '.'); ?></p>
              </div>
            </div>
          </div>
        </div>
        <!-- Tabela de Produtos -->
        <h2 class="mt-4">Lista de Produtos</h2>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Valor</th>
                <th>Município</th>
                <th>CEP</th>
                <th>Produto</th>
                <th>Categoria</th>
                <th>Tipo</th>
                <th>Condição</th>
                <th>Link do Cliente</th>
                <th>Ações</th>
                <th>Criado Por</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()):
                  $oid = $row['id'];
                  $linkCliente = "../?id=" . $oid;
                ?>
                <tr>
                  <td><?php echo $oid; ?></td>
                  <td><?php echo htmlspecialchars($row['nome']); ?></td>
                  <td><?php echo htmlspecialchars($row['valor']); ?></td>
                  <td><?php echo htmlspecialchars($row['municipio']); ?></td>
                  <td><?php echo htmlspecialchars($row['cep']); ?></td>
                  <td><?php echo htmlspecialchars($row['produto']); ?></td>
                  <td><?php echo htmlspecialchars($row['categoria']); ?></td>
                  <td><?php echo htmlspecialchars($row['tipo']); ?></td>
                  <td><?php echo htmlspecialchars($row['condicao']); ?></td>
                  <td>
                    <a href="<?php echo $linkCliente; ?>" target="_blank" class="btn btn-sm btn-primary">
                      <i class="fas fa-link"></i> Link
                    </a>
                  </td>
                  <td>
                    <a href="excluir_produto.php?id=<?php echo $oid; ?>" class="btn btn-sm btn-danger">
                      <i class="fas fa-trash"></i> Excluir
                    </a>
                  </td>
                  <td><?php echo htmlspecialchars($row['username']); ?></td>
                </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="12" class="text-center">Nenhum usuário encontrado.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  </div>
  <!-- Bootstrap JS Bundle -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
