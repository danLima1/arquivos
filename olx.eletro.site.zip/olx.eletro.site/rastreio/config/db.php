<?php
$conn = mysqli_connect(
    "localhost",  // Nome do host
    "rastreio",     // Nome do usuário
    "rRWAN5PiBJjGNBH2",     // Senha
    "rastreio"      // Nome do banco de dados
) or die("Falha na conexão: " . mysqli_connect_error());
?>
