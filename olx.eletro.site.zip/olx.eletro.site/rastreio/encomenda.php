<?php
// Incluir o arquivo de configuração do banco de dados
require_once 'config/db.php';
setlocale(LC_TIME, 'pt_BR.UTF-8');

// Variáveis para armazenar os dados
$data = [];
$error = null;
$ultimaAtualizacao = null; // Variável para armazenar a última atualização

// Verifica se o parâmetro 'tracking' está presente na URL e não está vazio
if (isset($_GET['tracking']) && !empty($_GET['tracking'])) {
    // Obtém o valor do tracking da URL
    $trackingCode = $_GET['tracking'];

    $sql = "SELECT id  FROM rastreios WHERE codigo = ?";
    
    // Prepara a consulta
    if ($stmt = $conn->prepare($sql)) {
        // Vincula o parâmetro de entrada
        $stmt->bind_param("s", $trackingCode);
        
        // Executa a consulta
        $stmt->execute();
        
        // Armazena o resultado
        $stmt->store_result();
        
        // Verifica se o código de rastreio existe na tabela 'rastreios'
        if ($stmt->num_rows > 0) {
            // Obtém o ID do rastreio
            $stmt->bind_result($rastreioId);
            $stmt->fetch();
            
            // Consulta a tabela 'movimentacoes' com o rastreio_id encontrado
            $sqlMov = "SELECT * FROM movimentacoes WHERE rastreio_id = ?";
            
            // Prepara a consulta para movimentações
            if ($stmtMov = $conn->prepare($sqlMov)) {
                // Vincula o parâmetro de entrada
                $stmtMov->bind_param("i", $rastreioId);
                
                // Executa a consulta
                $stmtMov->execute();
                
                // Armazena o resultado
                $resultMov = $stmtMov->get_result();
                
                // Variável para armazenar todas as movimentações
                $movimentacoes = [];
                $postagem = null; // Variável para armazenar a primeira postagem

                // Função para separar data e hora
                function formatDateAndTime($timestamp) {
                    // Define o locale para português
                    setlocale(LC_TIME, 'pt_BR.UTF-8');
                    $dateTime = new DateTime($timestamp);
                    // Exibe somente o dia e o mês (sem o ano)
                    $date = strftime('%d de %b', $dateTime->getTimestamp()); // Exemplo: 22 de fev
                    $time = $dateTime->format('H:i'); // Formato da hora
                    return ['date' => $date, 'time' => $time];
                }

                // Verifica se existem movimentações
                if ($resultMov->num_rows > 0) {
                    // Armazena todas as movimentações em um array e salva a primeira postagem separada
                    $first = true; // Flag para identificar o primeiro registro (postagem)
                    while ($row = $resultMov->fetch_assoc()) {
                        // Converte o campo 'criado_em' para data e hora separadas
                        $dateTimeFormatted = formatDateAndTime($row['criado_em']);
                        $row['data_formatada'] = $dateTimeFormatted['date'];  // Agora exibe apenas o dia e o mês
                        $row['hora_formatada'] = $dateTimeFormatted['time'];

                        // Se for o primeiro registro, armazena como postagem
                        if ($first) {
                            $postagem = $row;
                            $first = false; // Desativa a flag após armazenar a postagem
                            continue; // Pula a iteração para não adicionar o primeiro registro ao array
                        }
                        
                        // Adiciona a movimentação ao array de movimentações (somente após o primeiro registro)
                        $movimentacoes[] = $row;

                        // Atualiza a variável ultimaAtualizacao com o último registro
                        $ultimaAtualizacao = $dateTimeFormatted['date'] . ' às ' . $dateTimeFormatted['time'];
                    }

                    // Armazena os dados na variável $data
                    $data['postagem'] = $postagem;
                    $data['movimentacoes'] = $movimentacoes;

                } else {
                    $error = 'Não há movimentações para este código de rastreio.';
                }

                $stmtMov->close();
            } else {
                $error = "Erro ao preparar a consulta de movimentações: " . $conn->error;
            }
        } else {
            $error = 'Código de rastreio não encontrado.';
        }
        
        $stmt->close();
    } else {
        $error = "Erro ao preparar a consulta de rastreio: " . $conn->error;
    }
    
    // Fecha a conexão com o banco de dados
    $conn->close();
} else {
    $error = 'Código de rastreio não informado.';
}

// Caso necessário, o conteúdo pode ser manipulado através da variável $data, $error ou $ultimaAtualizacao
?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Rastreie suas encomendas gratuitamente</title>
    <meta name="description" content="Rastrear a sua encomenda nunca foi tão fácil.">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <link rel="icon" type="image/ico" href="https://app.melhorrastreio.com.br/favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="https://app.melhorrastreio.com.br/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://app.melhorrastreio.com.br/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://app.melhorrastreio.com.br/favicon-16x16.png">
    <link rel="mask-icon" href="https://app.melhorrastreio.com.br/safari-pinned-tab.svg" color="#2bc866">
    <link rel="stylesheet" href="./encomenda_files/entry.3b8eeccc.css">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/azul-cargo-express.b4f85de7.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/buslog.8c89e02f.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="./encomenda_files/correios.abc01ab5.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/jadlog.e67d781e.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/latam-airlines.95faa23b.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/loggi.b39c8df1.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/melhorenvio.3b490f17.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/jet-express.4c89d06b.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/melhorponto.ea06f1d4.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/pegaki.52b4e05d.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/me-logo-blue.86d0bf20.svg">
    <link rel="prefetch" as="image" type="image/svg+xml" href="https://app.melhorrastreio.com.br/files/melhorenvio.8708d620.svg">
    <style>
        #arrow[data-v-20b7fd4a],
          #arrow[data-v-20b7fd4a]::before {
            transition: background 250ms ease-in-out;
            position: absolute;
            width: calc(10px - var(--popper-theme-border-width, 0px));
            height: calc(10px - var(--popper-theme-border-width, 0px));
            box-sizing: border-box;
            background: var(--popper-theme-background-color);
        }
        #arrow[data-v-20b7fd4a] {
            visibility: hidden;
        }
        #arrow[data-v-20b7fd4a]::before {
            visibility: visible;
            content: "";
            transform: rotate(45deg);
        }
        
          /* Top arrow */
        .popper[data-popper-placement^="top"] > #arrow[data-v-20b7fd4a] {
            bottom: -5px;
        }
        .popper[data-popper-placement^="top"] > #arrow[data-v-20b7fd4a]::before {
            border-right: var(--popper-theme-border-width)
              var(--popper-theme-border-style) var(--popper-theme-border-color);
            border-bottom: var(--popper-theme-border-width)
              var(--popper-theme-border-style) var(--popper-theme-border-color);
        }
        
          /* Bottom arrow */
        .popper[data-popper-placement^="bottom"] > #arrow[data-v-20b7fd4a] {
            top: -5px;
        }
        .popper[data-popper-placement^="bottom"] > #arrow[data-v-20b7fd4a]::before {
            border-left: var(--popper-theme-border-width)
              var(--popper-theme-border-style) var(--popper-theme-border-color);
            border-top: var(--popper-theme-border-width)
              var(--popper-theme-border-style) var(--popper-theme-border-color);
        }
        
          /* Left arrow */
        .popper[data-popper-placement^="left"] > #arrow[data-v-20b7fd4a] {
            right: -5px;
        }
        .popper[data-popper-placement^="left"] > #arrow[data-v-20b7fd4a]::before {
            border-right: var(--popper-theme-border-width)
              var(--popper-theme-border-style) var(--popper-theme-border-color);
            border-top: var(--popper-theme-border-width)
              var(--popper-theme-border-style) var(--popper-theme-border-color);
        }
        
          /* Right arrow */
        .popper[data-popper-placement^="right"] > #arrow[data-v-20b7fd4a] {
            left: -5px;
        }
    </style>
    <style type="text/css">
        .inline-block[data-v-5784ed69] {
            display: inline-block;
        }
        .popper[data-v-5784ed69] {
            transition: background 250ms ease-in-out;
            background: var(--popper-theme-background-color);
            padding: var(--popper-theme-padding);
            color: var(--popper-theme-text-color);
            border-radius: var(--popper-theme-border-radius);
            border-width: var(--popper-theme-border-width);
            border-style: var(--popper-theme-border-style);
            border-color: var(--popper-theme-border-color);
            box-shadow: var(--popper-theme-box-shadow);
            z-index: var(--c81fc0a4);
        }
        .popper[data-v-5784ed69]:hover,
          .popper:hover > #arrow[data-v-5784ed69]::before {
            background: var(--popper-theme-background-color-hover);
        }
        .inline-block[data-v-5784ed69] {
            display: inline-block;
        }
        .fade-enter-active[data-v-5784ed69],
          .fade-leave-active[data-v-5784ed69] {
            transition: opacity 0.2s ease;
        }
        .fade-enter-from[data-v-5784ed69],
          .fade-leave-to[data-v-5784ed69] {
            opacity: 0;
        }
    </style>
    <script recaptcha-v3-script="" src="./encomenda_files/api.js.download"></script>
    <link rel="modulepreload" as="script" crossorigin="" href="https://app.melhorrastreio.com.br/files/_trackingCode_.1544f6cd.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://app.melhorrastreio.com.br/files/MRNonLoggedUserOnly.f13ed192.js">
    <link rel="stylesheet" href="./encomenda_files/MRNonLoggedUserOnly.783bab73.css">
    <link rel="modulepreload" as="script" crossorigin="" href="https://app.melhorrastreio.com.br/files/MRTrackingEventList.80e7c49c.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://app.melhorrastreio.com.br/files/information-circle-outline.f7e33939.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://app.melhorrastreio.com.br/files/vue.f36acd1f.a35c934b.js">
    <style>
        .grecaptcha-badge{visibility:hidden !important;}
    </style>
    <style type="text/css">
        @font-face {
        	font-family: 'Atlassian Sans';
        	font-style: normal;
        	font-weight: 400 653;
        	font-display: swap;
        	src:
        		local('AtlassianSans'),
        		local('Atlassian Sans Text'),
        		url(https://ds-cdn.prod-east.frontend.public.atl-paas.net/assets/fonts/atlassian-sans/v1/AtlassianSans-latin.woff2)
        			format('woff2');
        	unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304,
        		U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
    </style>
    <script type="text/javascript" defer="" src="./encomenda_files/consent.js.download" id="cookiefirst-banner"></script>
    <script src="./encomenda_files/banner.no-autoblock.js.download"></script>
    <meta name="robots" content="noindex">
    <iframe id="bulk-consent" tabindex="-1" role="presentation" aria-hidden="true" title="Bulk Consent" src="./encomenda_files/cf-bc-handler.html" style="position: absolute; width: 1px; height: 1px; top: -9999px;"></iframe>
    <link rel="stylesheet" type="text/css" href="./encomenda_files/441.e308.c.css">
    <link rel="stylesheet" type="text/css" href="./encomenda_files/ui.b5ec.c.css">
    <link rel="stylesheet" type="text/css" href="./encomenda_files/560.362b.c.css">
</head>

<body style="padding-right: 0px;">
    <div id="__nuxt" data-v-app="">
        <div class="overflow-hidden min-h-screen" data-page-name="page-carrier-trackingCode">
            <div class="me-template">
                <header class="h-header border-b-neutral-light z-100 fixed left-0 top-0 w-screen border-b bg-white">
                    <div class="mx-auto flex size-full items-center xl:px-11 max-w-screen-2xl">
                        <!---->
                        <a href="./" class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 xl:static xl:transform-none" disabled="false"><img src="./encomenda_files/mr-logo.svg" alt="Melhor Rastreio" class="h-9"></a>
                    </div>
                </header>
                <div class="pt-header relative mx-auto max-w-screen-2xl">
                    <!---->
                    <main role="main" class="template__main relative mx-3 xl:mx-11 xl:py-11">
                        <div>
                            <form novalidate="" class="flex flex-col pb-7 pr-3 pl-3 lg:-mx-11 lg:-mt-11 lg:px-11 lg:rounded-b-[4px] relative pt-7 bg-tracking-form w-auto -mx-3 z-1"  method="GET" action="./encomenda">
                                <!---->
                                <!---->
                                <div class="flex justify-center w-full">
                                    <div class="relative w-full"><span class="relative z-0 w-full mr-tracking-field"><div><div class="relative w-full"><div class="field"><div class="field__wrapper"><!----><input class="field__input border-neutral-light" id="tracking" name="tracking" type="text" inputmode="text" placeholder="Por favor, digite um código de rastreio." tabindex="0" value="<?= $trackingCode ?>"><label class="field__label" for="tracking">Código de rastreamento<!----></label><!----></div><!----></div></div></div></span>
                                      
                                            <section>
                                                <!---->
                                            </section>
                                    </div>
                                    <button type="submit" class="me-button me-button--primary search-button ml-3 focus:ring-2 focus:ring-offset-2 responsive-button"  aria-label="Rastrear"><span class="me-button__content"><span class="me-button__icon" role="img"><svg viewBox="0 0 512 512" fill="currentColor" width="1em" height="1em" class="text-xl"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 48c-79.5 0-144 61.39-144 137c0 87 96 224.87 131.25 272.49a15.77 15.77 0 0 0 25.5 0C304 409.89 400 272.07 400 185c0-75.61-64.5-137-144-137Z"></path><circle cx="256" cy="192" r="48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle></svg></span>
                                        <span
                                        class="me-button__text uppercase"><span class="sm:ml-2"> Rastrear </span></span>
                                            <!---->
                                            </span>
                                            <!---->
                                    </button>
                                </div>
                            </form>
                                                            <script>
    document.querySelector('form').addEventListener('submit', function (event) {
        event.preventDefault(); // Evita o envio tradicional do formulário
        const trackingCode = document.querySelector('#tracking').value;
        if (trackingCode) {
            window.location.href = `./encomenda?tracking=${trackingCode}`;
        } else {
            alert('Por favor, digite um código de rastreio válido.');
        }
    });
</script>

                            <div class="flex mt-6">
                                <div class="w-full">
                                    <div class="flex flex-col w-full">
                                        <!---->
                                        <div class="flex flex-col xl:flex-row w-full">
                                            <div class="w-full">
                                                <div class="border border-neutral-light rounded bg-neutral-light">
                                                    <div class="bg-white rounded p-5 xl:px-6 xl:pt-[30px] xl:pb-9">
                                                        <div class="flex justify-between items-center w-full">
                                                          <?php if (!empty($data['postagem'])): ?>
                                                            <div class="relative mr-5 min-w-[60px] min-h-[60px]" mr-testid="&#39;spinner&#39;">
                                                                <div class="absolute h-7 top-0 right-0 bottom-0 left-0 m-auto flex justify-center items-center">
                                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <g id="movement_svg__ICON____truck">
                                                                            <path id="movement_svg__Vector" fill-rule="evenodd" clip-rule="evenodd" d="M13.3479 16.0106C13.5935 16.0106 13.7915 16.2117 13.7915 16.4583C13.7921 16.5763 13.7458 16.6897 13.6628 16.7736C13.5798 16.8575 13.4669 16.9051 13.3489 16.9059H11.5473C11.4293 16.9051 11.3164 16.8575 11.2335 16.7736C11.1505 16.6897 11.1042 16.5763 11.1047 16.4583C11.1047 16.2117 11.3038 16.0106 11.5473 16.0106H13.3489H13.3479ZM13.5126 4.36834C13.7652 4.36834 13.9704 4.56941 13.9704 4.81596C13.9688 4.93594 13.9197 5.05039 13.8339 5.13428C13.7481 5.21817 13.6326 5.26467 13.5126 5.26359H2.96464C2.84483 5.2644 2.72956 5.21779 2.644 5.13392C2.55843 5.05006 2.50951 4.93576 2.50792 4.81596C2.50792 4.56941 2.71304 4.36834 2.96464 4.36834H13.5136H13.5126ZM18.6275 17.6223C18.7248 17.6171 18.8221 17.6318 18.9135 17.6655C19.0049 17.6992 19.0885 17.7511 19.1592 17.8181C19.2299 17.8852 19.2862 17.9659 19.3246 18.0554C19.3631 18.1449 19.383 18.2413 19.383 18.3387C19.383 18.4361 19.3631 18.5325 19.3246 18.622C19.2862 18.7115 19.2299 18.7922 19.1592 18.8593C19.0885 18.9263 19.0049 18.9782 18.9135 19.0119C18.8221 19.0456 18.7248 19.0603 18.6275 19.0551C18.4441 19.0454 18.2714 18.9656 18.145 18.8323C18.0186 18.6991 17.9481 18.5224 17.9481 18.3387C17.9481 18.155 18.0186 17.9783 18.145 17.845C18.2714 17.7118 18.4441 17.632 18.6275 17.6223ZM5.37353 17.6223C5.47081 17.6171 5.56812 17.6318 5.65953 17.6655C5.75095 17.6992 5.83455 17.7511 5.90524 17.8181C5.97592 17.8852 6.03222 17.9659 6.07069 18.0554C6.10916 18.1449 6.129 18.2413 6.129 18.3387C6.129 18.4361 6.10916 18.5325 6.07069 18.622C6.03222 18.7115 5.97592 18.7922 5.90524 18.8593C5.83455 18.9263 5.75095 18.9782 5.65953 19.0119C5.56812 19.0456 5.47081 19.0603 5.37353 19.0551C5.1901 19.0454 5.01741 18.9656 4.89102 18.8323C4.76463 18.6991 4.69418 18.5224 4.69418 18.3387C4.69418 18.155 4.76463 17.9783 4.89102 17.845C5.01741 17.7118 5.1901 17.632 5.37353 17.6223ZM23.029 13.0632H22.1095V13.5735C22.1095 13.7856 22.2812 13.9594 22.4944 13.9594H23.03V13.0632H23.029ZM21.483 17.8496H23.037V14.9234H22.1095C21.8538 14.9234 21.6086 14.8218 21.4278 14.6411C21.2471 14.4603 21.1455 14.2151 21.1455 13.9594V12.8227C21.1455 12.4226 21.4688 12.0992 21.868 12.0992H23.034C23.0212 11.9168 22.9398 11.7461 22.8061 11.6214C22.6724 11.4967 22.4964 11.4273 22.3136 11.4273H16.2802V12.3912C16.2802 12.5191 16.2295 12.6417 16.1391 12.732C16.0487 12.8224 15.9261 12.8732 15.7982 12.8732C15.6704 12.8732 15.5478 12.8224 15.4574 12.732C15.367 12.6417 15.3163 12.5191 15.3163 12.3912V10.4623H15.3011V3.36396H0.962951V17.8496H2.51802C2.63366 17.1824 2.98059 16.5771 3.49795 16.1402C4.01532 15.7032 4.67005 15.4623 5.34726 15.4599C6.70327 15.4599 7.88548 16.4239 8.15931 17.7526L8.17649 17.8496H15.3011L15.3163 17.8648V14.7223C15.3163 14.5945 15.367 14.4719 15.4574 14.3815C15.5478 14.2911 15.6704 14.2403 15.7982 14.2403C15.9261 14.2403 16.0487 14.2911 16.1391 14.3815C16.2295 14.4719 16.2802 14.5945 16.2802 14.7223V16.72C16.5437 16.3329 16.8975 16.0158 17.3111 15.7962C17.7246 15.5767 18.1855 15.4613 18.6538 15.4599C20.0098 15.4599 21.192 16.4239 21.4658 17.7526L21.483 17.8496ZM20.521 18.7166C20.5728 18.4626 20.5728 18.2007 20.521 17.9466C20.4314 17.5173 20.197 17.1317 19.8571 16.8545C19.5172 16.5773 19.0924 16.4253 18.6538 16.4239C18.3709 16.4251 18.0919 16.4891 17.8367 16.6111C17.5815 16.733 17.3566 16.9101 17.178 17.1294C16.9994 17.3488 16.8717 17.605 16.804 17.8796C16.7363 18.1542 16.7303 18.4404 16.7865 18.7176C16.9673 19.5997 17.7524 20.2403 18.6538 20.2403C19.5541 20.2403 20.3402 19.5997 20.521 18.7166ZM7.21455 18.7166C7.26627 18.4626 7.26627 18.2007 7.21455 17.9466C7.12493 17.5173 6.89054 17.1317 6.55062 16.8545C6.2107 16.5773 5.78587 16.4253 5.34726 16.4239C5.06442 16.4251 4.78538 16.4891 4.5302 16.6111C4.27502 16.733 4.05006 16.9101 3.87149 17.1294C3.69293 17.3488 3.5652 17.605 3.4975 17.8796C3.4298 18.1542 3.42381 18.4404 3.47996 18.7176C3.66184 19.5997 4.44594 20.2403 5.34726 20.2403C6.24756 20.2403 7.03368 19.5997 7.21455 18.7166ZM20.3766 8.17265H16.2651V10.4623H20.9485L20.3766 8.17265ZM16.3257 5.68494V7.20768H20.6201V6.40943C20.6202 6.31433 20.6016 6.22015 20.5653 6.13225C20.529 6.04436 20.4757 5.96449 20.4085 5.8972C20.3413 5.82991 20.2615 5.77653 20.1737 5.74011C20.0859 5.70369 19.9917 5.68494 19.8966 5.68494H16.3257ZM22.5551 10.4623C23.3533 10.4623 24 11.11 24 11.9093V18.0911C24 18.4903 23.6767 18.8146 23.2775 18.8146H21.483C21.4769 18.8459 21.4729 18.8783 21.4658 18.9106C21.331 19.5573 20.9781 20.1381 20.4662 20.5557C19.9542 20.9732 19.3144 21.2022 18.6538 21.2043C17.9931 21.2022 17.3533 20.9732 16.8414 20.5557C16.3294 20.1381 15.9765 19.5573 15.8417 18.9106L15.8245 18.8146H8.17447C8.17043 18.8459 8.16437 18.8783 8.1583 18.9106C8.02349 19.5573 7.67057 20.1381 7.15865 20.5557C6.64672 20.9732 6.00687 21.2022 5.34624 21.2043C4.68562 21.2022 4.04577 20.9732 3.53384 20.5557C3.02191 20.1381 2.669 19.5573 2.53419 18.9106L2.51701 18.8146H0.722466C0.627458 18.8145 0.533406 18.7956 0.445681 18.7592C0.357955 18.7227 0.278274 18.6693 0.211187 18.602C0.1441 18.5347 0.0909206 18.4549 0.0546852 18.3671C0.0184497 18.2792 -0.000132079 18.1851 7.06664e-07 18.0901V3.12347C7.06664e-07 2.72334 0.323342 2.4 0.722466 2.4H15.5426C15.9417 2.4 16.2651 2.72334 16.2651 3.12347V4.71997H20.1371C20.9353 4.71997 21.583 5.36867 21.583 6.16793V7.44917C21.5831 7.55419 21.5603 7.65798 21.5162 7.75327C21.472 7.84856 21.4076 7.93306 21.3274 8.00087L21.9427 10.4623H22.5551Z"
                                                                            fill="#3598DC"></path>
                                                                        </g>
                                                                    </svg>
                                                                </div>
                                                                <svg width="54" height="54" viewBox="0 0 54 54" class="w-full h-full flex-shrink-0 stroke-[4px]">
                                                                    <circle cx="27" cy="27" r="24" stroke="#c8cdda" fill="white" class="stroke-[4px]"></circle>
                                                                    <circle cx="27" cy="27" r="24" fill="none" stroke="rgb(var(--color-primary-dark))" class="stroke-[4px]" style="stroke-dasharray: 285; stroke-dashoffset: 209; transform: rotate(0deg) rotate3d(0, 0, 1, 270deg); transform-origin: center center;"></circle>
                                                                    <line id="line1" x1="27" y1="27" x2="27" y2="1" class="stroke-white stroke-[4px]"></line>
                                                                    <line id="line2" x1="27" y1="27" x2="49.51666049839541" y2="40" class="stroke-white stroke-[4px]"></line>
                                                                    <line id="line3" x1="27" y1="27" x2="4.483339501604593" y2="40" class="stroke-white stroke-[4px]"></line>
                                                                </svg>
                                                            </div>
                                                            <div class="ml-0 mr-auto grid mr-5">
                                                                <h3 class="text-base sm:text-xl font-bold mb-0">Pacote em movimento</h3><span class="text-xs sm:text-sm">Seu pacote está sendo transferido entre as unidades da transportadora</span></div>
                                                                                                                    
                                                    <?php else: ?>
                                                    <div class="relative flex w-full rounded-r border-l-4 bg-white p-5 shadow text-info" type="info"><span role="img" class="mr-5 mt-3 size-7 shrink-0 grow-0"><svg viewBox="0 0 512 512" width="1em" height="1em" class="size-full"><path fill="currentColor" d="M256 56C145.72 56 56 145.72 56 256s89.72 200 200 200s200-89.72 200-200S366.28 56 256 56m0 82a26 26 0 1 1-26 26a26 26 0 0 1 26-26m48 226h-88a16 16 0 0 1 0-32h28v-88h-16a16 16 0 0 1 0-32h32a16 16 0 0 1 16 16v104h28a16 16 0 0 1 0 32"></path></svg></span><div class="shrink grow"><h3 class="text-neutral-dark text-small mb-2 font-bold">Este pacote ainda não tem movimentação</h3><div class="text-neutral-clear text-minute"><h6>Seu código está correto? Tente novamente mais tarde. As informações podem levar algumas horas para aparecer.</h6></div><!----></div><!----></div>
                                                    
                                                        </div>
                                                        <div class="flex border border-neutral-light rounded mt-6"><div class="bg-neutral-bright flex justify-center items-center py-4 px-5"><svg fill="currentColor" width="1em" height="1em" viewBox="0 0 70 71" xmlns="http://www.w3.org/2000/svg" class="w-[47px] h-[47px] text-primary"><path opacity=".3" d="M23.187 56.83c2.546-3.442 14.96-5.675 27.728-4.989 12.767.687 21.053 4.034 18.506 7.473-.963 1.301-3.412 2.489-7.004 3.396-9.5 2.4-24.414 2.27-33.313-.291-5.204-1.497-7.41-3.58-5.915-5.592l-.002.003Zm44.677 2.407c2.373-3.21-5.357-6.333-17.265-6.971-11.908-.638-23.483 1.444-25.855 4.655-2.373 3.21 5.357 6.333 17.265 6.971 6.956.374 14.154-.18 19.329-1.488 3.348-.85 5.63-1.957 6.526-3.17v.003Z" fill="#C8CDDA"></path><path opacity=".3" d="M23.187 56.83c2.546-3.442 14.96-5.675 27.728-4.989 12.767.687 21.053 4.034 18.506 7.473-.963 1.301-3.412 2.489-7.004 3.396-9.5 2.4-24.414 2.27-33.313-.291-5.204-1.497-7.41-3.58-5.915-5.592l-.002.003Zm44.677 2.407c2.373-3.21-5.357-6.333-17.265-6.971-11.908-.638-23.483 1.444-25.855 4.655-2.373 3.21 5.357 6.333 17.265 6.971 6.956.374 14.154-.18 19.329-1.488 3.348-.85 5.63-1.957 6.526-3.17v.003Z" fill="#C8CDDA"></path><path opacity=".3" d="M22.608 56.525c2.548-3.443 14.962-5.676 27.729-4.99 12.766.687 21.052 4.034 18.506 7.473-.963 1.302-3.412 2.49-7.004 3.396-9.5 2.4-24.414 2.27-33.313-.291-5.206-1.495-7.409-3.576-5.918-5.588Zm44.678 2.402c2.364-3.209-5.37-6.327-17.274-6.966-11.904-.64-23.471 1.448-25.835 4.657-2.363 3.21 5.37 6.328 17.275 6.967 6.95.372 14.138-.182 19.308-1.489 3.35-.846 5.631-1.954 6.526-3.169Z" fill="#C8CDDA"></path><path opacity=".3" d="m2.34 70.138-.75-.197c-.67-.174-.298-.573.408-.767l26.338-7.336 3.523.918-26.308 7.326c-.88.235-2.349.28-3.21.056Z" fill="#C8CDDA"></path><path d="M12.817 21.05a.137.137 0 0 0 .015.073l-.015-.074ZM21.949 20.402C24.495 7.636 36.909-.65 49.677 1.898c12.767 2.546 21.055 14.96 18.506 27.727a23.57 23.57 0 0 1-7.005 12.595c-9.5 8.902-24.413 8.418-33.313-1.077a23.57 23.57 0 0 1-5.914-20.738l-.002-.002Zm44.677 8.914C69 17.409 61.27 5.832 49.361 3.46 37.453 1.087 25.878 8.818 23.505 20.725 21.133 32.632 28.863 44.209 40.77 46.58a21.985 21.985 0 0 0 25.856-17.265Z" fill="#3B3F51"></path><path d="M21.949 20.402C24.495 7.636 36.909-.65 49.677 1.898c12.767 2.546 21.055 14.96 18.506 27.727a23.57 23.57 0 0 1-7.005 12.595c-9.5 8.902-24.413 8.418-33.313-1.077a23.57 23.57 0 0 1-5.914-20.738l-.002-.002Zm44.677 8.914C69 17.409 61.27 5.832 49.361 3.46 37.453 1.087 25.878 8.818 23.505 20.725 21.133 32.632 28.863 44.209 40.77 46.58a21.985 21.985 0 0 0 25.856-17.265Z" fill="#3B3F51"></path><path d="M21.37 19.267C23.917 6.5 36.331-1.785 49.1.761c12.767 2.547 21.052 14.962 18.506 27.73a23.574 23.574 0 0 1-7.006 12.597c-9.5 8.901-24.414 8.417-33.313-1.08a23.57 23.57 0 0 1-5.916-20.741Zm44.675 8.913c2.364-11.906-5.37-23.47-17.274-25.834C36.866-.017 25.3 7.716 22.937 19.62c-2.364 11.904 5.37 23.472 17.274 25.835a21.976 21.976 0 0 0 25.834-17.274Z" fill="currentColor"></path><path d="m1.103 69.758-.751-.727c-.67-.646-.298-2.127.408-2.845l26.336-27.212 3.522 3.406L4.31 69.55c-.877.874-2.346 1.04-3.207.209Z" fill="currentColor"></path><path d="M38.343 10.947a17.33 17.33 0 0 1 1.992-.854 13.788 13.788 0 0 1 2.24-.566 14.024 14.024 0 0 1 2.515-.165c.896.007 1.837.11 2.82.308 1.363.275 2.562.696 3.598 1.266 1.038.555 1.886 1.231 2.545 2.028a6.49 6.49 0 0 1 1.36 2.633c.26.976.28 2.012.06 3.108-.213 1.054-.564 1.936-1.053 2.645a7.33 7.33 0 0 1-1.629 1.75 8.868 8.868 0 0 1-1.91 1.153c-.674.297-1.312.573-1.915.826-.602.254-1.137.522-1.603.803-.448.27-.761.612-.938 1.023l-1.167 2.861-4.292-.864.247-3.457c.028-.688.235-1.245.62-1.672a5.106 5.106 0 0 1 1.43-1.12 14.148 14.148 0 0 1 1.852-.86 16.898 16.898 0 0 0 1.927-.89 6.688 6.688 0 0 0 1.615-1.211c.475-.482.788-1.097.939-1.846.184-.915-.017-1.714-.605-2.395-.572-.678-1.426-1.131-2.561-1.36-.833-.168-1.554-.226-2.163-.176a8.834 8.834 0 0 0-1.566.27c-.448.111-.832.221-1.154.33-.32.108-.61.137-.867.085-.576-.116-.961-.432-1.156-.947l-1.18-2.706Zm-.672 25.28c.092-.459.27-.87.532-1.236.281-.376.617-.677 1.009-.9a3.64 3.64 0 0 1 1.3-.475c.49-.089 1.001-.08 1.531.027.515.104.981.291 1.399.563.42.258.767.573 1.038.945.275.359.46.764.559 1.217.115.442.127.891.035 1.35a3 3 0 0 1-.56 1.25 3.295 3.295 0 0 1-.985.906 3.792 3.792 0 0 1-1.319.448c-.488.075-.989.061-1.504-.043a4.344 4.344 0 0 1-1.425-.547 3.848 3.848 0 0 1-1.02-.92 3.605 3.605 0 0 1-.581-1.22 3.21 3.21 0 0 1-.009-1.366Z" fill="#3B3F51"></path><path d="M37.876 11.06a15.97 15.97 0 0 1 1.827-.936 12.25 12.25 0 0 1 2.059-.658c.733-.16 1.505-.25 2.315-.267.827-.03 1.694.035 2.604.192 1.259.219 2.368.59 3.329 1.117.963.513 1.752 1.153 2.368 1.922a6.437 6.437 0 0 1 1.282 2.575c.25.965.28 2 .089 3.103-.184 1.062-.498 1.957-.942 2.686a7.486 7.486 0 0 1-1.481 1.815 8.462 8.462 0 0 1-1.748 1.23c-.618.324-1.204.626-1.756.904-.553.279-1.042.568-1.47.868-.41.289-.694.642-.853 1.06l-1.044 2.907-3.966-.688.19-3.464c.019-.688.203-1.253.554-1.696a5.028 5.028 0 0 1 1.306-1.177c.52-.341 1.086-.653 1.697-.936a15.686 15.686 0 0 0 1.767-.967 6.551 6.551 0 0 0 1.475-1.277c.433-.5.714-1.128.845-1.882.16-.922-.034-1.712-.583-2.368-.535-.654-1.327-1.072-2.376-1.254-.77-.134-1.434-.163-1.995-.087a7.718 7.718 0 0 0-1.441.333c-.412.13-.765.256-1.06.377-.294.122-.56.162-.799.12-.531-.091-.89-.391-1.076-.898l-1.117-2.655Zm-.343 25.283c.08-.462.239-.88.477-1.256.254-.388.56-.702.92-.942a3.31 3.31 0 0 1 1.193-.526c.451-.11.922-.121 1.411-.036.476.082.907.25 1.296.505.39.24.713.541.967.902.257.346.433.744.528 1.192.112.437.127.886.047 1.347-.082.475-.25.9-.501 1.273a3.306 3.306 0 0 1-.899.945c-.359.24-.762.407-1.211.502-.449.095-.91.101-1.386.019a3.697 3.697 0 0 1-1.32-.488 3.489 3.489 0 0 1-.95-.877 3.603 3.603 0 0 1-.55-1.197 3.466 3.466 0 0 1-.022-1.363Z" fill="currentColor"></path></svg></div><div class="flex items-start gap-4 py-4 px-6"><!----><div class="flex flex-col gap-2"><h4 class="text-neutral-dark font-bold block">Não conseguimos encontrar seu rastreio</h4></div></div>
                                                        <?php endif; ?>

                                                        <!---->
                                                        <!---->
                                                        <!---->
                                                        </div>
                                                    </div>
                                                    


                                                    
                                                    
                                                                                                              <?php if (!empty($data['postagem'])): ?><div class="flex items-center px-5 py-2 text-xs"><span>Última atualização em <wbr><?= $ultimaAtualizacao ?></span></div><?php endif;?>
                                                </div>
                                            </div>
                                            <div class="mt-5 xl:mt-0 xl:ml-5 min-w-[320px]">
                                                <div class="flex border border-neutral-light p-5 rounded w-full mt-0 mx-auto items-center justify-center">
                                                    <div class="flex w-full text-xs">
                                                        <div class="w-[48px] h-[48px] p-2 flex justify-center items-center bg-neutral-bright"><img class="max-w-full min-h-[28px] max-w-18" src="./encomenda_files/correios.abc01ab5.svg" alt="Correios"></div>
                                                        <div class="flex flex-col justify-center ml-3"><span class="block">Código de Rastreio</span><span class="block font-bold text-base"><?= $trackingCode ?></span></div>
                                                    </div>
                                                    <script>
    document.addEventListener('DOMContentLoaded', function () {
        // Captura o botão de compartilhamento
        const shareButton = document.getElementById('share-AA448269628BR');
        
        // Função para copiar o link atual para a área de transferência
        function copyLinkToClipboard() {
            const link = window.location.href; // Pega o link atual da página
            const textArea = document.createElement('textarea');
            textArea.value = link;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            alert('Link copiado para a área de transferência!');
        }

        // Evento de clique no botão de compartilhamento
        shareButton.addEventListener('click', function() {
            copyLinkToClipboard(); // Chama a função para copiar o link
        });
    });
</script>

                                                    <div class="share-button">
                                                        <div data-v-5784ed69="" class="inline-block" style="border: 0px solid transparent; margin: 0px; --c81fc0a4: 10000;">
                                                            <div data-v-5784ed69="">
                                                                <button data-v-5784ed69-s="" class="text-primary ml-3 w-7 h-7" id="share-AA448269628BR" aria-label="Compartilhar rastreio">
                                                                    <svg data-v-5784ed69-s="" viewBox="0 0 512 512" fill="currentColor" width="1em" height="1em" class="w-full h-full">
                                                                        <circle cx="128" cy="256" r="48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle>
                                                                        <circle cx="384" cy="112" r="48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle>
                                                                        <circle cx="384" cy="400" r="48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle>
                                                                        <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="m169.83 279.53l172.34 96.94m0-240.94l-172.34 96.94"></path>
                                                                    </svg>
                                                                </button>
                                                            </div>
                                                            <div data-v-5784ed69="" class="popper" style="display: none;">
                                                                <div data-v-5784ed69-s="" class="shadow rounded p-4 bg-white text-base text-neutral-dark">
                                                                    <ul data-v-5784ed69-s="" class="flex items-center justify-between">
                                                                        <li data-v-5784ed69-s="">
                                                                            <button data-v-5784ed69-s="" class="hover:bg-neutral-bright rounded p-3" type="button" aria-label="Compartilhar no Facebook">
                                                                                <svg data-v-5784ed69-s="" viewBox="0 0 512 512" fill="currentColor" width="1em" height="1em" class="w-7 h-7 text-[#1877f2]">
                                                                                    <path fill="currentColor" fill-rule="evenodd" d="M480 257.35c0-123.7-100.3-224-224-224s-224 100.3-224 224c0 111.8 81.9 204.47 189 221.29V322.12h-56.89v-64.77H221V208c0-56.13 33.45-87.16 84.61-87.16c24.51 0 50.15 4.38 50.15 4.38v55.13H327.5c-27.81 0-36.51 17.26-36.51 35v42h62.12l-9.92 64.77H291v156.54c107.1-16.81 189-109.48 189-221.31Z"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </li>
                                                                        <li data-v-5784ed69-s="">
                                                                            <button data-v-5784ed69-s="" class="hover:bg-neutral-bright rounded p-3" type="button" aria-label="Compartilhar no Twitter">
                                                                                <svg data-v-5784ed69-s="" viewBox="0 0 512 512" fill="currentColor" width="1em" height="1em" class="w-7 h-7 text-[#1da1f2]">
                                                                                    <path fill="currentColor" d="M496 109.5a201.8 201.8 0 0 1-56.55 15.3a97.51 97.51 0 0 0 43.33-53.6a197.74 197.74 0 0 1-62.56 23.5A99.14 99.14 0 0 0 348.31 64c-54.42 0-98.46 43.4-98.46 96.9a93.21 93.21 0 0 0 2.54 22.1a280.7 280.7 0 0 1-203-101.3A95.69 95.69 0 0 0 36 130.4c0 33.6 17.53 63.3 44 80.7A97.5 97.5 0 0 1 35.22 199v1.2c0 47 34 86.1 79 95a100.76 100.76 0 0 1-25.94 3.4a94.38 94.38 0 0 1-18.51-1.8c12.51 38.5 48.92 66.5 92.05 67.3A199.59 199.59 0 0 1 39.5 405.6a203 203 0 0 1-23.5-1.4A278.68 278.68 0 0 0 166.74 448c181.36 0 280.44-147.7 280.44-275.8c0-4.2-.11-8.4-.31-12.5A198.48 198.48 0 0 0 496 109.5Z"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </li>
                                                                        <!---->
                                                                        <li data-v-5784ed69-s="">
                                                                            <button data-v-5784ed69-s="" class="hover:bg-neutral-bright rounded p-3" type="button" aria-label="Compartilhar no Whatsapp">
                                                                                <svg data-v-5784ed69-s="" viewBox="0 0 512 512" fill="currentColor" width="1em" height="1em" class="w-7 h-7 text-[#128c7e]">
                                                                                    <path fill="currentColor" fill-rule="evenodd" d="M414.73 97.1A222.14 222.14 0 0 0 256.94 32C134 32 33.92 131.58 33.87 254a220.61 220.61 0 0 0 29.78 111L32 480l118.25-30.87a223.63 223.63 0 0 0 106.6 27h.09c122.93 0 223-99.59 223.06-222A220.18 220.18 0 0 0 414.73 97.1ZM256.94 438.66h-.08a185.75 185.75 0 0 1-94.36-25.72l-6.77-4l-70.17 18.32l18.73-68.09l-4.41-7A183.46 183.46 0 0 1 71.53 254c0-101.73 83.21-184.5 185.48-184.5a185 185 0 0 1 185.33 184.64c-.04 101.74-83.21 184.52-185.4 184.52Zm101.69-138.19c-5.57-2.78-33-16.2-38.08-18.05s-8.83-2.78-12.54 2.78s-14.4 18-17.65 21.75s-6.5 4.16-12.07 1.38s-23.54-8.63-44.83-27.53c-16.57-14.71-27.75-32.87-31-38.42s-.35-8.56 2.44-11.32c2.51-2.49 5.57-6.48 8.36-9.72s3.72-5.56 5.57-9.26s.93-6.94-.46-9.71s-12.54-30.08-17.18-41.19c-4.53-10.82-9.12-9.35-12.54-9.52c-3.25-.16-7-.2-10.69-.2a20.53 20.53 0 0 0-14.86 6.94c-5.11 5.56-19.51 19-19.51 46.28s20 53.68 22.76 57.38s39.3 59.73 95.21 83.76a323.11 323.11 0 0 0 31.78 11.68c13.35 4.22 25.5 3.63 35.1 2.2c10.71-1.59 33-13.42 37.63-26.38s4.64-24.06 3.25-26.37s-5.11-3.71-10.69-6.48Z"></path>
                                                                                </svg>
                                                                            </button>
                                                                        </li>
                                                                    </ul>
                                                                    <div data-v-5784ed69-s="">
                                                                        <div data-v-5784ed69-s="" class="border-neutral-light inline-flex h-12 w-auto items-center rounded border-[1px] bg-white pl-5 share-copy" alt="false" minimal="false"><span class="text-neutral-dark max-w-full truncate">https://app.melhorrastreio.com.br/app/correios/AA448269628BR</span>
                                                                            <button type="button" class="me-button me-button--minimal me-button--icon-only me-button--primary"><span class="me-button__content"><span class="me-button__icon" role="img"><svg viewBox="0 0 512 512" width="1em" height="1em"><rect width="336" height="336" x="128" y="128" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32" rx="57" ry="57"></rect><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="m383.5 128l.5-24a56.16 56.16 0 0 0-56-56H112a64.19 64.19 0 0 0-64 64v216a56.16 56.16 0 0 0 56 56h24"></path></svg></span>
                                                                                <!---->
                                                                                <!---->
                                                                                </span>
                                                                                <!---->
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!---->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!---->
                                            </div>
                                        </div>
                                        <!---->
                                        <!---->
                                    </div>
                                    <!---->
                                    <ul class="relative mt-6 z-0">

                                        <?php if (isset($movimentacoes) && count($movimentacoes) > 0): ?>
    <?php foreach ($movimentacoes as $mov): ?>
                                        <li class="flex">
                                            <div class="flex">
                                                <div class="w-14 text-right mr-3 text-neutral-clear text-xs"><span class="block font-bold"><?= $mov['data_formatada'] ?></span><span class="block"><?= $mov['hora_formatada'] ?></span></div>
                                                <div class="flex flex-col relative w-7">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mt-2 bg-white absolute top-0 z-10">
                                                        <g id="movement_svg__ICON____truck">
                                                            <path id="movement_svg__Vector" fill-rule="evenodd" clip-rule="evenodd" d="M13.3479 16.0106C13.5935 16.0106 13.7915 16.2117 13.7915 16.4583C13.7921 16.5763 13.7458 16.6897 13.6628 16.7736C13.5798 16.8575 13.4669 16.9051 13.3489 16.9059H11.5473C11.4293 16.9051 11.3164 16.8575 11.2335 16.7736C11.1505 16.6897 11.1042 16.5763 11.1047 16.4583C11.1047 16.2117 11.3038 16.0106 11.5473 16.0106H13.3489H13.3479ZM13.5126 4.36834C13.7652 4.36834 13.9704 4.56941 13.9704 4.81596C13.9688 4.93594 13.9197 5.05039 13.8339 5.13428C13.7481 5.21817 13.6326 5.26467 13.5126 5.26359H2.96464C2.84483 5.2644 2.72956 5.21779 2.644 5.13392C2.55843 5.05006 2.50951 4.93576 2.50792 4.81596C2.50792 4.56941 2.71304 4.36834 2.96464 4.36834H13.5136H13.5126ZM18.6275 17.6223C18.7248 17.6171 18.8221 17.6318 18.9135 17.6655C19.0049 17.6992 19.0885 17.7511 19.1592 17.8181C19.2299 17.8852 19.2862 17.9659 19.3246 18.0554C19.3631 18.1449 19.383 18.2413 19.383 18.3387C19.383 18.4361 19.3631 18.5325 19.3246 18.622C19.2862 18.7115 19.2299 18.7922 19.1592 18.8593C19.0885 18.9263 19.0049 18.9782 18.9135 19.0119C18.8221 19.0456 18.7248 19.0603 18.6275 19.0551C18.4441 19.0454 18.2714 18.9656 18.145 18.8323C18.0186 18.6991 17.9481 18.5224 17.9481 18.3387C17.9481 18.155 18.0186 17.9783 18.145 17.845C18.2714 17.7118 18.4441 17.632 18.6275 17.6223ZM5.37353 17.6223C5.47081 17.6171 5.56812 17.6318 5.65953 17.6655C5.75095 17.6992 5.83455 17.7511 5.90524 17.8181C5.97592 17.8852 6.03222 17.9659 6.07069 18.0554C6.10916 18.1449 6.129 18.2413 6.129 18.3387C6.129 18.4361 6.10916 18.5325 6.07069 18.622C6.03222 18.7115 5.97592 18.7922 5.90524 18.8593C5.83455 18.9263 5.75095 18.9782 5.65953 19.0119C5.56812 19.0456 5.47081 19.0603 5.37353 19.0551C5.1901 19.0454 5.01741 18.9656 4.89102 18.8323C4.76463 18.6991 4.69418 18.5224 4.69418 18.3387C4.69418 18.155 4.76463 17.9783 4.89102 17.845C5.01741 17.7118 5.1901 17.632 5.37353 17.6223ZM23.029 13.0632H22.1095V13.5735C22.1095 13.7856 22.2812 13.9594 22.4944 13.9594H23.03V13.0632H23.029ZM21.483 17.8496H23.037V14.9234H22.1095C21.8538 14.9234 21.6086 14.8218 21.4278 14.6411C21.2471 14.4603 21.1455 14.2151 21.1455 13.9594V12.8227C21.1455 12.4226 21.4688 12.0992 21.868 12.0992H23.034C23.0212 11.9168 22.9398 11.7461 22.8061 11.6214C22.6724 11.4967 22.4964 11.4273 22.3136 11.4273H16.2802V12.3912C16.2802 12.5191 16.2295 12.6417 16.1391 12.732C16.0487 12.8224 15.9261 12.8732 15.7982 12.8732C15.6704 12.8732 15.5478 12.8224 15.4574 12.732C15.367 12.6417 15.3163 12.5191 15.3163 12.3912V10.4623H15.3011V3.36396H0.962951V17.8496H2.51802C2.63366 17.1824 2.98059 16.5771 3.49795 16.1402C4.01532 15.7032 4.67005 15.4623 5.34726 15.4599C6.70327 15.4599 7.88548 16.4239 8.15931 17.7526L8.17649 17.8496H15.3011L15.3163 17.8648V14.7223C15.3163 14.5945 15.367 14.4719 15.4574 14.3815C15.5478 14.2911 15.6704 14.2403 15.7982 14.2403C15.9261 14.2403 16.0487 14.2911 16.1391 14.3815C16.2295 14.4719 16.2802 14.5945 16.2802 14.7223V16.72C16.5437 16.3329 16.8975 16.0158 17.3111 15.7962C17.7246 15.5767 18.1855 15.4613 18.6538 15.4599C20.0098 15.4599 21.192 16.4239 21.4658 17.7526L21.483 17.8496ZM20.521 18.7166C20.5728 18.4626 20.5728 18.2007 20.521 17.9466C20.4314 17.5173 20.197 17.1317 19.8571 16.8545C19.5172 16.5773 19.0924 16.4253 18.6538 16.4239C18.3709 16.4251 18.0919 16.4891 17.8367 16.6111C17.5815 16.733 17.3566 16.9101 17.178 17.1294C16.9994 17.3488 16.8717 17.605 16.804 17.8796C16.7363 18.1542 16.7303 18.4404 16.7865 18.7176C16.9673 19.5997 17.7524 20.2403 18.6538 20.2403C19.5541 20.2403 20.3402 19.5997 20.521 18.7166ZM7.21455 18.7166C7.26627 18.4626 7.26627 18.2007 7.21455 17.9466C7.12493 17.5173 6.89054 17.1317 6.55062 16.8545C6.2107 16.5773 5.78587 16.4253 5.34726 16.4239C5.06442 16.4251 4.78538 16.4891 4.5302 16.6111C4.27502 16.733 4.05006 16.9101 3.87149 17.1294C3.69293 17.3488 3.5652 17.605 3.4975 17.8796C3.4298 18.1542 3.42381 18.4404 3.47996 18.7176C3.66184 19.5997 4.44594 20.2403 5.34726 20.2403C6.24756 20.2403 7.03368 19.5997 7.21455 18.7166ZM20.3766 8.17265H16.2651V10.4623H20.9485L20.3766 8.17265ZM16.3257 5.68494V7.20768H20.6201V6.40943C20.6202 6.31433 20.6016 6.22015 20.5653 6.13225C20.529 6.04436 20.4757 5.96449 20.4085 5.8972C20.3413 5.82991 20.2615 5.77653 20.1737 5.74011C20.0859 5.70369 19.9917 5.68494 19.8966 5.68494H16.3257ZM22.5551 10.4623C23.3533 10.4623 24 11.11 24 11.9093V18.0911C24 18.4903 23.6767 18.8146 23.2775 18.8146H21.483C21.4769 18.8459 21.4729 18.8783 21.4658 18.9106C21.331 19.5573 20.9781 20.1381 20.4662 20.5557C19.9542 20.9732 19.3144 21.2022 18.6538 21.2043C17.9931 21.2022 17.3533 20.9732 16.8414 20.5557C16.3294 20.1381 15.9765 19.5573 15.8417 18.9106L15.8245 18.8146H8.17447C8.17043 18.8459 8.16437 18.8783 8.1583 18.9106C8.02349 19.5573 7.67057 20.1381 7.15865 20.5557C6.64672 20.9732 6.00687 21.2022 5.34624 21.2043C4.68562 21.2022 4.04577 20.9732 3.53384 20.5557C3.02191 20.1381 2.669 19.5573 2.53419 18.9106L2.51701 18.8146H0.722466C0.627458 18.8145 0.533406 18.7956 0.445681 18.7592C0.357955 18.7227 0.278274 18.6693 0.211187 18.602C0.1441 18.5347 0.0909206 18.4549 0.0546852 18.3671C0.0184497 18.2792 -0.000132079 18.1851 7.06664e-07 18.0901V3.12347C7.06664e-07 2.72334 0.323342 2.4 0.722466 2.4H15.5426C15.9417 2.4 16.2651 2.72334 16.2651 3.12347V4.71997H20.1371C20.9353 4.71997 21.583 5.36867 21.583 6.16793V7.44917C21.5831 7.55419 21.5603 7.65798 21.5162 7.75327C21.472 7.84856 21.4076 7.93306 21.3274 8.00087L21.9427 10.4623H22.5551Z"
                                                            fill="#3598DC"></path>
                                                        </g>
                                                    </svg>
                                                    <div class="h-full border-r-2 border-dashed border-neutral-light self-center absolute"></div>
                                                </div>
                                            </div>
                                            <div class="ml-3 mb-6">
                                                <h3 class="font-bold text-neutral-dark"><?= $mov['titulo'] ?></h3>
                                                <p class="text-neutral-medium text-xs"><?= $mov['descricao'] ?></p>
                                                <div class="flex mt-3"><span class="flex justify-center items-center mr-[6px] text-primary"><svg viewBox="0 0 512 512" fill="currentColor" width="1em" height="1em"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 48c-79.5 0-144 61.39-144 137c0 87 96 224.87 131.25 272.49a15.77 15.77 0 0 0 25.5 0C304 409.89 400 272.07 400 185c0-75.61-64.5-137-144-137Z"></path><circle cx="256" cy="192" r="48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle></svg></span>
                                                    <div
                                                    class="flex flex-col text-neutral-medium text-xs">
                                                        <p><?= $mov['de'] ?></p>
                                                        <p class="first-letter:uppercase"><b>Destino: </b><?= $mov['para'] ?></p>
                                                </div>
                                            </div>
                                            <!---->
                                </div>
                                </li>
                                    <?php endforeach; ?>
<?php endif; ?>
                                        <?php if (isset($postagem)): ?>
                        <li class="flex">
                            <div class="flex">
                                <div class="w-14 text-right mr-3 text-neutral-clear text-xs"><span class="block font-bold"><?= $postagem['data_formatada'];?></span><span class="block"><?= $postagem['hora_formatada'];?></span></div>
                                <div class="flex flex-col relative w-7">
                                    <svg width="23" height="24" viewBox="0 0 23 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mt-2 bg-white absolute top-0 z-10">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.42047 0.465155C9.93944 0.163035 10.5048 0 11.1441 0C11.7833 0 12.3487 0.163051 12.8677 0.465197L21.0121 5.20502C21.4002 5.43116 21.7224 5.755 21.9464 6.14432C22.1705 6.53363 22.2886 6.97484 22.2892 7.42403L22.2892 7.42507V16.5744C22.2891 17.0237 22.1713 17.4653 21.9475 17.8549C21.7237 18.2445 21.4018 18.5687 21.0137 18.7952L12.8683 23.5356C12.3449 23.8398 11.7504 24 11.1451 24C10.5398 24 9.94533 23.8398 9.42201 23.5356L1.27707 18.7955C0.888728 18.5692 0.566461 18.2451 0.34239 17.8555C0.118318 17.4659 0.000267049 17.0243 0 16.5749L3.9243e-07 7.42403C0.000548225 6.97484 0.118733 6.53363 0.34279 6.14432C0.566848 5.755 0.888964 5.43116 1.27708 5.20502L9.42047 0.465155C9.4205 0.46514 9.42045 0.465169 9.42047 0.465155ZM11.1441 1.71455C10.8178 1.71455 10.5488 1.7922 10.283 1.94693L2.14024 6.68645C2.14024 6.68645 2.14025 6.68645 2.14024 6.68645C2.01088 6.76183 1.9035 6.86978 1.82882 6.99955C1.7542 7.1292 1.71481 7.27612 1.71455 7.42571V16.5741C1.71469 16.7238 1.75404 16.8709 1.82868 17.0007C1.90334 17.1305 2.0107 17.2385 2.14008 17.314C2.14002 17.3139 2.14013 17.314 2.14008 17.314L10.2836 22.0533C10.2835 22.0532 10.2837 22.0533 10.2836 22.0533C10.2836 22.0533 10.2839 22.0535 10.284 22.0535C10.5456 22.2054 10.8427 22.2854 11.1451 22.2854C11.4478 22.2854 11.745 22.2053 12.0067 22.0533L20.1495 17.3144C20.1495 17.3144 20.1495 17.3143 20.1495 17.3144C20.2788 17.2389 20.3862 17.1308 20.4607 17.0009C20.5353 16.8711 20.5746 16.7241 20.5746 16.5744C20.5746 16.5743 20.5746 16.5744 20.5746 16.5744L20.5746 7.42612C20.5746 7.42582 20.5746 7.42552 20.5746 7.42522C20.5743 7.2758 20.5349 7.12906 20.4604 6.99955C20.3857 6.86978 20.2783 6.76183 20.149 6.68645L12.0052 1.947C11.7394 1.79227 11.4703 1.71455 11.1441 1.71455Z"
                                        fill="#3598DC"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0.386259 6.09097C0.626313 5.68288 1.15174 5.54666 1.55983 5.78671L11.1446 11.4248L20.7294 5.78671C21.1375 5.54666 21.6629 5.68288 21.903 6.09097C22.143 6.49906 22.0068 7.02449 21.5987 7.26455L11.5793 13.1583C11.311 13.3161 10.9782 13.3161 10.71 13.1583L0.690519 7.26455C0.282426 7.02449 0.146204 6.49906 0.386259 6.09097Z"
                                        fill="#3598DC"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.1446 11.5621C11.6181 11.5621 12.0019 11.946 12.0019 12.4194V23.1354C12.0019 23.6089 11.6181 23.9927 11.1446 23.9927C10.6712 23.9927 10.2874 23.6089 10.2874 23.1354V12.4194C10.2874 11.946 10.6712 11.5621 11.1446 11.5621Z"
                                        fill="#3598DC"></path>
                                    </svg>
                                    <div class="h-full border-r-2 border-dashed border-neutral-light self-center absolute"></div>
                                </div>
                            </div>
                            <div class="ml-3 mb-6">
                                <h3 class="font-bold text-neutral-dark"><?=  $postagem['titulo'] ?></h3>
                                <p class="text-neutral-medium text-xs"><?=  $postagem['descricao'] ?></p>
                                <div class="flex mt-3"><span class="flex justify-center items-center mr-[6px] text-primary"><svg viewBox="0 0 512 512" fill="currentColor" width="1em" height="1em"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 48c-79.5 0-144 61.39-144 137c0 87 96 224.87 131.25 272.49a15.77 15.77 0 0 0 25.5 0C304 409.89 400 272.07 400 185c0-75.61-64.5-137-144-137Z"></path><circle cx="256" cy="192" r="48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle></svg></span>
                                    <div
                                    class="flex flex-col text-neutral-medium text-xs">
                                        <p><?=  $postagem['de'] ?></p>
                                        <!---->
                                </div>
                            </div>
                            <!---->
                </div>
                </li>
                <?php endif; ?>


                </ul>
                <!---->
                <!---->
            </div>
            <div>
                <div class="flex flex-col ml-5">
                    <div class="w-[300px] !h-[600px]">
                        <div id="wrapper-783d0f01-aaff-4ff5-9d36-3a09924d2a85" class="overflow-hidden !min-h-0 !h-0 !m-0 !p-0 invisible mx-auto"><ins id="child-783d0f01-aaff-4ff5-9d36-3a09924d2a85" class="block w-full h-full adsbygoogle" data-ad-client="ca-pub-2781922082089615" data-ad-slot="7886569192" data-ad-format="vertical" style="display: block;"></ins></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </main>
    <!---->
    </div>
    </div>
    </div>
    </div>
    <script>
        window.__NUXT_SITE_CONFIG__={defaultLocale:"en",env:"production",indexable:true,name:"mr-web",trailingSlash:false,url:"https:\u002F\u002Fapp.melhorrastreio.com.br"}
    </script>
    <script type="application/json" id="__NUXT_DATA__" data-ssr="false">[{"_errors":1,"serverRendered":2,"data":3,"state":4},{},false,{},{}]</script>
    <script>
        window.__NUXT__={};window.__NUXT__.config={public:{apiUrl:"https://api.melhorrastreio.com.br",appName:"Melhor Rastreio",appTitleTemplate:"%s | Melhor Rastreio",appUrl:"https://app.melhorrastreio.com.br/app",lpUrl:"https://melhorrastreio.com.br",graphqlUrl:"https://api.melhorrastreio.com.br/graphql",ffAuthLogin:"true",ffAuthRequestPassword:"true",ffAuthRegister:"true",ffUserGeneralConfig:"true",ffUserIntegrationConfig:"true",ffUserEmailConfig:"false",ffUserPasswordConfig:"true",ffUserPrivacyConfig:"true",ffFollowList:"true",ffFollowEdit:"true",ffFollowRemove:"true",ffFollowFilter:"true",ffParcelTimeline:"true",ffParcelFollow:"true",ffParcelEvent:"true",ffParcelShare:"true",removeAccountReasonMaxChar:"200",ffSupport:"true",ffMaintenanceMode:"false",meOAuthClientId:"9331",meOAuthScope:"users-read orders-read",meOAuthAuthorizationURI:"https://melhorenvio.com.br/oauth/authorize",auth:{redirect:{login:"/login",home:"/"}},cookieFirst:{enabled:true,key:"16a3ee2a-39d8-494c-bb0a-6842897ce880",domain:"https://app.melhorrastreio.com.br"},gtm:{id:"GTM-MGKK7F5",enabled:true,debug:false,ignoredViews:[],trackOnNextTick:false},hotjar:{id:"2352497",sv:"6",enabled:true},microsoftClarity:{enabled:true,key:"d9qybxqw64"},optimize:{id:"OPT-P2B3247",enabled:true},recaptcha:{siteKey:"6LebJsMkAAAAAK-rd32Hj0VCNnbQcJLm3H7IsB5U",enabled:true},googleAdsense:{id:"ca-pub-2781922082089615",enabled:true,test:false,onPageLoad:true,pageLevelAds:true,overlayBottom:true},userPilot:{token:"NX-716c51fa"}},app:{baseURL:"/app/",buildAssetsDir:"/files/",cdnURL:"/"}}
    </script>
    <div id="me-overlay"></div>
    <div class="bg-neutral-murk/40 pointer-events-none fixed left-0 top-0 size-full transition-opacity z-100 opacity-0"></div>
    <div id="me-dialog">
        <!---->
    </div>
    <div id="me-toasts">
        <ul class="fixed left-1/2 top-10 z-[1000] flex max-w-full -translate-x-1/2 justify-center px-4 lg:bottom-0 lg:left-0 lg:top-[unset] lg:block lg:translate-x-0 lg:p-10 pointer-events-none">
            <ul class="relative w-[370px] max-w-full"></ul>
        </ul>
    </div>
    <div id="me-loader-full-page"></div>
    <div class="z-102 fixed left-0 top-0 flex h-screen w-screen cursor-wait flex-col items-center justify-center" style="display: none;"><span class="inline-block animate-spin" role="img"><svg class="block" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56" style="width: 48px; height: 48px;"><g><circle fill="none" cx="28" cy="28" r="24" stroke="#c8cdda" stroke-width="4"></circle><circle class="transition-all delay-150 ease-out" fill="none" stroke-linecap="round" pathLength="100" stroke-dasharray="100" cx="28" cy="28" r="24" stroke="#3598dc" stroke-width="4" stroke-dashoffset="25"></circle></g></svg></span>
        <!---->
    </div>
    <div>
        <div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;">
            <div class="grecaptcha-logo">
                <iframe title="reCAPTCHA" width="256" height="60" role="presentation" name="a-i37b2d7c8f31" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation"
                src="./encomenda_files/anchor.html"></iframe>
            </div>
            <div class="grecaptcha-error"></div>
            <textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
        </div>
        <iframe style="display: none;" src="./encomenda_files/saved_resource(1).html"></iframe>
    </div>
</body>
</html>