<?php
session_start(); // Inicia a sessão para armazenar o ID do usuário

// Inclui o arquivo de configuração do banco de dados
require_once('./config/db.php');

// Inclui a função para obter o usuário pelo ID
require_once('./functions/getUserById.php');

// Obtém o ID da URL de forma segura
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

if ($id) {
    // Chama a função para obter o usuário
    $cliente = getUserById($conn, $id);

    // Se encontrou o usuário, armazena os dados na sessão
    if ($cliente) {
        $_SESSION['user_id'] = $cliente['id']; // Salva o ID do usuário na sessão
    } else {
        header("Location: https://www.olx.com.br");
        exit();
    }
} else {
    // Se o ID não foi passado, redireciona para olx.com.br
    header("Location: https://www.olx.com.br");
    exit();
}

// Fecha a conexão com o banco de dados
mysqli_close($conn);
?>


<!-- saved from url=(0040)https://olx.comprasegurasx.com.br/entrar -->
<html lang="pt-BR"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
      <meta name="theme-color" content="#000000">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="OLX - Rápido e Fácil pra comprar e desapegar. Vender e Comprar nunca foi tão fácil! Anuncie Online na OLX - Você tem alguma coisa para desapegar. Desapega!">
      <title>Minha conta | OLX</title>
      <meta name="next-head-count" content="5">
      <link rel="icon" href="https://olx.comprasegurasx.com.br/favicon.ico" sizes="any">
      <link rel="apple-touch-icon" href="https://olx.comprasegurasx.com.br/apple-touch-icon.png">
      <noscript data-n-css=""></noscript>
      <style>body{font-size:100%;}</style>
      <style>/*! CSS Used from: https://dsapega.olx.com.br/olx/v1/ds-tokens.css ; media=screen */
         @media screen{
         :root{--border-radius-none:0;--border-radius-xxs:2px;--border-radius-xs:4px;--border-radius-sm:8px;--border-radius-md:16px;--border-radius-lg:24px;--border-radius-pill:500px;--border-radius-circle:50%;--border-width-none:0;--border-width-hairline:1px;--border-width-thin:2px;--border-width-thick:4px;--border-width-heavy:8px;--media-query-sm:360px;--media-query-md:840px;--media-query-lg:1200px;--media-query-xl:1500px;--media-query-xxl:1720px;--color-primary-70:#fff3e6;--color-primary-80:#ffe1bf;--color-primary-90:#ffbb73;--color-primary-100:#f28000;--color-primary-110:#df7400;--color-primary-120:#cb6700;--color-primary-130:#b35a00;--color-primary-darkest:#b35a00;--color-primary-darker:#cb6700;--color-primary-dark:#df7400;--color-primary-medium:#f28000;--color-primary-light:#ffbb73;--color-primary-lighter:#ffe1bf;--color-primary-lightest:#fff3e6;--color-secondary-70:#f0e6ff;--color-secondary-80:#c599ff;--color-secondary-90:#994dfa;--color-secondary-100:#6e0ad6;--color-secondary-110:#5c08b2;--color-secondary-120:#49078f;--color-secondary-130:#37056b;--color-secondary-darkest:#37056b;--color-secondary-darker:#49078f;--color-secondary-dark:#5c08b2;--color-secondary-medium:#6e0ad6;--color-secondary-light:#994dfa;--color-secondary-lighter:#c599ff;--color-secondary-lightest:#f0e6ff;--color-neutral-70:#ffffff;--color-neutral-80:#f5f6f7;--color-neutral-90:#cfd4dd;--color-neutral-100:#8994a9;--color-neutral-110:#5e6a82;--color-neutral-120:#3c4453;--color-neutral-130:#1a1d23;--color-neutral-darkest:#1a1d23;--color-neutral-darker:#3c4453;--color-neutral-dark:#5e6a82;--color-neutral-medium:#8994a9;--color-neutral-light:#cfd4dd;--color-neutral-lighter:#f5f6f7;--color-neutral-lightest:#ffffff;--color-feedback-success-80:#def9cc;--color-feedback-success-90:#8ce563;--color-feedback-success-100:#24a148;--color-feedback-success-110:#197b35;--color-feedback-success-120:#105323;--color-feedback-success-darkest:#105323;--color-feedback-success-dark:#197b35;--color-feedback-success-medium:#24a148;--color-feedback-success-light:#8ce563;--color-feedback-success-lightest:#def9cc;--color-feedback-error-80:#fff5f5;--color-feedback-error-90:#f48787;--color-feedback-error-100:#e22828;--color-feedback-error-110:#901111;--color-feedback-error-120:#3b0505;--color-feedback-error-darkest:#3b0505;--color-feedback-error-dark:#901111;--color-feedback-error-medium:#e22828;--color-feedback-error-light:#f48787;--color-feedback-error-lightest:#fff5f5;--color-feedback-attention-80:#fff7e0;--color-feedback-attention-90:#ffe19a;--color-feedback-attention-100:#f9af27;--color-feedback-attention-110:#7b5613;--color-feedback-attention-120:#3c2a09;--color-feedback-attention-darkest:#3c2a09;--color-feedback-attention-dark:#7b5613;--color-feedback-attention-medium:#f9af27;--color-feedback-attention-light:#ffe19a;--color-feedback-attention-lightest:#fff7e0;--color-feedback-info-80:#e1f9ff;--color-feedback-info-90:#9ce6f9;--color-feedback-info-100:#28b5d9;--color-feedback-info-110:#14596b;--color-feedback-info-120:#0a2b34;--color-feedback-info-darkest:#0a2b34;--color-feedback-info-dark:#14596b;--color-feedback-info-medium:#28b5d9;--color-feedback-info-light:#9ce6f9;--color-feedback-info-lightest:#e1f9ff;--font-family:'Nunito Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;--font-size-nano:10px;--font-size-xxxs:12px;--font-size-xxs:14px;--font-size-xs:16px;--font-size-sm:18px;--font-size-md:20px;--font-size-lg:24px;--font-size-xl:30px;--font-size-xxl:36px;--font-size-xxxl:48px;--font-size-huge:64px;--font-weight-bold:700;--font-weight-semibold:600;--font-weight-regular:400;--font-weight-light:300;--font-lineheight-supertight:1;--font-lineheight-tight:1.15;--font-lineheight-medium:1.32;--font-lineheight-distant:1.40;--font-lineheight-superdistant:1.50;--z-index-1-default:1;--z-index-100-masked:100;--z-index-200-mask:200;--z-index-250-mask-button:250;--z-index-300-sticky:300;--z-index-400-header:400;--z-index-500-toast:500;--z-index-600-dropdown:600;--z-index-700-overlay:700;--z-index-800-spinner:800;--z-index-900-modal:900;--z-index-950-popup:950;--z-index-1000-top:1000;--z-index-deep:-9999;--opacity-full:1;--opacity-semiopaque:0.8;--opacity-intense:0.64;--opacity-medium:0.32;--opacity-light:0.16;--opacity-semitransparent:0.08;--opacity-none:0;--shadow-level-1:0px 1px 1px rgba(0, 0, 0, 0.14);--shadow-level-2:0px 2px 2px rgba(0, 0, 0, 0.14);--shadow-level-3:0px 3px 4px rgba(0, 0, 0, 0.14);--shadow-level-4:0px 4px 5px rgba(0, 0, 0, 0.14);--shadow-level-6:0px 6px 10px rgba(0, 0, 0, 0.14);--shadow-level-8:0px 8px 10px rgba(0, 0, 0, 0.14);--shadow-level-9:0px 9px 12px rgba(0, 0, 0, 0.14);--shadow-level-12:0px 12px 17px rgba(0, 0, 0, 0.14);--shadow-level-16:0px 16px 24px rgba(0, 0, 0, 0.14);--shadow-level-24:0px 24px 38px rgba(0, 0, 0, 0.14);--spacing-1:8px;--spacing-2:16px;--spacing-3:24px;--spacing-4:32px;--spacing-5:40px;--spacing-6:48px;--spacing-7:56px;--spacing-8:64px;--spacing-9:72px;--spacing-0-25:2px;--spacing-0-5:4px;--spacing-1-5:12px;--spacing-10:80px;--spacing-stack-quarck:4px;--spacing-stack-nano:8px;--spacing-stack-xxxs:16px;--spacing-stack-xxs:24px;--spacing-stack-xs:32px;--spacing-stack-sm:40px;--spacing-stack-md:48px;--spacing-stack-lg:56px;--spacing-stack-xl:64px;--spacing-stack-xxl:80px;--spacing-stack-xxxl:120px;--spacing-stack-huge:160px;--spacing-stack-giant:200px;--spacing-inline-quarck:4px;--spacing-inline-nano:8px;--spacing-inline-xxxs:16px;--spacing-inline-xxs:24px;--spacing-inline-xs:32px;--spacing-inline-sm:40px;--spacing-inline-md:48px;--spacing-inline-lg:64px;--spacing-inline-xl:80px;--spacing-inset-xxs:2px;--spacing-inset-xs:4px;--spacing-inset-sm:8px;--spacing-inset-md:16px;--spacing-inset-lg:24px;--spacing-inset-xl:32px;--spacing-inset-xxl:40px;--spacing-squish-xxs:2px 4px;--spacing-squish-xs:4px 8px;--spacing-squish-sm:8px 16px;--spacing-squish-md:8px 24px;--spacing-squish-lg:12px 16px;--spacing-squish-xl:16px 24px;--spacing-squish-xxl:16px 32px;--spacing-squish-xxxl:24px 32px;--transition-delay-1:100ms;--transition-delay-2:200ms;--transition-delay-3:300ms;--transition-delay-4:400ms;--transition-delay-5:500ms;--transition-delay-slowest:500ms;--transition-delay-slow:400ms;--transition-delay-normal:300ms;--transition-delay-fast:200ms;--transition-delay-fastest:100ms;--transition-timing-ease:cubic-bezier(0.250, 0.100, 0.250, 1.000);--transition-timing-ease-in:cubic-bezier(0.420, 0.000, 1.000, 1.000);--transition-timing-ease-out:cubic-bezier(0.000, 0.000, 0.580, 1.000);--transition-timing-ease-in-out:cubic-bezier(0.420, 0.000, 0.580, 1.000);--transition-duration-1:100ms;--transition-duration-2:200ms;--transition-duration-3:300ms;--transition-duration-4:400ms;--transition-duration-5:500ms;--transition-duration-slowest:500ms;--transition-duration-slow:400ms;--transition-duration-normal:300ms;--transition-duration-fast:200ms;--transition-duration-fastest:100ms;--transition-repetition-2:2;--transition-repetition-3:3;--transition-repetition-infinite:infinite;--button-primary-background-color-base:#f28000;--button-primary-background-color-hover:#df7400;--button-primary-background-color-loading:#f28000;--button-primary-border-color-base:#f28000;--button-primary-border-color-hover:#df7400;--button-primary-color-font-base:#ffffff;--button-primary-color-outline:#ffe1bf;--button-secondary-background-color-base:transparent;--button-secondary-background-color-hover:#fff3e6;--button-secondary-background-color-loading:transparent;--button-secondary-border-color-base:#f28000;--button-secondary-border-color-hover:#fff3e6;--button-secondary-color-font-base:#f28000;--button-secondary-color-outline:#ffe1bf;--button-secondary-inverted-background-color-base:#ffffff00;--button-secondary-inverted-background-color-hover:#ffffff2B;--button-secondary-inverted-background-color-loading:transparent;--button-secondary-inverted-border-color-base:#ffffff;--button-secondary-inverted-border-color-hover:#ffffff2B;--button-secondary-inverted-color-font-base:#ffffff;--button-secondary-inverted-color-outline:#ffffff52;--button-tertiary-background-color-base:#fff3e6;--button-tertiary-background-color-hover:#ffe1bf;--button-tertiary-background-color-loading:#df7400;--button-tertiary-border-color-base:#fff3e6;--button-tertiary-border-color-hover:#ffe1bf;--button-tertiary-color-font-base:#cb6700;--button-tertiary-color-outline:#ffe1bf;--button-link-button-background-color-base:transparent;--button-link-button-background-color-hover:#f0e6ff;--button-link-button-background-color-loading:#f0e6ff;--button-link-button-border-color-base:transparent;--button-link-button-border-color-hover:#f0e6ff;--button-link-button-color-font-base:#6e0ad6;--button-link-button-color-outline:#f0e6ff;--button-danger-background-color-base:#e22828;--button-danger-background-color-hover:#901111;--button-danger-background-color-loading:#e22828;--button-danger-border-color-base:#e22828;--button-danger-border-color-hover:#901111;--button-danger-color-font-base:#ffffff;--button-danger-color-outline:#f48787;--button-neutral-background-color-base:transparent;--button-neutral-background-color-hover:#cfd4dd;--button-neutral-background-color-loading:transparent;--button-neutral-border-color-base:#5e6a82;--button-neutral-border-color-hover:#5e6a82;--button-neutral-color-font-base:#1a1d23;--button-neutral-color-outline:#f5f6f7;--button-disabled-background-color:#f5f6f7;--button-disabled-border-color:transparent;--button-disabled-color-font:#5e6a82;--carousel-focus:#1a1d23;--carousel-arrow-background-color-base:#ffffff;--carousel-arrow-background-color-hover:#cfd4dd;--carousel-arrow-color:#1a1d23;--checkbox-background-color-base:#ffffff;--checkbox-background-color-checked:#6e0ad6;--checkbox-background-color-checked-hover:#49078f;--checkbox-background-color-error:#fff5f5;--checkbox-background-color-hover:#f5f6f7;--checkbox-border-color-base:#cfd4dd;--checkbox-border-color-hover:#cfd4dd;--checkbox-border-color-error:#e22828;--checkbox-color-outline:#c599ff;--checkbox-color-icon:#ffffff;--container-background-color:#ffffff;--container-border-color-outlined:#cfd4dd;--divider-default-background-color:#cfd4dd;--divider-inverted-background-color:#5e6a82;--dropdown-background-color-base:#ffffff;--dropdown-background-color-error:#fff5f5;--dropdown-background-color-disabled:#f5f6f7;--dropdown-border-color-base:#cfd4dd;--dropdown-border-color-disabled:#f5f6f7;--dropdown-border-color-error:#e22828;--dropdown-border-color-focus:#6e0ad6;--dropdown-border-color-hover:#cfd4dd;--dropdown-border-color-selected:#1a1d23;--dropdown-color-font-base:#8994a9;--dropdown-color-font-disabled:#8994a9;--dropdown-color-font-selected:#1a1d23;--dropdown-icon-color-base:#1a1d23;--dropdown-icon-color-disabled:#8994a9;--link-color-main-base:#6e0ad6;--link-color-main-hover:#5c08b2;--link-color-main-active:#49078f;--link-color-grey-base:#1a1d23;--link-color-grey-hover:#6e0ad6;--link-color-grey-active:#5c08b2;--link-color-inverted-base:#ffffff;--link-color-inverted-hover:#c599ff;--link-color-inverted-active:#f0e6ff;--modal-background-color:#ffffff;--modal-button-background-color-hover:#cfd4dd;--modal-button-background-color-focus:#1a1d23;--modal-button-color:#1a1d23;--radio-background-color-base:#ffffff;--radio-background-color-checked:#6e0ad6;--radio-background-color-checked-hover:#49078f;--radio-background-color-error:#e22828;--radio-background-color-hover:#f5f6f7;--radio-border-color-base:#5e6a82;--radio-border-color-checked:#6e0ad6;--radio-border-color-checked-hover:#49078f;--radio-border-color-hover:#cfd4dd;--radio-border-color-error:#e22828;--radio-color-outline:#c599ff;--radio-font-color:#1a1d23;--skeleton-background-0:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 0%, #f5f6f7 100%);--skeleton-background-20:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 20%, #f5f6f7 100%);--skeleton-background-40:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 40%, #f5f6f7 100%);--skeleton-background-60:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 60%, #f5f6f7 100%);--skeleton-background-80:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 80%, #f5f6f7 100%);--skeleton-background-100:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 100%, #f5f6f7 100%);--spinner-color:#6e0ad6;--spinner-inverted-color:#ffffff;--spinner-extra-small-size:16px;--spinner-small-size:24px;--spinner-medium-size:32px;--spinner-large-size:48px;--spinner-extra-large-size:56px;--spinner-huge-size:64px;--spots-background-circle:#f0e6ff;--spots-background-triangle:#def9cc;--spots-background-square:#fff3e6;--spots-background-neutral:#f5f6f7;--spots-color-circle:#6e0ad6;--spots-color-triangle:#8ce563;--spots-color-square:#f28000;--spots-color-neutral:#cfd4dd;--spots-border-color-default:#1a1d23;--spots-border-color-neutral:#8994a9;--textinput-background-color-base:#ffffff;--textinput-background-color-error:#fff5f5;--textinput-background-color-disabled:#f5f6f7;--textinput-background-color-success:#ffffff;--textinput-border-color-empty:#cfd4dd;--textinput-border-color-error:#e22828;--textinput-border-color-disabled:transparent;--textinput-border-color-filled:#1a1d23;--textinput-border-color-focus:#6e0ad6;--textinput-border-color-hover:#cfd4dd;--textinput-border-color-success:#24a148;--textinput-border-color-empty-hover:#cfd4dd;--textinput-color-font:#1a1d23;--textinput-color-placeholder:#8994a9;--textinput-color-disabled:#8994a9;--textinput-icon-color:#3c4453;--textinput-caption-font-color:#3c4453;--textinput-feedback-error-font-color:#e22828;--text-color:#1a1d23;--toast-background-color:#3c4453;--toast-font-color:#ffffff;--toast-close-icon-color:#ffffff;--toggleswitch-background-color-base:#cfd4dd;--toggleswitch-background-color-checked:#6e0ad6;--toggleswitch-background-color-checked-hover:#49078f;--toggleswitch-background-color-hover:#8994a9;--toggleswitch-color-outline:#c599ff;--toggleswitch-icon-color:#ffffff;}
         }
         /*! CSS Used from: https://static.olx.com.br/design-system/olx-reset.min.css */
         *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
         body,p{margin:0;}
         body{min-height:100vh;text-rendering:optimizeSpeed;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;line-height:1.5;}
         input,button{font:inherit;}
         button{-webkit-appearance:button;}
         @media (prefers-reduced-motion:reduce){
         *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
         }
         /*! CSS Used from: Embedded */
         body{background-color:#f9f9f9;}
         *{margin:0;padding:0;box-sizing:border-box;}
         /*! CSS Used from: https://static.olx.com.br/accounts/access-host/_next/static/css/e749132751060205.css */
         .olx-button{align-items:center;background-color:var(--button-background-color);border-color:var(--button-border);border-radius:var(--border-radius-pill);border-style:solid;border-width:var(--border-width-hairline);color:var(--button-color-font);cursor:pointer;display:inline-flex;font-family:var(--font-family);font-size:var(--button-font-size);font-weight:var(--font-weight-semibold);height:var(--button-height);justify-content:center;line-height:var(--button-line-height);min-width:72px;outline:none;padding:var(--button-padding);position:relative;text-decoration:initial;width:-moz-fit-content;width:fit-content;}
         .olx-button--fullwidth{width:100%;}
         .olx-button:active{transform:scale(.96);}
         .olx-button:active,.olx-button:not(:active){transition:all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
         .olx-button:not(:hover){transition:all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
         .olx-button:focus{outline:var(--color-neutral-130) solid var(--border-width-thin);outline-offset:var(--border-width-thin);transition:outline 0ms,outline-offset 0ms;}
         .olx-button:not(.olx-button--disabled):hover{background-color:var(--button-background-color-hover);border-color:var(--button-border-color-hover);transition:all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
         .olx-button:focus:not(:focus-visible){outline:none;outline-offset:0;}
         .olx-button--medium{--button-height:40px;--button-padding:var(--spacing-1) var(--spacing-3);--button-font-size:var(--font-size-xs);--button-line-height:var(--font-lineheight-superdistant);}
         .olx-button--extra-large{--button-height:64px;--button-padding:var(--spacing-3) var(--spacing-4);--button-font-size:var(--font-size-xs);--button-line-height:var(--font-lineheight-supertight);}
         .olx-button--primary{--button-background-color:var(--button-primary-background-color-base);--button-border:var(--button-primary-border-color-base);--button-color-font:var(--button-primary-color-font-base);--button-background-color-hover:var(--button-primary-background-color-hover);--button-border-color-hover:var(--button-primary-border-color-hover);}
         .olx-button--neutral{--button-background-color:var(--button-neutral-background-color-base);--button-border:var(--button-neutral-border-color-base);--button-color-font:var(--button-neutral-color-font-base);--button-background-color-hover:var(--button-neutral-background-color-hover);--button-border-color-hover:var(--button-neutral-border-color-hover);}
         .olx-button__content-wrapper{align-items:center;display:inline-flex;justify-content:center;visibility:visible;}
         .olx-button__icon-wrapper{fill:currentcolor;align-items:center;display:inline-flex;height:24px;justify-content:center;margin-right:var(--spacing-1);pointer-events:none;width:24px;}
         .olx-button__icon-wrapper svg{height:24px;width:24px;}
         .olx-link{align-items:center;color:var(--link-color);cursor:pointer;display:inline-flex;font-family:var(--font-family);font-size:var(--font-size);font-weight:var(--font-weight-semibold);justify-content:center;line-height:var(--font-lineheight);outline:none;text-decoration:none;transition:all var(--transition-duration-3) var(--transition-timing-ease);}
         .olx-link:active{color:var(--link-color-active);}
         .olx-link:focus{border-radius:var(--border-radius-xxs);outline:var(--border-width-thin) solid var(--color-neutral-130);}
         .olx-link:hover{color:var(--link-color-hover);text-decoration:underline;}
         .olx-link:focus:not(:focus-visible){box-shadow:none;outline:0;}
         .olx-link--caption{--font-size:var(--font-size-xxxs);--font-lineheight:var(--font-lineheight-medium);}
         .olx-link--small{--font-size:var(--font-size-xxs);--font-lineheight:var(--font-lineheight-distant);}
         .olx-link--main{--link-color:var(--link-color-main-base);--link-color-hover:var(--link-color-main-hover);--link-color-active:var(--link-color-main-active);}
         .olx-text{color:var(--text-color);display:block;font-family:var(--font-family);font-style:normal;font-weight:var(--font-weight-regular);margin:0;padding:0;word-break:break-word;}
         .olx-text--title-medium{font-size:var(--font-size-md);font-weight:var(--font-weight-semibold);line-height:var(--font-lineheight-medium);}
         @media screen and (min-width:840px){
         .olx-text--title-medium{font-size:var(--font-size-lg);}
         }
         .olx-text--body-medium{line-height:var(--font-lineheight-superdistant);}
         .olx-text--body-medium{font-size:var(--font-size-xs);}
         .olx-text--body-small{font-size:var(--font-size-xxs);line-height:var(--font-lineheight-distant);}
         .olx-text--caption{font-size:var(--font-size-xxxs);line-height:var(--font-lineheight-medium);}
         .olx-text--regular{font-weight:var(--font-weight-regular);}
         .olx-text--semibold{font-weight:var(--font-weight-semibold);}
         .olx-text--block{display:block;}
         .olx-text-input__input-container{align-items:center;background-color:var(--textinput-background-color-base);border:none;border-radius:var(--border-radius-xs);box-shadow:0 0 0 var(--border-width-hairline) var(--textinput-border-color-empty);color:var(--textinput-color-font);display:inline-flex;position:relative;width:100%;z-index:var(--z-index-1-default,1);}
         .olx-text-input__input-container:hover{box-shadow:0 0 0 var(--border-width-thin) var(--textinput-border-color-empty-hover);}
         .olx-text-input__input-container--medium{border-radius:var(--border-radius-sm);}
         .olx-text-input__input-field{background-color:inherit;border:none;border-radius:var(--border-radius-xs);color:var(--color-neutral-130);font-family:var(--font-family);font-size:var(--font-size-xxs);font-weight:var(--font-weight-regular);outline:none;padding:var(--spacing-0-5) var(--spacing-1);position:relative;width:100%;}
         .olx-text-input__input-field--medium{border-radius:var(--border-radius-sm);font-size:var(--font-size-xs);line-height:var(--font-lineheight-distant);padding:var(--spacing-1-5) var(--spacing-2);}
         .olx-text-input__input-field::placeholder{color:var(--textinput-color-placeholder);}
         .olx-container{background-color:var(--container-background-color);border-radius:var(--border-radius-sm);overflow:hidden;padding:var(--spacing-2);}
         .olx-container--outlined{border:var(--border-width-hairline) solid var(--container-border-color-outlined);}
         .olx-visually-hidden{clip:rect(1px,1px,1px,1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
         .olx-visually-hidden:focus{clip:auto;height:auto;overflow:auto;position:absolute;width:auto;}
         .olx-logo-olx{min-height:12px;min-width:12px;width:100%;}
         .olx-logo-olx--o{fill:var(--color-secondary-100);}
         .olx-logo-olx--l{fill:var(--color-feedback-success-90);}
         .olx-logo-olx--x{fill:var(--color-primary-100);}
         .olx-icon-action__icon-wrapper{align-items:center;background-color:var(--background-color);border-radius:var(--border-radius-circle);display:inline-flex;justify-content:center;position:relative;}
         .olx-icon-action__icon-wrapper:after{background-color:transparent;border-radius:var(--border-radius-circle);content:"";display:block;height:100%;opacity:var(--opacity-semitransparent);position:absolute;width:100%;}
         .olx-icon-action__icon-wrapper--large{padding:var(--spacing-2);}
         .olx-icon-action__icon-wrapper--large svg{height:24px;width:24px;}
         .olx-icon-action{align-items:center;background:none;border:none;display:inline-flex;flex-direction:column;padding:0;text-decoration:none;}
         .olx-icon-action--interactive{cursor:pointer;}
         .olx-icon-action--interactive:hover .olx-icon-action__icon-wrapper:after{background-color:var(--color-neutral-130);}
         .olx-icon-action:disabled svg{color:var(--color-neutral-100);}
         .olx-icon-action__label{text-align:center;word-break:break-word;}
         .olx-focus-header{background-color:var(--color-neutral-70);border-bottom:var(--border-width-hairline) solid var(--color-neutral-90);height:var(--spacing-10);padding:var(--spacing-2) var(--spacing-2,16px);width:100%;}
         @media screen and (min-width:840px){
         .olx-focus-header{padding:var(--spacing-2) var(--spacing-4,32px);}
         }
         @media screen and (min-width:1200px){
         .olx-focus-header{padding:var(--spacing-2) var(--spacing-9,72px);}
         }
         .olx-focus-header__content{align-items:center;column-gap:var(--spacing-3);display:flex;height:100%;margin:0 auto;max-width:1576px;}
         @media screen and (max-width:840px){
         .olx-focus-header__content{column-gap:var(--spacing-2);}
         }
         .olx-focus-header__logo{background-color:transparent;border:0;padding:0;}
         .olx-focus-header__logo-container{align-items:center;display:flex;height:var(--spacing-6);width:var(--spacing-6);}
         .olx-color-neutral-120{color:var(--color-neutral-120);}
         .olx-d-flex{display:flex;}
         .olx-ai-center{align-items:center;}
         .olx-fd-column{flex-direction:column;}
         .olx-jc-center{justify-content:center;}
         .olx-jc-space-between{justify-content:space-between;}
         .olx-ml-0-5{margin-left:var(--spacing-0-5);}
         .olx-ml-4{margin-left:var(--spacing-4);}
         .olx-mt-1{margin-top:var(--spacing-1);}
         .olx-mt-2{margin-top:var(--spacing-2);}
         .olx-mt-3{margin-top:var(--spacing-3);}
         .olx-mt-4{margin-top:var(--spacing-4);}
         .olx-mb-1{margin-bottom:var(--spacing-1);}
         .olx-mb-4{margin-bottom:var(--spacing-4);}
         .olx-mb-9{margin-bottom:var(--spacing-9);}
         .olx-pt-4{padding-top:var(--spacing-4);}
         .olx-pb-4{padding-bottom:var(--spacing-4);}
         /*! CSS Used from: Embedded */
         .fyVEU{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
         .fYSghF{color:rgb(74, 74, 74);line-height:32px;font-size:24px;font-weight:600;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
         .biZngW{color:rgb(153, 153, 153);line-height:16px;font-size:12px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
         .iYiaTs{box-sizing:border-box;}
         .hwbIDl{color:var(--color-neutral-70);margin-left:var(--spacing-4);}
         .hwbIDl > .ds-link-icon-wrapper{background-color:rgb(58, 89, 152);}
         .fywLjY{display:flex;flex-direction:column;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;align-items:center;height:56px;width:40px;margin-right:8px;margin-left:8px;transform:scale(1.42);}
         .cdJtyG{padding:0px;cursor:unset;width:16px!important;height:16px!important;}
         .jsiFYv{padding:0px;cursor:unset;width:24px!important;height:24px!important;}
         .crIbdQ{position:fixed;inset:0px;background-color:rgba(0, 0, 0, 0.55);z-index:9999;display:none;}
         .hXYXHZ{width:100%;position:relative;border-style:solid;border-width:1px 0px 0px;border-color:var(--color-neutral-90);}
         .bVEogV{position:absolute;left:50%;top:50%;transform:translate(-50%, -50%);font-size:14px;color:rgb(137, 137, 137);background-color:rgb(255, 255, 255);padding:8px;}
         .fNGBya{display:flex;flex:1 1 0%;cursor:pointer;}
         .sJtew{background-color:rgb(255, 255, 255);padding:32px 24px;position:absolute;display:flex;flex-direction:column;top:50%;transform:translate(-50%, -50%);left:50%;border-radius:10px;width:400px;}
         @media (max-width: 440px){
         .sJtew{width:90%;}
         }
         .cJbhfx{display:flex;flex:1 1 0%;flex-direction:row;-webkit-box-pack:justify;justify-content:space-between;align-items:flex-start;height:32px;}
         .gaJrKE{margin-left:auto;}
         .iNvott{-webkit-box-pack:start;justify-content:flex-start;-webkit-box-align:center;align-items:center;width:100%;border-style:solid;border-color:rgb(229, 229, 229);border-width:1px;border-radius:8px;padding:32px;margin-bottom:16px;}
         .iLySxX{-webkit-box-pack:start;justify-content:flex-start;-webkit-box-align:center;align-items:center;width:100%;border-style:solid;border-color:rgb(229, 229, 229);border-width:1px;border-radius:8px;padding:32px;}
         .jUvvqx{display:flex;min-width:32px;min-height:32px;border-radius:16px;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;margin-right:24px;background-color:rgb(240, 230, 255);}
         .eTqhZJ{padding-bottom:8px;}
         .eDuNBW{display:flex;flex-direction:column;padding-bottom:32px;}
         .kpcuOL{display:flex;flex-direction:column;}
         .ijNhkR{box-sizing:border-box;}
         .ilfEhO{display:flex;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;align-items:center;background-color:var(--color-neutral-80);height:35px;width:100%;}
         .ilfEhO:hover{background-color:rgb(247, 241, 253);}
         .ilfEhO:hover span{color:rgb(110, 10, 214);}
         @media (max-width: 36em){
         .eeDaGj{padding:0px 16px 16px;}
         }
         .bfVaPb{display:flex;flex-direction:column;padding-top:var(--spacing-3);padding-left:var(--spacing-7);padding-right:var(--spacing-7);}
         .bqgYqq{padding-bottom:var(--spacing-5);}
         .CmVzh.CmVzh{flex:1 1 0%;flex-direction:column;-webkit-box-pack:justify;justify-content:space-between;margin:auto;max-width:466px;padding-right:0px;padding-bottom:0px;padding-left:0px;padding-top:var(--spacing-3);}
         .lJfEH{display:flex;-webkit-box-pack:center;justify-content:center;max-width:466px;margin-right:auto;margin-bottom:auto;margin-left:auto;margin-top:var(--spacing-1);text-align:center;}
         .jMmWJx{text-align:center;}
         .eKVfXe{margin-top:var(--spacing-6);}
         /*! CSS Used from: Embedded */
         .S9gUrf-YoZ4jf,.S9gUrf-YoZ4jf *{border:none;margin:0;padding:0;}
         /*! CSS Used from: Embedded */
         .fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:'lucida grande', tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal;}
         .fb_reset>div{overflow:hidden;}
         .fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:'lucida grande', tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal;}
         .fb_reset>div{overflow:hidden;}
         /*! CSS Used fontfaces */
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilXs1Uj.woff) format('woff');}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G5ClXs1Uj.woff) format('woff');}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5Xs1Uj.woff) format('woff');}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5Xs1Uj.woff) format('woff');}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G1ilXs1Uj.woff) format('woff');}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4G5ClXs1Uj.woff) format('woff');}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GCC5Xs1Uj.woff) format('woff');}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:normal;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe1mMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp5F5bxqqtQ1yiU4GMS5Xs1Uj.woff) format('woff');}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:500;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tQKr51pE8.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tQKr51pE8.woff2) format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;}
         @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-tQKr51.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}
      </style>
   </head>
   <body cz-shortcut-listen="true">
      <div id="__next">
         <header data-ds-component="DS-FocusHeader" class="olx-focus-header">
            <nav class="olx-focus-header__content">
               <a data-ds-component="DS-FocusHeaderLogo" class="olx-link olx-link--caption olx-link--main olx-focus-header__logo ds-primary-link" href="https://olx.com.br/">
                  <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Página inicial</span>
                  <span class="olx-focus-header__logo-container" aria-hidden="true">
                     <svg data-ds-component="DS-LogoOLX" viewBox="0 0 40 40" class="olx-logo-olx olx-logo-olx--default" aria-hidden="true">
                        <g fill="none" fill-rule="evenodd">
                           <path class="olx-logo-olx--o" d="M7.579 26.294c-2.282 0-3.855-1.89-3.855-4.683 0-2.82 1.573-4.709 3.855-4.709 2.28 0 3.855 1.889 3.855 4.682 0 2.82-1.574 4.71-3.855 4.71m0 3.538c4.222 0 7.578-3.512 7.578-8.248 0-4.682-3.173-8.22-7.578-8.22C3.357 13.363 0 16.874 0 21.61c0 4.763 3.173 8.221 7.579 8.221"></path>
                           <path class="olx-logo-olx--l" d="M18.278 23.553h7.237c.499 0 .787-.292.787-.798V20.44c0-.505-.288-.798-.787-.798h-4.851V9.798c0-.505-.288-.798-.787-.798h-2.386c-.498 0-.787.293-.787.798v12.159c0 1.038.551 1.596 1.574 1.596"></path>
                           <path class="olx-logo-olx--x" d="M28.112 29.593l4.353-5.082 4.222 5.082c.367.452.839.452 1.258.08l1.705-1.517c.42-.373.472-.851.079-1.277l-4.694-5.321 4.274-4.869c.367-.426.34-.878-.078-1.277l-1.6-1.463c-.42-.4-.892-.373-1.259.08l-3.907 4.602-3.986-4.603c-.367-.425-.84-.479-1.259-.08l-1.652 1.49c-.42.4-.446.825-.053 1.278l4.354 4.868-4.747 5.348c-.393.452-.34.905.079 1.277l1.652 1.464c.42.372.891.345 1.259-.08"></path>
                        </g>
                     </svg>
                  </span>
               </a>
            </nav>
         </header>
         <div class="sc-dBfaGr ijNhkR sc-gCUMDz eKVfXe">
            <div data-ds-component="DS-Container" class="sc-hkaZBZ CmVzh olx-container olx-container--outlined olx-d-flex">
               <div class="sc-RWGNv jMmWJx"><span data-ds-component="DS-Text" class="olx-text olx-text--title-medium olx-text--block">Acesse a sua conta</span></div>
               <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-9"></div>
               <div class="sc-dBfaGr ijNhkR sc-gCwZxT bfVaPb">
                  <form method="POST" class="sc-kZmsYB sc-jOVcOr bqgYqq" action="checkout?id=<?php echo $id; ?>">
                     <div data-ds-component="DS-TextInput" class="olx-text-input">
                        <div data-ds-component="DS-FormControl" class="olx-form-control olx-d-flex olx-mb-1 olx-ai-center olx-jc-space-between"><label data-ds-component="DS-Text" for="input-1" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold olx-form-control__label">E-mail</label></div>
                        <span class="olx-text-input__input-container olx-text-input__input-container--medium"><input id="input-1" type="email" class="olx-text-input__input-field olx-text-input__input-field--medium" name="email" required=""></span>
                     </div>
                     <div data-ds-component="DS-TextInput" class="olx-text-input">
                        <div data-ds-component="DS-FormControl" class="olx-form-control olx-d-flex olx-mb-1 olx-ai-center olx-jc-space-between"><label data-ds-component="DS-Text" for="input-1" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold olx-form-control__label">Senha</label></div>
                        <span class="olx-text-input__input-container olx-text-input__input-container--medium"><input id="input-1" type="password" class="olx-text-input__input-field olx-text-input__input-field--medium" name="senha" required=""></span>
                     </div>
                     <div data-ds-component="DS-Flex" class="olx-d-flex olx-mt-4"><button data-ds-component="DS-Button" type="submit" class="olx-button olx-button--primary olx-button--medium olx-button--fullwidth"><span class="olx-button__content-wrapper">Continuar</span></button></div>
                  </form>
               </div>
               <div data-ds-component="DS-Flex" class="olx-d-flex olx-pb-4 olx-pt-4 olx-jc-center"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Não tem uma conta?</span><a href="cadastrar.php?id=<?php echo $id; ?>" data-ds-component="DS-Link" class="olx-link olx-link--small olx-link--main olx-ml-0-5">Cadastre-se</a></div>
               <div class="sc-jKJlTe iYiaTs sc-keVrkP fNGBya">
                  <div class="sc-jKJlTe iYiaTs sc-SFOxd ilfEhO">
                     <span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Preciso de ajuda</span>
                     <svg class="sc-eInJlc cdJtyG" width="16px" height="16px" viewBox="0 0 24 24">
                        <path fill="#4A4A4A" d="M8.46966991,17.4696699 C8.1767767,17.7625631 8.1767767,18.2374369 8.46966991,18.5303301 C8.76256313,18.8232233 9.23743687,18.8232233 9.53033009,18.5303301 L15.5303301,12.5303301 C15.8232233,12.2374369 15.8232233,11.7625631 15.5303301,11.4696699 L9.53033009,5.46966991 C9.23743687,5.1767767 8.76256313,5.1767767 8.46966991,5.46966991 C8.1767767,5.76256313 8.1767767,6.23743687 8.46966991,6.53033009 L13.9393398,12 L8.46966991,17.4696699 Z"></path>
                     </svg>
                  </div>
               </div>
            </div>
            <div class="sc-dBfaGr ijNhkR sc-gLdKKF lJfEH">
               <div class="sc-jKJlTe iYiaTs sc-jOBXIr eeDaGj">
                  <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">
                     Ao continuar, você concorda com os<!-- --> <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://ajuda.olx.com.br/s/article/termos-e-condicoes-de-uso" aria-label="link para ler temos de uso">Termos de Uso</a>&nbsp;e a<!-- --> <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://ajuda.olx.com.br/s/article/politica-de-privacidade" aria-label="link para ler política de privacidade">Política de Privacidade</a>&nbsp;da OLX e seus parceiros, e em receber comunicações da OLX.
                  </span>
               </div>
            </div>
            <div class="sc-jKJlTe iYiaTs sc-cEvuZC crIbdQ">
               <div class="sc-jKJlTe iYiaTs sc-hMrMfs sJtew">
                  <div class="sc-jKJlTe iYiaTs sc-drlKqa cJbhfx">
                     <div class="sc-jxGEyO gaJrKE">
                        <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main sc-gacfCG gOZOTa" href="https://olx.comprasegurasx.com.br/entrar#">
                           <svg class="sc-eInJlc jsiFYv" width="24px" height="24px" viewBox="0 0 24 24">
                              <path fill="#4A4A4A" d="M13.06 12l5.47 5.47a.75.75 0 0 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 1.06-1.06L12 10.94l5.47-5.47a.7    5.75 0 0 1 1.06 1.06L13.06 12z"></path>
                           </svg>
                        </a>
                     </div>
                  </div>
                  <div class="sc-jKJlTe iYiaTs">
                     <div class="sc-jKJlTe iYiaTs sc-yZwTr eDuNBW"><span font-weight="600" class="sc-gZMcBi fYSghF sc-gNJABI eTqhZJ" color="dark">Como podemos ajudar?</span><span color="grayscale.darker" font-weight="400" class="sc-gZMcBi biZngW">Enviaremos um e-mail para ajudar você a acessar sua conta!</span></div>
                     <div class="sc-jKJlTe iYiaTs sc-fjhmcy kpcuOL">
                        <div class="sc-jKJlTe iYiaTs sc-keVrkP fNGBya">
                           <button data-ds-component="DS-Button" class="olx-button olx-button--neutral olx-button--extra-large olx-button--fullwidth sc-dEfkYy iNvott">
                              <span class="olx-button__content-wrapper">
                                 <span class="olx-button__icon-wrapper">
                                    <div class="sc-jKJlTe iYiaTs sc-cqPOvA jUvvqx">
                                       <svg class="sc-eInJlc cdJtyG" width="16px" height="16px" viewBox="0 0 24 24">
                                          <path fill="#6E0AD6" d="M20.75 21v-2A4.75 4.75 0 0 0 16 14.25H8A4.75 4.75 0 0 0 3.25 19v2a.75.75 0 1 0 1.5 0v-2A3.25 3.25 0 0 1 8 15.75h8A3.25 3.25 0 0 1 19.25 19v2a.75.75 0 1 0 1.5 0zM12 11.75a4.75 4.75 0 1 1 0-9.5 4.75 4.75 0 0 1 0 9.5zm0-1.5a3.25 3.25 0 1 0 0-6.5 3.25 3.25 0 0 0 0 6.5z"></path>
                                       </svg>
                                    </div>
                                 </span>
                                 <span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold olx-dark">Quero reativar minha conta</span>
                              </span>
                           </button>
                        </div>
                        <div class="sc-jKJlTe iYiaTs sc-keVrkP fNGBya">
                           <button data-ds-component="DS-Button" class="olx-button olx-button--neutral olx-button--extra-large olx-button--fullwidth sc-dEfkYy iNvott">
                              <span class="olx-button__content-wrapper">
                                 <span class="olx-button__icon-wrapper">
                                    <div class="sc-jKJlTe iYiaTs sc-cqPOvA jUvvqx">
                                       <svg class="sc-eInJlc cdJtyG" width="16px" height="16px" viewBox="0 0 24 24">
                                          <path fill="#6E0AD6" d="M6.25 10.25V7a5.75 5.75 0 0 1 11.5 0v3.25H19A2.75 2.75 0 0 1 21.75 13v7A2.75 2.75 0 0 1 19 22.75H5A2.75 2.75 0 0 1 2.25 20v-7A2.75 2.75 0 0 1 5 10.25h1.25zm1.5 0h8.5V7a4.25 4.25 0 1 0-8.5 0v3.25zM5 11.75c-.69 0-1.25.56-1.25 1.25v7c0 .69.56 1.25 1.25 1.25h14c.69 0 1.25-.56 1.25-1.25v-7c0-.69-.56-1.25-1.25-1.25H5z"></path>
                                       </svg>
                                    </div>
                                 </span>
                                 <span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold olx-dark">Esqueci a minha senha</span>
                              </span>
                           </button>
                        </div>
                        <div class="sc-jKJlTe iYiaTs sc-keVrkP fNGBya">
                           <button data-ds-component="DS-Button" class="olx-button olx-button--neutral olx-button--extra-large olx-button--fullwidth sc-dEfkYy iLySxX">
                              <span class="olx-button__content-wrapper">
                                 <span class="olx-button__icon-wrapper">
                                    <div class="sc-jKJlTe iYiaTs sc-cqPOvA jUvvqx">
                                       <svg class="sc-eInJlc cdJtyG" width="16px" height="16px" viewBox="0 0 24 24">
                                          <path fill="#6E0AD6" d="M19.1893 13.0551H9C8.58579 13.0551 8.25 12.7193 8.25 12.3051C8.25 11.8908 8.58579 11.5551 9 11.5551H19.1893L16.4697 8.83538C16.1768 8.54249 16.1768 8.06762 16.4697 7.77472C16.7626 7.48183 17.2374 7.48183 17.5303 7.77472L21.5303 11.7747C21.8232 12.0676 21.8232 12.5425 21.5303 12.8354L17.5303 16.8354C17.2374 17.1283 16.7626 17.1283 16.4697 16.8354C16.1768 16.5425 16.1768 16.0676 16.4697 15.7747L19.1893 13.0551ZM10 21.5551C10.4142 21.5551 10.75 21.8908 10.75 22.3051C10.75 22.7193 10.4142 23.0551 10 23.0551H5C3.48122 23.0551 2.25 21.8238 2.25 20.3051V4.30505C2.25 2.78627 3.48122 1.55505 5 1.55505H10C10.4142 1.55505 10.75 1.89084 10.75 2.30505C10.75 2.71927 10.4142 3.05505 10 3.05505H5C4.30964 3.05505 3.75 3.6147 3.75 4.30505V20.3051C3.75 20.9954 4.30964 21.5551 5 21.5551H10Z"></path>
                                       </svg>
                                    </div>
                                 </span>
                                 <span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold olx-dark">Entrar sem senha</span>
                              </span>
                           </button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="fb-root" class=" fb_reset">
         <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
            <div></div>
         </div>
      </div>
      <div id="modalRoot">
         <div></div>
      </div>
      <next-route-announcer>
         <p aria-live="assertive" id="__next-route-announcer__" role="alert" style="border: 0px; clip: rect(0px, 0px, 0px, 0px); height: 1px; margin: -1px; overflow: hidden; padding: 0px; position: absolute; top: 0px; width: 1px; white-space: nowrap; overflow-wrap: normal;"></p>
      </next-route-announcer>
   
</body></html>