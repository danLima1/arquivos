<?php
require_once '../config/db.php'; // Certifique-se de que este arquivo contém a conexão com o banco de dados

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $dados = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($dados['codigo'], $dados['cliente_nome'], $dados['cliente_cpf'], $dados['cliente_endereco'], $dados['userId'])) {
            echo json_encode(["erro" => "Dados incompletos."]);
            http_response_code(400);
            exit;
        }

        // Gera o código
        $codigo_gerado = $dados["codigo"] . strtoupper(bin2hex(random_bytes(4))) . "BR";
        $codigo_gerado = substr($codigo_gerado, 0, 14);
        
        // Prepara a query
        $stmt = $conn->prepare("INSERT INTO rastreios (codigo, cliente_nome, cliente_cpf, cliente_endereco, userId) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $codigo_gerado, $dados['cliente_nome'], $dados['cliente_cpf'], $dados['cliente_endereco'], $dados['userId']);
        
        if ($stmt->execute()) {
            echo json_encode(["mensagem" => "Rastreamento cadastrado com sucesso!", "codigo" => $codigo_gerado]);
        } else {
            echo json_encode(["erro" => "Erro ao cadastrar rastreamento."]);
            http_response_code(500);
        }
    } catch (Exception $e) {
        echo json_encode(["erro" => "Erro interno: " . $e->getMessage()]);
        http_response_code(500);
    }
} else {
    echo json_encode(["erro" => "Método não permitido."]);
    http_response_code(405);
}
