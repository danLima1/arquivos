<?php
session_start();
require_once '../config/db.php'; // O arquivo db.php deve definir a variável $conn

// Opcional: Verifica se o usuário está logado (adicione se necessário)
if (!isset($_SESSION['username'])) {
     header("Location: /");
    exit();
 }

// Verifica se o ID do cliente foi passado e se é um número inteiro válido
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $id = $_GET['id'];

    // Utiliza prepared statement para evitar SQL injection
    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
    if (!$stmt) {
        die("Erro na preparação da consulta: " . $conn->error);
    }
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Redireciona para a página de listagem de clientes se a exclusão for bem-sucedida
        header("Location: home");
        exit();
    } else {
        echo "Erro ao excluir o cliente: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Erro ao excluir o cliente: ID do cliente não informado ou inválido.";
}

$conn->close();
?>
