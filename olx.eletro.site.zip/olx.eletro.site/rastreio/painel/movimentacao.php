<?php
session_start();
require_once '../config/db.php'; // Conexão definida em ../config/db.php

// Verifica se o usuário está logado
if (!isset($_SESSION['username'])) {
    header('Location: /');
    exit();
}

$username = $_SESSION['username'];
$mensagem = "";
$mensagem_tipo = "";

// Processa o formulário de nova movimentação
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nova_movimentacao'])) {
    // Obtém e sanitiza os valores do formulário
    $rastreio_id  = intval($_POST['rastreio_id']);
    $titulo       = trim($_POST['titulo']);
    $descricao    = trim($_POST['descricao']);
    $de           = trim($_POST['de']);
    $para         = trim($_POST['para']);
    
    // Insere a nova movimentação no banco de dados (os campos criado_em e atualizado_em são gerados automaticamente)
    $sql_insert = "INSERT INTO movimentacoes (rastreio_id, titulo, descricao, `de`, `para`) VALUES (?, ?, ?, ?, ?)";
    if ($stmt = $conn->prepare($sql_insert)) {
        $stmt->bind_param("issss", $rastreio_id, $titulo, $descricao, $de, $para);
        if ($stmt->execute()) {
            $mensagem = "Movimentação criada com sucesso!";
            $mensagem_tipo = "success";
        } else {
            $mensagem = "Erro ao criar movimentação: " . $stmt->error;
            $mensagem_tipo = "danger";
        }
        $stmt->close();
    } else {
        $mensagem = "Erro na preparação da consulta: " . $conn->error;
        $mensagem_tipo = "danger";
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_movimentacao'])) {
    $movimentacao_id = intval($_POST['movimentacao_id']);
    
    // Verifica se a movimentação pertence ao usuário ou se ele é admin
    if (isset($_SESSION['isAdmin']) && $_SESSION['isAdmin'] == 1) {
        $sql_delete = "DELETE FROM movimentacoes WHERE id = ?";
    } else {
        // Usuário normal só pode deletar se for dono do rastreio associado
        $sql_delete = "DELETE FROM movimentacoes WHERE id = ? AND rastreio_id IN (
            SELECT id FROM rastreios WHERE userId = (SELECT id FROM usuarios WHERE username = ?)
        )";
    }

    if ($stmt = $conn->prepare($sql_delete)) {
        if (isset($_SESSION['isAdmin']) && $_SESSION['isAdmin'] == 1) {
            $stmt->bind_param("i", $movimentacao_id);
        } else {
            $stmt->bind_param("is", $movimentacao_id, $username);
        }

        if ($stmt->execute()) {
            $mensagem = "Movimentação deletada com sucesso!";
            $mensagem_tipo = "success";
        } else {
            $mensagem = "Erro ao deletar movimentação.";
            $mensagem_tipo = "danger";
        }
        $stmt->close();
    }
}

// Recupera os rastreios conforme o usuário logado:
// Se o usuário for admin (isAdmin = 1) mostra todos; senão, somente os rastreios cujo userId corresponda ao id do usuário
$rastreios = [];
if (isset($_SESSION['isAdmin']) && $_SESSION['isAdmin'] == 1) {
    $sql_rastreios = "SELECT * FROM rastreios";
    $result_rastreios = $conn->query($sql_rastreios);
    if ($result_rastreios && $result_rastreios->num_rows > 0) {
        while ($row = $result_rastreios->fetch_assoc()) {
            $rastreios[] = $row;
        }
    }
} else {
    // Se não for admin, busca o id do usuário a partir do username
    $user_id = 0;
    $sql_user = "SELECT id FROM usuarios WHERE username = ?";
    if ($stmt_user = $conn->prepare($sql_user)) {
        $stmt_user->bind_param("s", $username);
        $stmt_user->execute();
        $stmt_user->bind_result($user_id);
        $stmt_user->fetch();
        $stmt_user->close();
    }
    // Agora, busca os rastreios vinculados a esse usuário
    $sql_rastreios = "SELECT * FROM rastreios WHERE userId = ?";
    if ($stmt = $conn->prepare($sql_rastreios)) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result_rastreios = $stmt->get_result();
        if ($result_rastreios && $result_rastreios->num_rows > 0) {
            while ($row = $result_rastreios->fetch_assoc()) {
                $rastreios[] = $row;
            }
        }
        $stmt->close();
    }
}

// Determina qual rastreio foi selecionado (via GET); se nenhum for selecionado, utiliza o primeiro (caso exista)
$selected_rastreio_id = 0;
if (isset($_GET['rastreio_id'])) {
    $selected_rastreio_id = intval($_GET['rastreio_id']);
} elseif (!empty($rastreios)) {
    $selected_rastreio_id = $rastreios[0]['id'];
}

// Recupera as movimentações para o rastreio selecionado
$movimentacoes = [];
if ($selected_rastreio_id > 0) {
    $sql_mov = "SELECT * FROM movimentacoes WHERE rastreio_id = ? ORDER BY criado_em DESC";
    if ($stmt_mov = $conn->prepare($sql_mov)) {
        $stmt_mov->bind_param("i", $selected_rastreio_id);
        $stmt_mov->execute();
        $result_mov = $stmt_mov->get_result();
        if ($result_mov && $result_mov->num_rows > 0) {
            while ($row = $result_mov->fetch_assoc()) {
                $movimentacoes[] = $row;
            }
        }
        $stmt_mov->close();
    }
}

// Inserção automática de movimentação após a criação do rastreio
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nova_movimentacao'])) {
    $rastreio_id = intval($_POST['rastreio_id']);
    
    // A inserção de movimentação após o rastreio ter sido inserido
    $titulo = "Seu pacote foi postado";
    $descricao = "Seu pacote foi entregue ao centro de distribuição";
    $de = "Centro de Distribuição";
    $para = NULL; // A movimentação não possui destinatário especificado
    
    // Inserir movimentação
    $sql_mov_insert = "INSERT INTO movimentacoes (rastreio_id, titulo, descricao, `de`, `para`) VALUES (?, ?, ?, ?, ?)";
    if ($stmt_mov_insert = $conn->prepare($sql_mov_insert)) {
        $stmt_mov_insert->bind_param("issss", $rastreio_id, $titulo, $descricao, $de, $para);
        if ($stmt_mov_insert->execute()) {
            $mensagem = "Movimentação criada automaticamente para o rastreio!";
            $mensagem_tipo = "success";
        } else {
            $mensagem = "Erro ao criar movimentação automaticamente: " . $stmt_mov_insert->error;
            $mensagem_tipo = "danger";
        }
        $stmt_mov_insert->close();
    } else {
        $mensagem = "Erro na preparação da consulta para movimentação automática: " . $conn->error;
        $mensagem_tipo = "danger";
    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Movimentações - PTK</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
  <?php include 'navbar.php'; ?>
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <?php include 'sidebar.php'; ?>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
  <div class="container my-4">
      
    <!-- Exibe mensagem de feedback -->
    <?php if (!empty($mensagem)): ?>
      <div class="alert alert-<?php echo $mensagem_tipo; ?>">
        <?php echo $mensagem; ?>
      </div>
    <?php endif; ?>

    <!-- Formulário para selecionar um rastreio -->
    <form method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="mb-4">
      <div class="row">
        <div class="col-md-6">
          <label for="rastreio_id" class="form-label"><strong>Selecione o Rastreamento</strong></label>
          <select id="rastreio_id" name="rastreio_id" class="form-select" onchange="this.form.submit()">
            <?php foreach ($rastreios as $rast): ?>
              <option value="<?php echo $rast['id']; ?>" <?php echo ($rast['id'] == $selected_rastreio_id) ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($rast['codigo'] . " - " . $rast['cliente_nome']); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    </form>

    <!-- Tabela das últimas movimentações para o rastreio selecionado -->
    <h4>Movimentações do Rastreamento Selecionado</h4>
    <?php if (!empty($movimentacoes)): ?>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Título</th>
            <th>Descrição</th>
            <th>De</th>
            <th>Para</th>
            <th>Criado Em</th>
            <th>Atualizado Em</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($movimentacoes as $mov): ?>
            <tr>
              <td><?php echo htmlspecialchars($mov['titulo']); ?></td>
              <td><?php echo htmlspecialchars($mov['descricao']); ?></td>
              <td><?php echo htmlspecialchars($mov['de']); ?></td>
              <td><?php echo htmlspecialchars($mov['para']); ?></td>
              <td><?php echo htmlspecialchars($mov['criado_em']); ?></td>
              <td><?php echo htmlspecialchars($mov['atualizado_em']); ?></td>
               <td>
                <!-- Botão para excluir -->
                <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $mov['id']; ?>">
                  <i class="fas fa-trash-alt"></i>
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>Nenhuma movimentação encontrada para este rastreamento.</p>
    <?php endif; ?>

    <!-- Botão para abrir o modal de nova movimentação -->
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalNovaMovimentacao">
      <i class="fas fa-plus"></i> Nova Movimentação
    </button>
  </div>
  </main>
  </div>
  </div>

  <!-- Modal de Confirmação para Deletar -->
            <div class="modal fade" id="deleteModal<?php echo $mov['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo $mov['id']; ?>" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel<?php echo $mov['id']; ?>">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                  </div>
                  <div class="modal-body">
                    Tem certeza que deseja excluir esta movimentação?
                  </div>
                  <div class="modal-footer">
                    <form method="post">
                      <input type="hidden" name="movimentacao_id" value="<?php echo $mov['id']; ?>">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                      <button type="submit" name="delete_movimentacao" class="btn btn-danger">Deletar</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
  <!-- Modal para criar nova movimentação -->
  <div class="modal fade" id="modalNovaMovimentacao" tabindex="-1" aria-labelledby="modalNovaMovimentacaoLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
          <div class="modal-header">
            <h5 class="modal-title" id="modalNovaMovimentacaoLabel">Nova Movimentação</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
          </div>
          <div class="modal-body">
            <!-- Campo oculto com o rastreio selecionado -->
            <input type="hidden" name="rastreio_id" value="<?php echo $selected_rastreio_id; ?>">
            <!-- Flag para identificar a ação -->
            <input type="hidden" name="nova_movimentacao" value="1">
            <div class="mb-3">
              <label for="titulo" class="form-label">Título</label>
              <input type="text" class="form-control" id="titulo" name="titulo" required>
            </div>
            <div class="mb-3">
              <label for="descricao" class="form-label">Descrição</label>
              <textarea class="form-control" id="descricao" name="descricao" required></textarea>
            </div>
            <div class="mb-3">
              <label for="de" class="form-label">De (Origem)</label>
              <input type="text" class="form-control" id="de" name="de" required>
            </div>
            <div class="mb-3">
              <label for="para" class="form-label">Para (Destino)</label>
              <input type="text" class="form-control" id="para" name="para" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            <button type="submit" class="btn btn-primary">Salvar Movimentação</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  
  <!-- Bootstrap JS Bundle (inclui Popper) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
