<?php
header("Content-Type: application/json");

// Inclui o arquivo de conexão com o banco de dados
require_once('./config/db.php');

// Obtém os dados do corpo da requisição
$inputJSON = file_get_contents("php://input");
$data = json_decode($inputJSON, true);

// Verifica se os dados foram recebidos corretamente
if (!isset($data['requestBody'])) {
    echo json_encode(["error" => "Dados inválidos recebidos"]);
    exit();
}

$requestBody = $data['requestBody'];

// Verifica as condições para atualizar a transação
if (
    isset($requestBody['transactionType'], $requestBody['status'], $requestBody['transactionId']) &&
    $requestBody['transactionType'] === "RECEIVEPIX" &&
    $requestBody['status'] === "PAID"
) {
    $transactionId = $requestBody['transactionId'];

    // Prepara e executa a query para atualizar o status da transação
    $sql = "UPDATE transacoes SET status = 1 WHERE transactionId = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $transactionId);
    
    if ($stmt->execute()) {
        echo json_encode(["success" => "Status da transação atualizado com sucesso"]);
    } else {
        echo json_encode(["error" => "Erro ao atualizar status da transação"]);
    }
    
    // Fecha a conexão
    $stmt->close();
} else {
    echo json_encode(["error" => "Condições para atualização não atendidas"]);
}

$conn->close();
