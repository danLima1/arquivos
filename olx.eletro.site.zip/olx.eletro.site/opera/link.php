<?php
session_start();
require_once '../config/db.php'; // Conexão definida em ../config/db.php

// Verifica se o usuário está logado
if (!isset($_SESSION['username'])) {
    header('Location: /');
    exit();
}

$username = $_SESSION['username'];
$mensagem = "";
$mensagem_tipo = "";

// Processa o formulário ao enviar
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém e sanitiza os valores do formulário
    $nome = trim($_POST['nome']);
    $horapublicada = trim($_POST['horapublicada']);
    $valor = trim($_POST['valor']);
    $municipio = trim($_POST['municipio']);
    $cep = trim($_POST['cep']);
    $produto = trim($_POST['produto']);
    $categoria = trim($_POST['categoria']);
    $tipo = trim($_POST['tipo']);
    $condicao = trim($_POST['condicao']);
    $descricao = trim($_POST['descricao']);
    $datapublicada = trim($_POST['datapublicada']);

    // Processamento da imagem
    $imgprod = null;
if (!empty($_FILES['imgprod']['tmp_name']) && $_FILES['imgprod']['error'] === UPLOAD_ERR_OK) {
    if (exif_imagetype($_FILES['imgprod']['tmp_name'])) {
        $imgprod = file_get_contents($_FILES['imgprod']['tmp_name']);
    } else {
        $mensagem = "O arquivo enviado não é uma imagem válida.";
        $mensagem_tipo = "danger";
    }
}


    if (empty($mensagem)) {
        // Prepara e executa a inserção segura
        $sql = "INSERT INTO usuarios (nome, horapublicada, valor, municipio, cep, produto, categoria, tipo, condicao, descricao, datapublicada, username, imgprod) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sssssssssssss", 
                $nome, $horapublicada, $valor, $municipio, $cep, $produto, 
                $categoria, $tipo, $condicao, $descricao, $datapublicada, $username, $imgprod
            );

            if ($stmt->execute()) {
                $mensagem = "Produto cadastrado com sucesso!";
                $mensagem_tipo = "success";
            } else {
                $mensagem = "Erro ao cadastrar o produto: " . $stmt->error;
                $mensagem_tipo = "danger";
            }

            $stmt->close();
        } else {
            $mensagem = "Erro na preparação da consulta: " . $conn->error;
            $mensagem_tipo = "danger";
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PTK - ML</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body { background: #f8f9fa; }
    .sidebar { min-height: 100vh; }
  </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container-fluid">
  <div class="row">
    <?php include 'sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <div class="card shadow-sm">
        <div class="card-header text-center bg-white">
          <img src="ptk2.png" alt="Logo" style="width: 200px; height: 140px;">
        </div>
        <div class="card-body">
          <!-- Exibe mensagens de erro ou sucesso -->
          <?php if (!empty($mensagem)): ?>
            <div class="alert alert-<?php echo $mensagem_tipo; ?> text-center">
              <?php echo $mensagem; ?>
            </div>
          <?php endif; ?>

          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="username" class="form-label">Criado por:</label>
                <input type="text" class="form-control" id="username" name="username" 
                       value="<?php echo htmlspecialchars($username); ?>" readonly>
              </div>
              <div class="col-md-6">
                <label for="nome" class="form-label">Nome do Vendedor:</label>
                <input type="text" class="form-control" id="nome" name="nome" required>
              </div>
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="horapublicada" class="form-label">Hora Publicada:</label>
                <input type="time" class="form-control" id="horapublicada" name="horapublicada" required>
              </div>
              <div class="col-md-6">
                <label for="valor" class="form-label">Valor do Produto:</label>
                <input type="number" class="form-control" id="valor" name="valor" step="0.01" required>
              </div>
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="municipio" class="form-label">Município:</label>
                <input type="text" class="form-control" id="municipio" name="municipio" required>
              </div>
              <div class="col-md-6">
                <label for="cep" class="form-label">CEP:</label>
                <input type="text" class="form-control" id="cep" name="cep" required>
              </div>
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="produto" class="form-label">Nome do Produto:</label>
                <input type="text" class="form-control" id="produto" name="produto" required>
              </div>
              <div class="col-md-6">
                <label for="categoria" class="form-label">Categoria:</label>
                <input type="text" class="form-control" id="categoria" name="categoria" required>
              </div>
            </div>

            <div class="mb-3">
              <label for="descricao" class="form-label">Descrição:</label>
              <textarea class="form-control" id="descricao" name="descricao" required></textarea>
            </div>
            
            <label for="tipo" class="form-label">Tipo:</label>
<input type="text" class="form-control" id="tipo" name="tipo" required>

<label for="condicao" class="form-label">Condição:</label>
<input type="text" class="form-control" id="condicao" name="condicao" required>

<label for="datapublicada" class="form-label">Data Publicada:</label>
<input type="date" class="form-control" id="datapublicada" name="datapublicada" required>


            <div class="mb-3">
              <label for="imgprod" class="form-label">Imagem do Produto:</label>
              <input type="file" class="form-control" id="imgprod" name="imgprod" accept="image/*" required>
            </div>

            <button type="submit" class="btn btn-primary">Cadastrar</button>
          </form>
        </div>
      </div>
    </main>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
