<?php
session_start();
require_once '../config/db.php'; // Conexão definida em ../config/db.php

// Somente administradores podem acessar esta página
if (!isset($_SESSION['username']) || !isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] != 1) {
    header('Location: index.php');
    exit();
}

$username = $_SESSION['username'];

// Processamento de ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Excluir usuário
    if (isset($_POST['excluir'])) {
        $id = intval($_POST['id']);
        $sql_delete = "DELETE FROM usuarios WHERE id = ?";
        $stmt = $conn->prepare($sql_delete);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
    // Adicionar créditos
    if (isset($_POST['adicionar_creditos'])) {
        $id = intval($_POST['id']);
        $quantidade = intval($_POST['quantidade']);
        $sql_update = "UPDATE usuarios SET credito = credito + ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update);
        $stmt->bind_param("ii", $quantidade, $id);
        $stmt->execute();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
    // Retirar créditos
    if (isset($_POST['retirar_creditos'])) {
        $id = intval($_POST['id']);
        $quantidade = intval($_POST['quantidade']);
        $sql_update = "UPDATE usuarios SET credito = credito - ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update);
        $stmt->bind_param("ii", $quantidade, $id);
        $stmt->execute();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
    // Criar novo usuário (senha em bcrypt)
    if (isset($_POST['criar_usuario'])) {
        $nome = trim($_POST['nome']);
        $email = trim($_POST['email']);
        $username_new = trim($_POST['username']);
        $password_plain = trim($_POST['password']);
        $password_hash = password_hash($password_plain, PASSWORD_BCRYPT);
        
        $sql_insert = "INSERT INTO usuarios (nome, email, username, password, isAdmin, credito) VALUES (?, ?, ?, ?, 0, 0)";
        $stmt = $conn->prepare($sql_insert);
        $stmt->bind_param("ssss", $nome, $email, $username_new, $password_hash);
        $stmt->execute();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Consulta para buscar apenas usuários normais (isAdmin = 0)
$sql = "SELECT * FROM usuarios WHERE isAdmin = 0";
$result = $conn->query($sql);

// Armazena os usuários em um array para uso posterior (modais fora da tabela)
$usuarios = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $usuarios[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PTK - Lista de Usuários</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
  <?php include 'navbar.php'; ?>
  
  <div class="container mt-4">
    <h2>Lista de Usuários</h2>
    
    <!-- Botão para criar novo usuário -->
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalCriarUsuario">
      <i class="fas fa-user-plus"></i> Criar Novo Usuário
    </button>
    

    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Usuário</th>
            <th>Créditos</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($usuarios)): ?>
            <?php foreach ($usuarios as $row): ?>
            <tr>
              <td><?php echo $row['id']; ?></td>
              <td><?php echo htmlspecialchars($row['nome']); ?></td>
              <td><?php echo htmlspecialchars($row['username']); ?></td>
              <td><?php echo htmlspecialchars($row['credito']); ?></td>
              <td>
                <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalAdicionar<?php echo $row['id']; ?>">
                  <i class="fas fa-plus"></i> Adicionar Créditos
                </button>
                <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalRetirar<?php echo $row['id']; ?>">
                  <i class="fas fa-minus"></i> Retirar Créditos
                </button>
                <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalHistorico<?php echo $row['id']; ?>">
                  <i class="fas fa-history"></i> Histórico
                </button>
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" style="display:inline-block;">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="excluir" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este usuário?');">
                    <i class="fas fa-trash"></i> Deletar
                  </button>
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="5" class="text-center">Nenhum usuário encontrado.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  
  <!-- Modal de Teste -->
  <div class="modal fade" id="testeModal" tabindex="-1" aria-labelledby="testeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
           <h5 class="modal-title" id="testeModalLabel">Modal de Teste</h5>
           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
         </div>
         <div class="modal-body">
            Este é um modal de teste.
         </div>
      </div>
    </div>
  </div>
  
  <!-- Modais dos usuários -->
  <?php foreach ($usuarios as $row): ?>
    <!-- Modal Adicionar Créditos -->
    <div class="modal fade" id="modalAdicionar<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="modalAdicionarLabel<?php echo $row['id']; ?>" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalAdicionarLabel<?php echo $row['id']; ?>">Adicionar Créditos para <?php echo htmlspecialchars($row['nome']); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
          </div>
          <div class="modal-body">
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="adicionar_creditos" value="1">
              <div class="mb-3">
                <label class="form-label">Quantidade de Créditos</label>
                <input type="number" class="form-control" name="quantidade" required>
              </div>
              <button type="submit" class="btn btn-primary">Adicionar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Modal Retirar Créditos -->
    <div class="modal fade" id="modalRetirar<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="modalRetirarLabel<?php echo $row['id']; ?>" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalRetirarLabel<?php echo $row['id']; ?>">Retirar Créditos para <?php echo htmlspecialchars($row['nome']); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
          </div>
          <div class="modal-body">
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="retirar_creditos" value="1">
              <div class="mb-3">
                <label class="form-label">Quantidade de Créditos</label>
                <input type="number" class="form-control" name="quantidade" required>
              </div>
              <button type="submit" class="btn btn-primary">Retirar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Modal Histórico -->
    <div class="modal fade" id="modalHistorico<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="modalHistoricoLabel<?php echo $row['id']; ?>" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalHistoricoLabel<?php echo $row['id']; ?>">Histórico de <?php echo htmlspecialchars($row['nome']); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
          </div>
          <div class="modal-body">
            <?php
              $userId = $row['id'];
              $sql_history = "SELECT SUM(creditos) AS total_creditos, SUM(valor) AS total_valor FROM transacoes WHERE usuario_id = ?";
              $stmt_history = $conn->prepare($sql_history);
              $stmt_history->bind_param("i", $userId);
              $stmt_history->execute();
              $result_history = $stmt_history->get_result();
              $history = $result_history->fetch_assoc();
              $total_creditos = $history['total_creditos'] ?: 0;
              $total_valor = $history['total_valor'] ?: 0;
            ?>
            <p><strong>Total de Créditos Comprados:</strong> <?php echo $total_creditos; ?></p>
            <p><strong>Valor Gasto (R$):</strong> <?php echo number_format($total_valor, 2, ',', '.'); ?></p>
          </div>
        </div>
      </div>
    </div>
    
  <?php endforeach; ?>
  
  <!-- Modal Criar Novo Usuário -->
  <div class="modal fade" id="modalCriarUsuario" tabindex="-1" aria-labelledby="modalCriarUsuarioLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalCriarUsuarioLabel">Criar Novo Usuário</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
        </div>
        <div class="modal-body">
          <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
            <input type="hidden" name="criar_usuario" value="1">
            <div class="mb-3">
              <label class="form-label">Nome</label>
              <input type="text" class="form-control" name="nome" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Usuário</label>
              <input type="text" class="form-control" name="username" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Senha</label>
              <input type="password" class="form-control" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Criar Usuário</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Bootstrap JS Bundle (inclui Popper) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
