<!-- sidebar.php -->
<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-white sidebar collapse">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="home">
          <i class="fas fa-home"></i> Home
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="link">
          <i class="fas fa-plus"></i> Criar Link
        </a>
      </li>
    </ul>
  </div>
</nav>
