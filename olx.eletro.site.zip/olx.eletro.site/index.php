<?php
session_start(); // Inicia a sessão para armazenar o ID do usuário

// Inclui o arquivo de configuração do banco de dados
require_once('./config/db.php');

// Inclui a função para obter o usuário pelo ID
require_once('./functions/getUserById.php');

// Obtém o ID da URL de forma segura
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

if ($id) {
    // Chama a função para obter o usuário
    $cliente = getUserById($conn, $id);

    // Se encontrou o usuário, armazena os dados na sessão
    if ($cliente) {
        $_SESSION['user_id'] = $cliente['id']; // Salva o ID do usuário na sessão
    } else {
        header("Location: https://www.olx.com.br");
        exit();
    }
} else {
    // Se o ID não foi passado, redireciona para olx.com.br
    header("Location: https://www.olx.com.br");
    exit();
}

// Fecha a conexão com o banco de dados
mysqli_close($conn);
?>


<html lang="pt-BR" data-reactroot="" class="mobile_mode"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="x-testab-debugger" content="adv-cookieless-liveramp_enabled.adv-native_grid-list.autospp-marketplace-header_enabled.ck-filters_enabled.cmod-pro-ad-showphone-body_enabled.contentmod-gallery-tip_final.ds-header-navbar_enabled.mes-or-dot_enabled.nc-sub_control.ngage-new-home-autos_enabled.onb-perfil_enabled.payg-redirect-nc-ios_control.payg-redirect-nc_enabled.rec-ab91bd_don-0.redesign-listing_enabled.sqld-btl_control.sub-nc-and_enabled.sub-nc-ios_enabled.sxp-smartp_control">
    <meta name="theme-color" content="white">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta property="og:title" content="<?php echo $cliente['produto']; ?>">
    <meta property="og:site_name" content="OLX">
    <meta property="og:description" content="">
    <meta property="og:image" content="https://olx.compregarantindo.com/produtos/images-1739329312446.jpg">
    <meta name="description" content="">
    <title><?php echo $cliente['produto']; ?> | OLX</title>
    <style>body{font-size:100%;}</style>
    <style>
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      ul[class]{padding:0;}
      body,h1,h2,h3,p{margin:0;}
      body{min-height:100vh;text-rendering:optimizeSpeed;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;line-height:1.5;}
      img,picture{max-width:100%;display:block;}
      input,button{font:inherit;}
      button,[type='button']{-webkit-appearance:button;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      @media screen{
      :root{--border-radius-none:0;--border-radius-xxs:2px;--border-radius-xs:4px;--border-radius-sm:8px;--border-radius-md:16px;--border-radius-lg:24px;--border-radius-pill:500px;--border-radius-circle:50%;--border-width-none:0;--border-width-hairline:1px;--border-width-thin:2px;--border-width-thick:4px;--border-width-heavy:8px;--media-query-sm:360px;--media-query-md:840px;--media-query-lg:1200px;--media-query-xl:1500px;--media-query-xxl:1720px;--color-primary-70:#fff3e6;--color-primary-80:#ffe1bf;--color-primary-90:#ffbb73;--color-primary-100:#f28000;--color-primary-110:#df7400;--color-primary-120:#cb6700;--color-primary-130:#b35a00;--color-primary-darkest:#b35a00;--color-primary-darker:#cb6700;--color-primary-dark:#df7400;--color-primary-medium:#f28000;--color-primary-light:#ffbb73;--color-primary-lighter:#ffe1bf;--color-primary-lightest:#fff3e6;--color-secondary-70:#f0e6ff;--color-secondary-80:#c599ff;--color-secondary-90:#994dfa;--color-secondary-100:#6e0ad6;--color-secondary-110:#5c08b2;--color-secondary-120:#49078f;--color-secondary-130:#37056b;--color-secondary-darkest:#37056b;--color-secondary-darker:#49078f;--color-secondary-dark:#5c08b2;--color-secondary-medium:#6e0ad6;--color-secondary-light:#994dfa;--color-secondary-lighter:#c599ff;--color-secondary-lightest:#f0e6ff;--color-neutral-70:#ffffff;--color-neutral-80:#f5f6f7;--color-neutral-90:#cfd4dd;--color-neutral-100:#8994a9;--color-neutral-110:#5e6a82;--color-neutral-120:#3c4453;--color-neutral-130:#1a1d23;--color-neutral-darkest:#1a1d23;--color-neutral-darker:#3c4453;--color-neutral-dark:#5e6a82;--color-neutral-medium:#8994a9;--color-neutral-light:#cfd4dd;--color-neutral-lighter:#f5f6f7;--color-neutral-lightest:#ffffff;--color-feedback-success-80:#def9cc;--color-feedback-success-90:#8ce563;--color-feedback-success-100:#24a148;--color-feedback-success-110:#197b35;--color-feedback-success-120:#105323;--color-feedback-success-darkest:#105323;--color-feedback-success-dark:#197b35;--color-feedback-success-medium:#24a148;--color-feedback-success-light:#8ce563;--color-feedback-success-lightest:#def9cc;--color-feedback-error-80:#fff5f5;--color-feedback-error-90:#f48787;--color-feedback-error-100:#e22828;--color-feedback-error-110:#901111;--color-feedback-error-120:#3b0505;--color-feedback-error-darkest:#3b0505;--color-feedback-error-dark:#901111;--color-feedback-error-medium:#e22828;--color-feedback-error-light:#f48787;--color-feedback-error-lightest:#fff5f5;--color-feedback-attention-80:#fff7e0;--color-feedback-attention-90:#ffe19a;--color-feedback-attention-100:#f9af27;--color-feedback-attention-110:#7b5613;--color-feedback-attention-120:#3c2a09;--color-feedback-attention-darkest:#3c2a09;--color-feedback-attention-dark:#7b5613;--color-feedback-attention-medium:#f9af27;--color-feedback-attention-light:#ffe19a;--color-feedback-attention-lightest:#fff7e0;--color-feedback-info-80:#e1f9ff;--color-feedback-info-90:#9ce6f9;--color-feedback-info-100:#28b5d9;--color-feedback-info-110:#14596b;--color-feedback-info-120:#0a2b34;--color-feedback-info-darkest:#0a2b34;--color-feedback-info-dark:#14596b;--color-feedback-info-medium:#28b5d9;--color-feedback-info-light:#9ce6f9;--color-feedback-info-lightest:#e1f9ff;--font-family:'Nunito Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;--font-size-nano:10px;--font-size-xxxs:12px;--font-size-xxs:14px;--font-size-xs:16px;--font-size-sm:18px;--font-size-md:20px;--font-size-lg:24px;--font-size-xl:30px;--font-size-xxl:36px;--font-size-xxxl:48px;--font-size-huge:64px;--font-weight-bold:700;--font-weight-semibold:600;--font-weight-regular:400;--font-weight-light:300;--font-lineheight-supertight:1;--font-lineheight-tight:1.15;--font-lineheight-medium:1.32;--font-lineheight-distant:1.40;--font-lineheight-superdistant:1.50;--z-index-1-default:1;--z-index-100-masked:100;--z-index-200-mask:200;--z-index-250-mask-button:250;--z-index-300-sticky:300;--z-index-400-header:400;--z-index-500-toast:500;--z-index-600-dropdown:600;--z-index-700-overlay:700;--z-index-800-spinner:800;--z-index-900-modal:900;--z-index-950-popup:950;--z-index-1000-top:1000;--z-index-deep:-9999;--opacity-full:1;--opacity-semiopaque:0.8;--opacity-intense:0.64;--opacity-medium:0.32;--opacity-light:0.16;--opacity-semitransparent:0.08;--opacity-none:0;--shadow-level-1:0px 1px 1px rgba(0, 0, 0, 0.14);--shadow-level-2:0px 2px 2px rgba(0, 0, 0, 0.14);--shadow-level-3:0px 3px 4px rgba(0, 0, 0, 0.14);--shadow-level-4:0px 4px 5px rgba(0, 0, 0, 0.14);--shadow-level-6:0px 6px 10px rgba(0, 0, 0, 0.14);--shadow-level-8:0px 8px 10px rgba(0, 0, 0, 0.14);--shadow-level-9:0px 9px 12px rgba(0, 0, 0, 0.14);--shadow-level-12:0px 12px 17px rgba(0, 0, 0, 0.14);--shadow-level-16:0px 16px 24px rgba(0, 0, 0, 0.14);--shadow-level-24:0px 24px 38px rgba(0, 0, 0, 0.14);--spacing-1:8px;--spacing-2:16px;--spacing-3:24px;--spacing-4:32px;--spacing-5:40px;--spacing-6:48px;--spacing-7:56px;--spacing-8:64px;--spacing-9:72px;--spacing-0-25:2px;--spacing-0-5:4px;--spacing-1-5:12px;--spacing-10:80px;--spacing-stack-quarck:4px;--spacing-stack-nano:8px;--spacing-stack-xxxs:16px;--spacing-stack-xxs:24px;--spacing-stack-xs:32px;--spacing-stack-sm:40px;--spacing-stack-md:48px;--spacing-stack-lg:56px;--spacing-stack-xl:64px;--spacing-stack-xxl:80px;--spacing-stack-xxxl:120px;--spacing-stack-huge:160px;--spacing-stack-giant:200px;--spacing-inline-quarck:4px;--spacing-inline-nano:8px;--spacing-inline-xxxs:16px;--spacing-inline-xxs:24px;--spacing-inline-xs:32px;--spacing-inline-sm:40px;--spacing-inline-md:48px;--spacing-inline-lg:64px;--spacing-inline-xl:80px;--spacing-inset-xxs:2px;--spacing-inset-xs:4px;--spacing-inset-sm:8px;--spacing-inset-md:16px;--spacing-inset-lg:24px;--spacing-inset-xl:32px;--spacing-inset-xxl:40px;--spacing-squish-xxs:2px 4px;--spacing-squish-xs:4px 8px;--spacing-squish-sm:8px 16px;--spacing-squish-md:8px 24px;--spacing-squish-lg:12px 16px;--spacing-squish-xl:16px 24px;--spacing-squish-xxl:16px 32px;--spacing-squish-xxxl:24px 32px;--transition-delay-1:100ms;--transition-delay-2:200ms;--transition-delay-3:300ms;--transition-delay-4:400ms;--transition-delay-5:500ms;--transition-delay-slowest:500ms;--transition-delay-slow:400ms;--transition-delay-normal:300ms;--transition-delay-fast:200ms;--transition-delay-fastest:100ms;--transition-timing-ease:cubic-bezier(0.250, 0.100, 0.250, 1.000);--transition-timing-ease-in:cubic-bezier(0.420, 0.000, 1.000, 1.000);--transition-timing-ease-out:cubic-bezier(0.000, 0.000, 0.580, 1.000);--transition-timing-ease-in-out:cubic-bezier(0.420, 0.000, 0.580, 1.000);--transition-duration-1:100ms;--transition-duration-2:200ms;--transition-duration-3:300ms;--transition-duration-4:400ms;--transition-duration-5:500ms;--transition-duration-slowest:500ms;--transition-duration-slow:400ms;--transition-duration-normal:300ms;--transition-duration-fast:200ms;--transition-duration-fastest:100ms;--transition-repetition-2:2;--transition-repetition-3:3;--transition-repetition-infinite:infinite;--button-primary-background-color-base:#f28000;--button-primary-background-color-hover:#df7400;--button-primary-background-color-loading:#f28000;--button-primary-border-color-base:#f28000;--button-primary-border-color-hover:#df7400;--button-primary-color-font-base:#ffffff;--button-primary-color-outline:#ffe1bf;--button-secondary-background-color-base:transparent;--button-secondary-background-color-hover:#fff3e6;--button-secondary-background-color-loading:transparent;--button-secondary-border-color-base:#f28000;--button-secondary-border-color-hover:#fff3e6;--button-secondary-color-font-base:#f28000;--button-secondary-color-outline:#ffe1bf;--button-secondary-inverted-background-color-base:#ffffff00;--button-secondary-inverted-background-color-hover:#ffffff2B;--button-secondary-inverted-background-color-loading:transparent;--button-secondary-inverted-border-color-base:#ffffff;--button-secondary-inverted-border-color-hover:#ffffff2B;--button-secondary-inverted-color-font-base:#ffffff;--button-secondary-inverted-color-outline:#ffffff52;--button-tertiary-background-color-base:#fff3e6;--button-tertiary-background-color-hover:#ffe1bf;--button-tertiary-background-color-loading:#df7400;--button-tertiary-border-color-base:#fff3e6;--button-tertiary-border-color-hover:#ffe1bf;--button-tertiary-color-font-base:#cb6700;--button-tertiary-color-outline:#ffe1bf;--button-link-button-background-color-base:transparent;--button-link-button-background-color-hover:#f0e6ff;--button-link-button-background-color-loading:#f0e6ff;--button-link-button-border-color-base:transparent;--button-link-button-border-color-hover:#f0e6ff;--button-link-button-color-font-base:#6e0ad6;--button-link-button-color-outline:#f0e6ff;--button-danger-background-color-base:#e22828;--button-danger-background-color-hover:#901111;--button-danger-background-color-loading:#e22828;--button-danger-border-color-base:#e22828;--button-danger-border-color-hover:#901111;--button-danger-color-font-base:#ffffff;--button-danger-color-outline:#f48787;--button-neutral-background-color-base:transparent;--button-neutral-background-color-hover:#cfd4dd;--button-neutral-background-color-loading:transparent;--button-neutral-border-color-base:#5e6a82;--button-neutral-border-color-hover:#5e6a82;--button-neutral-color-font-base:#1a1d23;--button-neutral-color-outline:#f5f6f7;--button-disabled-background-color:#f5f6f7;--button-disabled-border-color:transparent;--button-disabled-color-font:#5e6a82;--carousel-focus:#1a1d23;--carousel-arrow-background-color-base:#ffffff;--carousel-arrow-background-color-hover:#cfd4dd;--carousel-arrow-color:#1a1d23;--checkbox-background-color-base:#ffffff;--checkbox-background-color-checked:#6e0ad6;--checkbox-background-color-checked-hover:#49078f;--checkbox-background-color-error:#fff5f5;--checkbox-background-color-hover:#f5f6f7;--checkbox-border-color-base:#cfd4dd;--checkbox-border-color-hover:#cfd4dd;--checkbox-border-color-error:#e22828;--checkbox-color-outline:#c599ff;--checkbox-color-icon:#ffffff;--container-background-color:#ffffff;--container-border-color-outlined:#cfd4dd;--divider-default-background-color:#cfd4dd;--divider-inverted-background-color:#5e6a82;--dropdown-background-color-base:#ffffff;--dropdown-background-color-error:#fff5f5;--dropdown-background-color-disabled:#f5f6f7;--dropdown-border-color-base:#cfd4dd;--dropdown-border-color-disabled:#f5f6f7;--dropdown-border-color-error:#e22828;--dropdown-border-color-focus:#6e0ad6;--dropdown-border-color-hover:#cfd4dd;--dropdown-border-color-selected:#1a1d23;--dropdown-color-font-base:#8994a9;--dropdown-color-font-disabled:#8994a9;--dropdown-color-font-selected:#1a1d23;--dropdown-icon-color-base:#1a1d23;--dropdown-icon-color-disabled:#8994a9;--link-color-main-base:#6e0ad6;--link-color-main-hover:#5c08b2;--link-color-main-active:#49078f;--link-color-grey-base:#1a1d23;--link-color-grey-hover:#6e0ad6;--link-color-grey-active:#5c08b2;--link-color-inverted-base:#ffffff;--link-color-inverted-hover:#c599ff;--link-color-inverted-active:#f0e6ff;--modal-background-color:#ffffff;--modal-button-background-color-hover:#cfd4dd;--modal-button-background-color-focus:#1a1d23;--modal-button-color:#1a1d23;--radio-background-color-base:#ffffff;--radio-background-color-checked:#6e0ad6;--radio-background-color-checked-hover:#49078f;--radio-background-color-error:#e22828;--radio-background-color-hover:#f5f6f7;--radio-border-color-base:#5e6a82;--radio-border-color-checked:#6e0ad6;--radio-border-color-checked-hover:#49078f;--radio-border-color-hover:#cfd4dd;--radio-border-color-error:#e22828;--radio-color-outline:#c599ff;--radio-font-color:#1a1d23;--skeleton-background-0:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 0%, #f5f6f7 100%);--skeleton-background-20:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 20%, #f5f6f7 100%);--skeleton-background-40:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 40%, #f5f6f7 100%);--skeleton-background-60:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 60%, #f5f6f7 100%);--skeleton-background-80:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 80%, #f5f6f7 100%);--skeleton-background-100:linear-gradient(90deg, #f5f6f7 0%, #cfd4dd 100%, #f5f6f7 100%);--spinner-color:#6e0ad6;--spinner-inverted-color:#ffffff;--spinner-extra-small-size:16px;--spinner-small-size:24px;--spinner-medium-size:32px;--spinner-large-size:48px;--spinner-extra-large-size:56px;--spinner-huge-size:64px;--spots-background-circle:#f0e6ff;--spots-background-triangle:#def9cc;--spots-background-square:#fff3e6;--spots-background-neutral:#f5f6f7;--spots-color-circle:#6e0ad6;--spots-color-triangle:#8ce563;--spots-color-square:#f28000;--spots-color-neutral:#cfd4dd;--spots-border-color-default:#1a1d23;--spots-border-color-neutral:#8994a9;--textinput-background-color-base:#ffffff;--textinput-background-color-error:#fff5f5;--textinput-background-color-disabled:#f5f6f7;--textinput-background-color-success:#ffffff;--textinput-border-color-empty:#cfd4dd;--textinput-border-color-error:#e22828;--textinput-border-color-disabled:transparent;--textinput-border-color-filled:#1a1d23;--textinput-border-color-focus:#6e0ad6;--textinput-border-color-hover:#cfd4dd;--textinput-border-color-success:#24a148;--textinput-border-color-empty-hover:#cfd4dd;--textinput-color-font:#1a1d23;--textinput-color-placeholder:#8994a9;--textinput-color-disabled:#8994a9;--textinput-icon-color:#3c4453;--textinput-caption-font-color:#3c4453;--textinput-feedback-error-font-color:#e22828;--text-color:#1a1d23;--toast-background-color:#3c4453;--toast-font-color:#ffffff;--toast-close-icon-color:#ffffff;--toggleswitch-background-color-base:#cfd4dd;--toggleswitch-background-color-checked:#6e0ad6;--toggleswitch-background-color-checked-hover:#49078f;--toggleswitch-background-color-hover:#8994a9;--toggleswitch-color-outline:#c599ff;--toggleswitch-icon-color:#ffffff;}
      }
      .olx-button{align-items:center;background-color:var(--button-background-color);border-color:var(--button-border);border-radius:var(--border-radius-pill);border-style:solid;border-width:var(--border-width-hairline);color:var(--button-color-font);cursor:pointer;display:inline-flex;font-family:var(--font-family);font-size:var(--button-font-size);font-weight:var(--font-weight-semibold);height:var(--button-height);justify-content:center;line-height:var(--button-line-height);min-width:72px;outline:none;padding:var(--button-padding);position:relative;text-decoration:initial;width:-moz-fit-content;width:fit-content;}
      .olx-button--a{text-decoration:none;}
      .olx-button:active{transform:scale(.96);}
      .olx-button:active,.olx-button:not(:active){transition:all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:not(:hover){transition:all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:focus{outline:var(--color-neutral-130) solid var(--border-width-thin);outline-offset:var(--border-width-thin);transition:outline 0ms,outline-offset 0ms;}
      .olx-button:not(.olx-button--disabled):hover{background-color:var(--button-background-color-hover);border-color:var(--button-border-color-hover);transition:all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:focus:not(:focus-visible){outline:none;outline-offset:0;}
      .olx-button--small{--button-height:32px;--button-padding:var(--spacing-1) var(--spacing-2);--button-font-size:var(--font-size-xxs);--button-line-height:var(--font-lineheight-tight);}
      .olx-button--medium{--button-height:40px;--button-padding:var(--spacing-1) var(--spacing-3);--button-font-size:var(--font-size-xs);--button-line-height:var(--font-lineheight-superdistant);}
      .olx-button--large{--button-height:48px;--button-padding:var(--spacing-2) var(--spacing-3);--button-font-size:var(--font-size-xs);--button-line-height:var(--font-lineheight-supertight);}
      .olx-button--primary{--button-background-color:var(--button-primary-background-color-base);--button-border:var(--button-primary-border-color-base);--button-color-font:var(--button-primary-color-font-base);--button-background-color-hover:var(--button-primary-background-color-hover);--button-border-color-hover:var(--button-primary-border-color-hover);}
      .olx-button--secondary{--button-background-color:var(--button-secondary-background-color-base);--button-border:var(--button-secondary-border-color-base);--button-color-font:var(--button-secondary-color-font-base);--button-background-color-hover:var(--button-secondary-background-color-hover);--button-border-color-hover:var(--button-secondary-border-color-hover);}
      .olx-button--link-button{--button-background-color:var(--button-link-button-background-color-base);--button-border:var(--button-link-button-border-color-base);--button-color-font:var(--button-link-button-color-font-base);--button-background-color-hover:var(--button-link-button-background-color-hover);--button-border-color-hover:var(--button-link-button-border-color-hover);}
      .olx-button__content-wrapper{align-items:center;display:inline-flex;justify-content:center;visibility:visible;}
      .olx-button__icon-wrapper{fill:currentcolor;align-items:center;display:inline-flex;height:24px;justify-content:center;margin-right:var(--spacing-1);pointer-events:none;width:24px;}
      .olx-button__icon-wrapper svg{height:24px;width:24px;}
      .olx-link{align-items:center;color:var(--link-color);cursor:pointer;display:inline-flex;font-family:var(--font-family);font-size:var(--font-size);font-weight:var(--font-weight-semibold);justify-content:center;line-height:var(--font-lineheight);outline:none;text-decoration:none;transition:all var(--transition-duration-3) var(--transition-timing-ease);}
      .olx-link:active{color:var(--link-color-active);}
      .olx-link:focus{border-radius:var(--border-radius-xxs);outline:var(--border-width-thin) solid var(--color-neutral-130);}
      .olx-link:hover{color:var(--link-color-hover);text-decoration:underline;}
      .olx-link:focus:not(:focus-visible){box-shadow:none;outline:0;}
      .olx-link--caption{--font-size:var(--font-size-xxxs);--font-lineheight:var(--font-lineheight-medium);}
      .olx-link--small{--font-size:var(--font-size-xxs);--font-lineheight:var(--font-lineheight-distant);}
      .olx-link--medium{--font-size:var(--font-size-xs);--font-lineheight:var(--font-lineheight-superdistant);}
      .olx-link--main{--link-color:var(--link-color-main-base);--link-color-hover:var(--link-color-main-hover);--link-color-active:var(--link-color-main-active);}
      .olx-link--grey{--link-color:var(--link-color-grey-base);--link-color-hover:var(--link-color-grey-hover);--link-color-active:var(--link-color-grey-active);}
      .olx-text{color:var(--text-color);display:block;font-family:var(--font-family);font-style:normal;font-weight:var(--font-weight-regular);margin:0;padding:0;word-break:break-word;}
      .olx-text--title-large{font-size:var(--font-size-lg);font-weight:var(--font-weight-semibold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width:840px){
      .olx-text--title-large{font-size:var(--font-size-xxl);}
      }
      .olx-text--title-medium{font-size:var(--font-size-md);font-weight:var(--font-weight-semibold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width:840px){
      .olx-text--title-medium{font-size:var(--font-size-lg);}
      }
      .olx-text--title-small{font-size:var(--font-size-sm);font-weight:var(--font-weight-bold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width:840px){
      .olx-text--title-small{font-size:var(--font-size-md);}
      }
      .olx-text--body-large{font-size:var(--font-size-sm);}
      .olx-text--body-large,.olx-text--body-medium{line-height:var(--font-lineheight-superdistant);}
      .olx-text--body-medium{font-size:var(--font-size-xs);}
      .olx-text--body-small{font-size:var(--font-size-xxs);line-height:var(--font-lineheight-distant);}
      .olx-text--caption{font-size:var(--font-size-xxxs);line-height:var(--font-lineheight-medium);}
      .olx-text--light,.olx-text--regular{font-weight:var(--font-weight-regular);}
      .olx-text--semibold{font-weight:var(--font-weight-semibold);}
      .olx-text--bold{font-weight:var(--font-weight-bold);}
      .olx-text--inline{display:inline;}
      .olx-text--block{display:block;}
      .olx-text-input__input-container{align-items:center;background-color:var(--textinput-background-color-base);border:none;border-radius:var(--border-radius-xs);box-shadow:0 0 0 var(--border-width-hairline) var(--textinput-border-color-empty);color:var(--textinput-color-font);display:inline-flex;position:relative;width:100%;z-index:var(--z-index-1-default,1);}
      .olx-text-input__input-container:hover{box-shadow:0 0 0 var(--border-width-thin) var(--textinput-border-color-empty-hover);}
      .olx-text-input__input-container--medium{border-radius:var(--border-radius-sm);}
      .olx-text-input__input-field{background-color:inherit;border:none;border-radius:var(--border-radius-xs);color:var(--color-neutral-130);font-family:var(--font-family);font-size:var(--font-size-xxs);font-weight:var(--font-weight-regular);outline:none;padding:var(--spacing-0-5) var(--spacing-1);position:relative;width:100%;}
      .olx-text-input__input-field--medium{border-radius:var(--border-radius-sm);font-size:var(--font-size-xs);line-height:var(--font-lineheight-distant);padding:var(--spacing-1-5) var(--spacing-2);}
      .olx-text-input__input-field::placeholder{color:var(--textinput-color-placeholder);}
      .olx-container{background-color:var(--container-background-color);border-radius:var(--border-radius-sm);overflow:hidden;padding:var(--spacing-2);}
      .olx-container--outlined{border:var(--border-width-hairline) solid var(--container-border-color-outlined);}
      .olx-divider{background-color:var(--divider-default-background-color);border:none;height:1px;margin:0;}
      .olx-visually-hidden{clip:rect(1px,1px,1px,1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-visually-hidden:focus{clip:auto;height:auto;overflow:auto;position:absolute;width:auto;}
      .olx-image-carousel{height:100%;padding:0;position:relative;width:100%;}
      .olx-image-carousel>span{height:24px;left:8px;max-width:calc(100% - 16px);position:absolute;top:8px;z-index:var(--z-index-100-masked);}
      .olx-image-carousel span{display:block;text-overflow:ellipsis;}
      @media screen and (min-width:566px){
      .olx-image-carousel>span{left:16px;top:16px;}
      }
      .olx-image-carousel__items{align-items:center;display:flex;height:100%;justify-content:flex-start;margin:0;overflow-x:scroll;overflow-y:hidden;padding:0;scroll-snap-type:x mandatory;scrollbar-width:none;}
      .olx-image-carousel__items::-webkit-scrollbar{display:none;}
      .olx-image-carousel__item{align-items:center;display:flex;height:100%;justify-content:center;list-style:none;margin:0;min-width:100%;overflow:hidden;padding:0;position:relative;scroll-snap-align:start;scroll-snap-stop:always;}
      .olx-image-carousel__item *{height:100%;width:100%;}
      .olx-image-carousel__item img,.olx-image-carousel__item picture{display:block;-o-object-fit:cover;object-fit:cover;}
      .olx-image-carousel__counter-wrapper{bottom:6px;position:absolute;right:8px;}
      .olx-ad-card{background:var(--color-neutral-70);border:1px solid var(--color-neutral-90);border-radius:var(--border-radius-sm);cursor:pointer;position:relative;transition:box-shadow var(--transition-duration-2) var(--transition-timing-ease);}
      .olx-ad-card picture img{transition:scale var(--transition-duration-5) var(--transition-timing-ease);}
      .olx-ad-card:hover{box-shadow:var(--shadow-level-6);}
      .olx-ad-card:hover picture img{scale:1.1;}
      .olx-ad-card--vertical{display:flex;flex-direction:column;max-width:400px;min-height:100%;min-width:180px;width:100%;}
      .olx-ad-card--vertical .olx-image-carousel{border-bottom:0;border-top-left-radius:var(--border-radius-sm);border-top-right-radius:var(--border-radius-sm);height:180px;overflow:hidden;width:100%;}
      .olx-ad-card__link-wrapper{display:block;height:100%;outline:none;position:absolute;top:0;width:100%;z-index:var(--z-index-1-default);}
      .olx-ad-card__link-wrapper:focus{border-radius:var(--border-radius-sm);outline:var(--border-width-hairline) solid var(--color-neutral-130);outline-offset:var(--border-width-hairline);}
      .olx-ad-card__content{border-radius:var(--border-radius-sm);display:flex;flex-direction:column;padding:var(--spacing-2);}
      .olx-ad-card__content--vertical{--carousel-height:180px;gap:var(--spacing-2);height:calc(100% - var(--carousel-height));}
      .olx-ad-card__top{display:flex;flex-direction:column;height:100%;width:100%;}
      @media screen and (min-width:566px){
      .olx-ad-card__top{flex-direction:row;gap:var(--spacing-2);}
      }
      .olx-ad-card__top--vertical{flex-direction:column-reverse;gap:var(--spacing-2);justify-content:flex-end;}
      .olx-ad-card__title{-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box;font-size:14px;font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:normal;}
      .olx-ad-card__title--vertical{-webkit-line-clamp:2;--two-lines-height:37px;height:var(--two-lines-height);}
      .olx-ad-card__title-link{color:inherit;text-decoration:none;}
      .olx-ad-card__badges-items{display:flex;margin:0;margin-top:var(--spacing-1);overflow:hidden;padding:0;position:relative;}
      .olx-ad-card__badges-item{list-style:none;}
      .olx-ad-card__badges-item+.olx-ad-card__badges-item{padding-left:var(--spacing-1);}
      .olx-ad-card__badges-item>span{display:flex;white-space:nowrap;}
      .olx-ad-card__old-price{color:var(--color-neutral-100);text-decoration-line:line-through;width:-moz-max-content;width:max-content;}
      .olx-ad-card__price{width:-moz-max-content;width:max-content;}
      .olx-ad-card__details-ads{display:flex;flex-direction:column;}
      .olx-ad-card__bottom{align-items:center;display:flex;justify-content:space-between;width:100%;}
      .olx-ad-card__bottom-content{display:flex;flex-direction:column;overflow:hidden;}
      .olx-ad-card__location{align-items:center;display:flex;flex-direction:row;gap:var(--spacing-0-5);margin-right:var(--spacing-6);padding:0;}
      .olx-ad-card__location--vertical{align-items:flex-start;flex-direction:column;}
      .olx-ad-card__location svg{color:var(--color-neutral-120);min-width:16px;}
      .olx-ad-card__location p{color:var(--color-neutral-120);line-height:normal;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .olx-ad-card__location-date-container{align-items:flex-start;display:flex;gap:var(--spacing-0-5);width:100%;}
      .olx-alertbox{--background-color:var(--color-neutral-80);--color:var(--color-neutral-130);--svg-color:var(--color-neutral-120);background-color:var(--background-color);border-radius:var(--border-radius-sm);color:var(--color);display:flex;flex-direction:column;font-family:var(--font-family);padding:var(--spacing-2);}
      .olx-alertbox svg{color:var(--svg-color);}
      .olx-alertbox__content-wrapper{display:flex;}
      .olx-alertbox__icon-wrapper{height:24px;width:24px;}
      .olx-alertbox__content{display:flex;flex-direction:column;margin-left:var(--spacing-2);}
      .olx-alertbox__description{display:inline;font-size:var(--font-size-xxs);font-weight:var(--font-weight-regular);}
      @media screen and (min-width:840px){
      .olx-alertbox__description{font-size:var(--font-size-xs);}
      }
      .olx-alertbox__title{align-items:center;display:flex;font-size:var(--font-size-xxs);font-weight:var(--font-weight-semibold);line-height:24px;word-break:break-word;}
      @media screen and (min-width:840px){
      .olx-alertbox__title{font-size:var(--font-size-xs);}
      }
      .olx-badge{align-items:center;background:var(--badge-background-color);color:var(--badge-color);display:inline-flex;font-family:var(--font-family);font-weight:var(--font-weight-semibold);overflow:hidden;white-space:nowrap;}
      .olx-badge:not(.olx-badge--no-gap){-moz-column-gap:var(--spacing-1);column-gap:var(--spacing-1);}
      .olx-badge--small{border-radius:var(--border-radius-xs);font-size:var(--font-size-xxxs);}
      .olx-badge--small{padding:var(--spacing-0-5) var(--spacing-1);}
      .olx-badge--success{--badge-background-color:var(--color-feedback-success-80);--badge-color:var(--color-feedback-success-120);}
      .olx-badge--info{--badge-background-color:var(--color-feedback-info-80);--badge-color:var(--color-feedback-info-110);}
      .olx-badge svg{max-height:16px;max-width:16px;}
      .olx-autocomplete{position:relative;}
      .olx-carousel{position:relative;}
      .olx-carousel__viewport{overflow:hidden;}
      .olx-carousel__content{display:flex;}
      .olx-carousel__next{right:-24px;}
      .olx-carousel__next{align-items:center;background-color:transparent;border:0;border-radius:var(--border-radius-circle);color:var(--carousel-arrow-color);cursor:pointer;display:flex;height:48px;justify-content:center;outline:0;padding:var(--spacing-0-5);position:absolute;top:50%;transform:translateY(-50%);width:48px;z-index:var(--z-index-300-sticky,300);}
      .olx-carousel__next:hover span{background-color:var(--carousel-arrow-background-color-hover);}
      .olx-carousel__next--hide-on-mobile{display:none;}
      @media screen and (min-width:840px){
      .olx-carousel__next--hide-on-mobile{display:flex;}
      }
      .olx-carousel__arrow-icon{align-items:center;background-color:var(--carousel-arrow-background-color-base);border-radius:var(--border-radius-circle);box-shadow:var(--shadow-level-2);}
      .olx-carousel__arrow-icon,.olx-modal{display:flex;height:100%;justify-content:center;width:100%;}
      .olx-modal{align-items:flex-end;background-color:rgba(0,0,0,.333);border:0;opacity:0;pointer-events:none;position:fixed;right:0;top:0;transition:opacity var(--transition-timing-ease) var(--transition-duration-3);visibility:hidden;will-change:transform;z-index:var(--z-index-900-modal,900);}
      @media screen and (min-width:840px){
      .olx-modal{align-items:center;}
      }
      .olx-modal__dialog{background-color:var(--modal-background-color);border-radius:var(--border-radius-md);border-bottom-left-radius:0;border-bottom-right-radius:0;display:flex;flex-direction:column;max-height:var(--modal-max-height);max-width:100%;min-height:200px;opacity:0;padding:var(--spacing-3) var(--spacing-4);position:relative;transform:translateY(100%) scale(.9);transition:all var(--transition-timing-ease) var(--transition-duration-3);width:100%;}
      @media screen and (min-width:840px){
      .olx-modal__dialog{border-radius:var(--border-radius-md);max-width:var(--modal-max-width);transform:translateY(10%) scale(.9);}
      }
      .olx-modal__content{background-color:var(--color-neutral-70);display:flex;flex-direction:column;height:100%;overflow-x:hidden;overflow-y:auto;}
      .olx-modal__content::-webkit-scrollbar{width:10px;}
      .olx-modal__content::-webkit-scrollbar-track{background:var(--color-neutral-80);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb{background:var(--color-neutral-90);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb:hover{background:var(--color-neutral-110);}
      .olx-modal__close-button{align-items:center;align-self:flex-end;background-color:transparent;border:none;border-radius:var(--border-radius-pill);color:var(--modal-button-color);cursor:pointer;display:flex;height:48px;justify-content:center;min-height:48px;width:48px;}
      .olx-modal__close-button:hover{background-color:var(--modal-button-background-color-hover);}
      .olx-logo-olx{min-height:12px;min-width:12px;width:100%;}
      .olx-logo-olx--o{fill:var(--color-secondary-100);}
      .olx-logo-olx--l{fill:var(--color-feedback-success-90);}
      .olx-logo-olx--x{fill:var(--color-primary-100);}
      .olx-default-footer{border-top:1px solid var(--divider-default-background-color);padding:var(--spacing-2) var(--spacing-2) var(--spacing-8);}
      @media screen and (min-width:840px){
      .olx-default-footer{padding:var(--spacing-2) var(--spacing-4) var(--spacing-3);}
      }
      @media screen and (min-width:1200px){
      .olx-default-footer{padding:var(--spacing-2) var(--spacing-9) var(--spacing-3);}
      }
      @media screen and (min-width:1720px){
      .olx-default-footer{display:grid;grid-template-columns:1576px;justify-content:center;}
      }
      .olx-default-footer__links-container{flex-direction:column;gap:var(--spacing-2);padding-bottom:var(--spacing-2);}
      @media screen and (min-width:840px){
      .olx-default-footer__links-container{flex-direction:row;gap:var(--spacing-4);}
      }
      .olx-static-footer__links-container{display:flex;flex-direction:column;gap:var(--spacing-3);padding-top:var(--spacing-2);}
      @media screen and (min-width:1200px){
      .olx-static-footer__links-container{display:grid;grid-template-columns:1fr auto;}
      }
      .olx-static-footer__legal-container,.olx-static-footer__legal-container-links{display:flex;flex-direction:column;justify-content:center;row-gap:var(--spacing-1-5);}
      @media screen and (min-width:840px){
      .olx-static-footer__legal-container-links{-moz-column-gap:var(--spacing-2);column-gap:var(--spacing-2);flex-direction:row;justify-content:flex-start;}
      }
      .olx-static-footer__social-container{display:grid;gap:var(--spacing-1);grid-template-columns:repeat(3,48px);grid-template-rows:repeat(2,48px);justify-content:center;}
      @media screen and (min-width:600px){
      .olx-static-footer__social-container{grid-template-columns:repeat(6,48px);grid-template-rows:48px;}
      }
      @media screen and (min-width:1200px){
      .olx-static-footer__social-container{justify-content:flex-end;}
      }
      .olx-static-footer__legal-container-address{display:block;text-align:center;}
      @media screen and (min-width:840px){
      .olx-static-footer__legal-container-address{text-align:left;}
      }
      .olx-static-footer__icon-wrapper{align-items:center;display:inline-flex;height:48px;justify-content:center;width:48px;}
      .olx-static-footer__social-link{border-radius:100%;padding:var(--spacing-1);transition:all .3s ease;}
      .olx-static-footer__social-link:active svg,.olx-static-footer__social-link:hover svg{color:var(--color-neutral-70);}
      .olx-static-footer__facebook-link:active,.olx-static-footer__facebook-link:hover{background-color:#3a5998;}
      .olx-static-footer__youtube-link:active,.olx-static-footer__youtube-link:hover{background-color:red;}
      .olx-static-footer__tiktok-link:active,.olx-static-footer__tiktok-link:hover{background-color:#040000;}
      .olx-static-footer__linkedin-link:active,.olx-static-footer__linkedin-link:hover{background-color:#0084bf;}
      .olx-static-footer__instagram-link:active,.olx-static-footer__instagram-link:hover{background-color:#e1306c;}
      .olx-static-footer__twitter-link:active,.olx-static-footer__twitter-link:hover{background-color:#040000;}
      .olx-header{display:flex;flex-direction:column;font-family:var(--font-family);justify-content:center;position:relative;z-index:var(--z-index-400-header,400);}
      .olx-header__skip-links{clip:rect(1px,1px,1px,1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-header__skip-links:focus{clip:auto;background-color:var(--color-neutral-70);box-shadow:0 0 0 2px var(--color-neutral-70);color:var(--color-neutral-130);display:inline-block;height:50px;left:0;outline:var(--border-width-thin) solid var(--color-neutral-130);overflow:initial;top:50%;transform:translateY(-50%);transition:none;white-space:normal;width:60px;z-index:2;}
      .olx-header__main-menu{background-color:var(--color-neutral-70);border-bottom:1px solid var(--color-neutral-90);display:flex;flex-direction:column;justify-content:center;min-height:80px;padding:var(--spacing-2) var(--spacing-2);transition:transform var(--transition-duration-5) var(--transition-timing-ease-in-out);}
      @media screen and (min-width:840px){
      .olx-header__main-menu{padding:var(--spacing-2) var(--spacing-4);}
      }
      @media screen and (min-width:1200px){
      .olx-header__main-menu{padding:var(--spacing-2) var(--spacing-9);}
      }
      .olx-header__items{align-items:center;display:flex;margin:0;padding:0;}
      @media screen and (min-width:1200px){
      .olx-header__items{-moz-column-gap:var(--spacing-2);column-gap:var(--spacing-2);}
      }
      @media screen and (min-width:1500px){
      .olx-header__items{-moz-column-gap:var(--spacing-3);column-gap:var(--spacing-3);}
      }
      .olx-header__icon-button{align-items:center;background-color:transparent;border:none;color:var(--color-neutral-130);cursor:pointer;display:flex;height:48px;justify-content:center;margin:0;outline:none;padding:0;width:48px;}
      .olx-header__icon-button :hover{color:var(--link-color-main-hover);}
      .olx-header__icon-button :focus{border-radius:var(--border-radius-xxs);outline:var(--border-width-thin) solid var(--color-neutral-130);}
      .olx-header__item{align-items:center;display:flex;list-style:none;}
      .olx-header__item[data-variant=anunciar]{margin-left:var(--spacing-1-5);}
      @media screen and (max-width:1200px){
      .olx-header__item[data-myads=true],.olx-header__item[data-professional=true]{display:none;}
      }
      @media screen and (min-width:1200px){
      .olx-header__item[data-variant=anunciar]{margin-left:0;}
      }
      .olx-header__link{-moz-column-gap:var(--spacing-1);column-gap:var(--spacing-1);}
      @media screen and (max-width:1200px){
      .olx-header__link{padding:12px;}
      }
      .olx-header__link:hover{text-decoration:none;}
      .olx-header__primary-menu{display:flex;flex-direction:row;justify-content:space-between;margin:0 auto;max-width:1576px;width:100%;}
      .olx-header__burger-menu{height:48px;justify-content:flex-start;width:48px;}
      .olx-header__burger-menu:focus{border-radius:var(--border-radius-xxs);outline:var(--color-neutral-130) solid var(--border-width-thin);}
      @media screen and (max-width:360px){
      .olx-header__burger-menu{height:44px;width:44px;}
      }
      @media screen and (min-width:840px){
      .olx-header__burger-menu{display:none;}
      }
      .olx-header__column-left{align-items:center;display:flex;flex:1;position:relative;}
      .olx-header__column-right{display:flex;transition:all var(--transition-duration-5) var(--transition-timing-ease);}
      .olx-header__olx-container{align-items:center;color:var(--color-neutral-130);-moz-column-gap:32px;column-gap:32px;display:flex;font-size:var(--font-size-xxs);height:48px;width:48px;}
      .olx-header__logo-wrapper{height:24px;width:24px;}
      @media screen and (max-width:1200px){
      .olx-header__label{clip:rect(1px,1px,1px,1px);display:flex;height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-header__label[data-variant=chat],.olx-header__label[data-variant=notification]{clip:auto;display:initial;height:auto;overflow:initial;position:static;white-space:normal;width:auto;}
      }
      @media screen and (max-width:840px){
      .olx-header__label[data-variant=chat],.olx-header__label[data-variant=notification]{clip:rect(1px,1px,1px,1px);display:flex;height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      }
      .olx-header__desapegar-button{font-size:var(--font-size-xxs);}
      @media screen and (max-width:840px){
      .olx-header__desapegar-button{height:36px;padding:var(--spacing-1) var(--spacing-2);}
      }
      .olx-header__profile-item{align-items:center;display:flex;list-style:none;}
      .olx-header__profile-link{align-items:center;background-color:transparent;border:0;border:1px solid var(--color-neutral-90);border-radius:var(--border-radius-pill);color:var(--color-neutral-130);cursor:pointer;display:flex;font-family:var(--font-family);font-size:var(--font-size-xxs);font-weight:var(--font-weight-semibold);height:40px;justify-content:center;line-height:var(--font-lineheight-medium);padding:var(--spacing-0-5);transition:all ease var(--transition-duration-3);width:135px;}
      .olx-header__profile-link:hover{border-color:var(--color-secondary-100);color:var(--link-color-main-hover);text-decoration:none;}
      .olx-header__profile-link:focus{border-radius:var(--border-radius-pill);box-shadow:none;outline:var(--border-width-thin) solid var(--color-neutral-130);}
      @media screen and (max-width:840px){
      .olx-header__profile-link{display:none;}
      }
      .olx-header__search{margin-left:var(--spacing-3);margin-right:var(--spacing-1-5);width:100%;}
      @media screen and (min-width:840px){
      .olx-header__search{margin-right:var(--spacing-3);}
      }
      @media screen and (max-width:840px){
      .olx-header__search[data-hasnavbar=false],.olx-header__search[data-hasnavbar=false] .olx-text-input__input-field{display:none;}
      }
      .olx-header__search-fluid{padding-left:var(--spacing-3);padding-right:var(--spacing-3);padding-top:var(--spacing-2);width:100%;}
      @media screen and (min-width:840px){
      .olx-header__search-fluid,.olx-header__search-fluid .olx-text-input__input-field{display:none;}
      }
      @media screen and (max-width:840px){
      .olx-header__search-fluid{padding-left:0;padding-right:0;}
      }
      .olx-header__overlay{background:var(--color-neutral-130);height:calc(100vh - 100%);height:calc(100svh - 100%);left:0;opacity:0;pointer-events:none;position:absolute;top:100%;transition:opacity 1s ease;width:100%;}
      @media screen and (min-width:840px){
      .olx-header__overlay{display:none;}
      }
      .olx-header__overflow{background-color:var(--color-neutral-70);box-shadow:var(--shadow-level-2);height:0;list-style:none;opacity:0;padding-bottom:2px;padding-top:2px;pointer-events:none;position:absolute;scroll-behavior:smooth;top:64px;transition:transform ease var(--transition-duration-3),opacity ease var(--transition-duration-3);width:280px;z-index:var(--z-index-700-overlay);}
      @media screen and (min-width:840px){
      .olx-header__overflow{border-radius:var(--border-radius-sm);}
      .olx-header__overflow[data-islogged=false]{display:none;}
      }
      @media screen and (max-width:840px){
      .olx-header__overflow:not([data-hasnavbar=true]){border-radius:0;height:calc(100vh - 100%);height:calc(100svh - 100%);left:0;overflow:hidden;padding-bottom:50px;top:100%;transform:translateX(-100%);}
      }
      .olx-header__overflow-item[data-divider=true]{border-bottom:1px solid var(--color-neutral-90);margin-bottom:var(--spacing-0-5);}
      .olx-header__overflow-link{color:var(--color-neutral-130);-moz-column-gap:16px;column-gap:16px;cursor:pointer;display:inline-flex;font-size:var(--font-size-xxs);justify-content:flex-start;padding:var(--spacing-2);position:relative;text-decoration:none;transition:all ease var(--transition-duration-3);width:100%;}
      .olx-header__overflow-link:hover{background:var(--color-neutral-80);text-decoration:none;}
      .olx-header__overflow-link:focus{transform:scale(.98);}
      .olx-color-primary-100{color:white}
      .olx-color-secondary-100{color:var(--color-secondary-100);}
      .olx-color-neutral-70{color:var(--color-neutral-70);}
      .olx-color-neutral-100{color:var(--color-neutral-100);}
      .olx-color-neutral-120{color:var(--color-neutral-120);}
      .olx-color-feedback-success-120{color:var(--color-feedback-success-120);}
      .olx-d-flex{display:flex;}
      .olx-ai-flex-start{align-items:flex-start;}
      .olx-ai-center{align-items:center;}
      .olx-fd-row{flex-direction:row;}
      .olx-fd-column{flex-direction:column;}
      .olx-fd-column-reverse{flex-direction:column-reverse;}
      .olx-jc-flex-start{justify-content:flex-start;}
      .olx-jc-center{justify-content:center;}
      .olx-jc-space-between{justify-content:space-between;}
      .olx-ml-0-5{margin-left:var(--spacing-0-5);}
      .olx-ml-1{margin-left:var(--spacing-1);}
      .olx-ml-2{margin-left:var(--spacing-2);}
      .olx-mr-2{margin-right:var(--spacing-2);}
      .olx-mt-1{margin-top:var(--spacing-1);}
      .olx-mt-2{margin-top:var(--spacing-2);}
      .olx-mt-3{margin-top:var(--spacing-3);}
      .olx-mb-2{margin-bottom:var(--spacing-2);}
      .olx-mb-3{margin-bottom:var(--spacing-3);}
      .olx-mb-4{margin-bottom:var(--spacing-4);}
      .olx-pl-1{padding-left:var(--spacing-1);}
      .olx-pr-1{padding-right:var(--spacing-1);}
      .olx-pt-6{padding-top:var(--spacing-6);}
      .olx-pb-4{padding-bottom:var(--spacing-4);}
      .olx-mb-stack-quarck{margin-bottom:var(--spacing-stack-quarck);}
      .ajfs2S{align-items:center;background:transparent;border:none;border-radius:var(--border-radius-lg);cursor:pointer;display:flex;height:44px;justify-content:center;outline:none;position:absolute;right:4px;top:50%;transform:translateY(-50%);transition:var(--transition-duration-2);width:44px;z-index:var(--z-index-1-default);}
      .ajfs2S svg{color:var(--color-neutral-130);}
      .ajfs2S:active,.ajfs2S:hover{background:var(--color-neutral-90);}
      .ajfs2S:focus{outline:var(--color-secondary-100) solid var(--border-width-thin);}
      ._2dsuYh{align-items:center;display:flex;height:32px;justify-content:center;width:32px;}
      .S6FMF5{height:48px;margin:0;position:relative;}
      .S6FMF5 input{padding-right:var(--spacing-6);}
      .rec-gallery-galleries,.rec-gallery-gallery{display:flex;flex-direction:column;}
      .rec-gallery-gallery+.rec-gallery-gallery{margin-top:var(--spacing-6);}
      .rec-gallery-carousel__viewport{margin-left:calc(var(--spacing-1)*-1);padding-left:var(--spacing-0-25);}
      .rec-gallery-carousel__slide{flex:0 0 240px;min-width:0;padding:var(--spacing-0-25);padding-left:var(--spacing-2);position:relative;}
      @media screen and (min-width:840px){
      .rec-gallery-carousel__slide{flex:0 0 25%;}
      }
      @media screen and (min-width:1200px){
      .rec-gallery-carousel__slide{flex:0 0 20%;}
      }
      @media screen and (min-width:1500px){
      .rec-gallery-carousel__slide{flex:0 0 16.66%;}
      }
      .rec-gallery-carousel__slide[data-reduced=true]{flex:0 0 240px;}
      .rec-gallery-adcard{height:396px;}
      .rec-gallery-title__wrapper{display:flex;justify-content:space-between;margin-bottom:var(--spacing-3);width:100%;}
      *,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:currentColor;}
      :before,:after{--tw-content:"";}
      html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;}
      body{margin:0;line-height:inherit;}
      hr{height:0;color:inherit;border-top-width:1px;}
      h1,h2,h3{font-size:inherit;font-weight:inherit;}
      a{color:inherit;text-decoration:inherit;}
      button,input{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0;}
      button{text-transform:none;}
      button,[type=button]{-webkit-appearance:button;background-color:transparent;background-image:none;}
      h1,h2,h3,hr,p{margin:0;}
      ul{list-style:none;margin:0;padding:0;}
      input::placeholder{opacity:1;color:#9ca3af;}
      button,[role=button]{cursor:pointer;}
      :disabled{cursor:default;}
      img,svg,iframe{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,:before,:after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      *,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:currentColor;}
      :before,:after{--tw-content:"";}
      html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;}
      body{margin:0;line-height:inherit;}
      hr{height:0;color:inherit;border-top-width:1px;}
      h1,h2,h3{font-size:inherit;font-weight:inherit;}
      a{color:inherit;text-decoration:inherit;}
      button,input{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0;}
      button{text-transform:none;}
      button,[type=button]{-webkit-appearance:button;background-color:transparent;background-image:none;}
      h1,h2,h3,hr,p{margin:0;}
      ul{list-style:none;margin:0;padding:0;}
      input::placeholder{opacity:1;color:#9ca3af;}
      button,[role=button]{cursor:pointer;}
      :disabled{cursor:default;}
      img,svg,iframe{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,:before,:after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      *,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:currentColor;}
      :before,:after{--tw-content:"";}
      html{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";font-feature-settings:normal;font-variation-settings:normal;}
      body{margin:0;line-height:inherit;}
      hr{height:0;color:inherit;border-top-width:1px;}
      h1,h2,h3{font-size:inherit;font-weight:inherit;}
      a{color:inherit;text-decoration:inherit;}
      button,input{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0;}
      button{text-transform:none;}
      button,[type=button]{-webkit-appearance:button;background-color:transparent;background-image:none;}
      h1,h2,h3,hr,p{margin:0;}
      ul{list-style:none;margin:0;padding:0;}
      input::placeholder{opacity:1;color:#9ca3af;}
      button,[role=button]{cursor:pointer;}
      :disabled{cursor:default;}
      img,svg,iframe{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,:before,:after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      .eqqGqr{display:none;}
      @media (min-width: 52.5em){
      .eqqGqr{display:block;}
      }
      .vKKEq{display:none;}
      @media (min-width: 45em){
      .vKKEq{display:block;}
      }
      .ckFhRN{display:none;}
      @media (min-width: 1em){
      .ckFhRN{display:block;}
      }
      @media (min-width: 52.5em){
      .ckFhRN{display:block;}
      }
      .dFeJTI{display:block;}
      @media (min-width: 52.5em){
      .dFeJTI{display:none;}
      }
      @media (min-width: 52.5em){
      .eZENlu{display:none;}
      }
      @media (min-width: 1em) and (max-width: 52.4375em){
      .bidUvU{display:none;}
      }
      .qaqUu{width:100%;}
      @media (min-width: 1em){
      .qaqUu{height:2px;width:2px;}
      }
      @media (min-width: 52.5em){
      .qaqUu{height:8px;width:8px;}
      }
      .jZvhZY{width:100%;}
      @media (min-width: 1em){
      .jZvhZY{height:24px;width:24px;}
      }
      @media (min-width: 52.5em){
      .jZvhZY{height:24px;width:24px;}
      }
      .YSXKQ{width:100%;}
      @media (min-width: 1em){
      .YSXKQ{height:24px;width:24px;}
      }
      @media (min-width: 52.5em){
      .YSXKQ{height:32px;width:32px;}
      }
      .VkedQ{width:100%;}
      @media (min-width: 1em){
      .VkedQ{height:24px;width:24px;}
      }
      .hnWKZq{width:100%;}
      @media (min-width: 1em){
      .hnWKZq{height:16px;width:16px;}
      }
      @media (min-width: 52.5em){
      .hnWKZq{height:16px;width:16px;}
      }
      .iCkJT{width:100%;}
      @media (min-width: 52.5em){
      .iCkJT{height:4px;width:4px;}
      }
      .jjAoYZ{width:100%;}
      @media (min-width: 1em){
      .jjAoYZ{height:32px;width:32px;}
      }
      .fRFGxf{width:100%;}
      @media (min-width: 1em){
      .fRFGxf{height:16px;width:16px;}
      }
      .eTAynA{width:100%;}
      @media (min-width: 1em){
      .eTAynA{height:8px;width:8px;}
      }
      .ccoOnh{width:100%;}
      @media (min-width: 1em){
      .ccoOnh{height:32px;width:32px;}
      }
      @media (min-width: 52.5em){
      .ccoOnh{height:8px;width:8px;}
      }
      .jtSpqv{width:100%;}
      @media (min-width: 1em){
      .jtSpqv{height:32px;width:32px;}
      }
      @media (min-width: 52.5em){
      .jtSpqv{height:16px;width:16px;}
      }
      .dmeyOb{width:100%;}
      @media (min-width: 1em){
      .dmeyOb{height:8px;width:8px;}
      }
      @media (min-width: 52.5em){
      .dmeyOb{height:16px;width:16px;}
      }
      .gbSaoO{width:100%;}
      @media (min-width: 1em){
      .gbSaoO{height:8px;width:8px;}
      }
      @media (min-width: 52.5em){
      .gbSaoO{height:32px;width:32px;}
      }
      .jZVVT{width:100%;}
      @media (min-width: 1em){
      .jZVVT{height:32px;width:32px;}
      }
      @media (min-width: 52.5em){
      .jZVVT{height:32px;width:32px;}
      }
      .kyiLNg{width:100%;}
      @media (min-width: 52.5em){
      .kyiLNg{height:32px;width:32px;}
      }
      @media (min-width: 1em){
      .bTEwpS{order:0;}
      }
      @media (min-width: 1em){
      .bgoMCM{order:1;}
      }
      @media (min-width: 1em){
      .iwowFd{order:2;}
      }
      @media (min-width: 52.5em){
      .iwowFd{order:1;}
      }
      @media (min-width: 1em){
      .eXkntI{order:4;}
      }
      @media (min-width: 52.5em){
      .eXkntI{order:3;}
      }
      @media (min-width: 1em){
      .biWSIX{order:9;}
      }
      @media (min-width: 52.5em){
      .biWSIX{order:5;}
      }
      @media (min-width: 1em){
      .fJvuvt{order:11;}
      }
      @media (min-width: 52.5em){
      .fJvuvt{order:7;}
      }
      @media (min-width: 1em){
      .jMBOCG{order:14;}
      }
      @media (min-width: 52.5em){
      .jMBOCG{order:13;}
      }
      @media (min-width: 1em){
      .duuEbc{order:18;}
      }
      @media (min-width: 52.5em){
      .duuEbc{order:16;}
      }
      @media (min-width: 1em){
      .kRruSJ{order:20;}
      }
      @media (min-width: 52.5em){
      .kRruSJ{order:18;}
      }
      @media (min-width: 1em){
      .gVgMGW{order:22;}
      }
      @media (min-width: 52.5em){
      .gVgMGW{order:20;}
      }
      @media (min-width: 1em){
      .fehGuf{order:24;}
      }
      @media (min-width: 52.5em){
      .fehGuf{order:22;}
      }
      @media (min-width: 1em){
      .bjPHHm{order:26;}
      }
      @media (min-width: 52.5em){
      .bjPHHm{order:24;}
      }
      @media (min-width: 1em){
      .jHOiUX{order:28;}
      }
      @media (min-width: 52.5em){
      .jHOiUX{order:26;}
      }
      @media (min-width: 52.5em){
      .eHwusb{order:29;}
      }
      @media (min-width: 1em){
      .jxfkIO{order:3;}
      }
      @media (min-width: 52.5em){
      .jxfkIO{order:6;}
      }
      @media (min-width: 1em){
      .hVBMMM{order:5;}
      }
      @media (min-width: 52.5em){
      .hVBMMM{order:8;}
      }
      @media (min-width: 1em){
      .kpCWBk{order:6;}
      }
      @media (min-width: 52.5em){
      .kpCWBk{order:10;}
      }
      @media (min-width: 1em){
      .eUxWSm{order:7;}
      }
      @media (min-width: 1em){
      .ipeowV{order:8;}
      }
      @media (min-width: 52.5em){
      .ipeowV{order:0;}
      }
      @media (min-width: 1em){
      .hpznci{order:10;}
      }
      @media (min-width: 1em){
      .ldCVRg{order:12;}
      }
      @media (min-width: 1em){
      .hIQvOE{order:13;}
      }
      @media (min-width: 1em){
      .WTzEA{order:15;}
      }
      @media (min-width: 52.5em){
      .WTzEA{order:17;}
      }
      @media (min-width: 1em){
      .ikhjpf{order:19;}
      }
      @media (min-width: 52.5em){
      .ikhjpf{order:21;}
      }
      @media (min-width: 1em){
      .eufdoK{order:23;}
      }
      @media (min-width: 52.5em){
      .eufdoK{order:25;}
      }
      @media (min-width: 1em){
      .gyFliR{order:27;}
      }
      @media (min-width: 1em){
      .bJFnSS{order:16;}
      }
      @media (min-width: 52.5em){
      .bJFnSS{order:11;}
      }
      @media (min-width: 1em){
      .izJjFH{order:17;}
      }
      @media (min-width: 52.5em){
      .izJjFH{order:12;}
      }
      @media (min-width: 1em){
      .dmSScE{order:21;}
      }
      @media (min-width: 52.5em){
      .dmSScE{order:19;}
      }
      @media (min-width: 1em){
      .gWUwFL{order:25;}
      }
      @media (min-width: 52.5em){
      .gWUwFL{order:23;}
      }
      @media (min-width: 1em){
      .jbSupI{order:29;}
      }
      @media (min-width: 52.5em){
      .jbSupI{order:27;}
      }
      @media (min-width: 1em){
      .bRvyBK{order:30;}
      }
      @media (min-width: 52.5em){
      .bRvyBK{order:28;}
      }
      @media (min-width: 52.5em){
      .hMpuIj{order:2;}
      }
      @media (min-width: 52.5em){
      .blJUlT{order:4;}
      }
      @media (min-width: 52.5em){
      .gHUNGR{order:9;}
      }
      @media (min-width: 52.5em){
      .bWQuzC{order:14;}
      }
      @media (min-width: 52.5em){
      .bJBjGa{order:15;}
      }
      @media (min-width: 1em){
      .eOOSgR{order:0;}
      }
      @media (min-width: 52.5em){
      .eOOSgR{order:2;}
      }
      @media (min-width: 1em){
      .eNYuAb{order:2;}
      }
      @media (min-width: 52.5em){
      .eNYuAb{order:5;}
      }
      @media (min-width: 1em){
      .cqVNVF{order:5;}
      }
      @media (min-width: 52.5em){
      .cqVNVF{order:7;}
      }
      @media (min-width: 1em){
      .hdSEbB{order:9;}
      }
      @media (min-width: 52.5em){
      .hdSEbB{order:10;}
      }
      @media (min-width: 1em){
      .fWWdwl{order:11;}
      }
      @media (min-width: 1em){
      .cjdioF{order:3;}
      }
      @media (min-width: 52.5em){
      .cjdioF{order:3;}
      }
      @media (min-width: 1em){
      .gPstkR{order:4;}
      }
      @media (min-width: 52.5em){
      .gPstkR{order:4;}
      }
      @media (min-width: 1em){
      .kBsbVK{order:6;}
      }
      @media (min-width: 1em){
      .hQZMji{order:7;}
      }
      @media (min-width: 52.5em){
      .hQZMji{order:8;}
      }
      @media (min-width: 1em){
      .ilTMJK{order:8;}
      }
      @media (min-width: 1em){
      .igguHp{order:12;}
      }
      @media (min-width: 52.5em){
      .igguHp{order:11;}
      }
      @media (min-width: 52.5em){
      .kwBCR{order:0;}
      }
      @media (min-width: 52.5em){
      .islsjX{order:1;}
      }
      @media (min-width: 52.5em){
      .dqVBIN{order:6;}
      }
      .lbubah{box-sizing:border-box;display:flex;flex:1 0 auto;flex-flow:wrap;}
      @media only screen and (min-width: 1rem){
      .lbubah{margin-left:-0.5rem;margin-right:-0.5rem;}
      }
      @media only screen and (min-width: 37.5rem){
      .lbubah{margin-left:-0.5rem;margin-right:-0.5rem;}
      }
      @media only screen and (min-width: 45rem){
      .lbubah{margin-left:-0.75rem;margin-right:-0.75rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .lbubah{margin-left:-0.75rem;margin-right:-0.75rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .lbubah{margin-left:-0.75rem;margin-right:-0.75rem;}
      }
      .eMnLDp{box-sizing:border-box;flex:1 0 auto;max-width:100%;display:flex;flex-direction:column;}
      @media only screen and (min-width: 1rem){
      .eMnLDp{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 37.5rem){
      .eMnLDp{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 45rem){
      .eMnLDp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .eMnLDp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 71.19rem){
      .eMnLDp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 78.69rem){
      .eMnLDp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .eMnLDp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 91.19rem){
      .eMnLDp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 103.69rem){
      .eMnLDp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 116.82rem){
      .eMnLDp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 1rem){
      .eMnLDp{flex:1 1 100%;max-width:100%;}
      }
      @media only screen and (min-width: 45rem){
      .eMnLDp{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 52.5rem){
      .eMnLDp{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 71.19rem){
      .eMnLDp{flex:1 1 33.3333%;max-width:33.3333%;}
      }
      @media only screen and (min-width: 78.69rem){
      .eMnLDp{flex:1 1 33.3333%;max-width:33.3333%;}
      }
      @media only screen and (min-width: 79.5rem){
      .eMnLDp{flex:1 1 33.3333%;max-width:33.3333%;}
      }
      @media only screen and (min-width: 91.19rem){
      .eMnLDp{flex:1 1 33.3333%;max-width:33.3333%;}
      }
      @media only screen and (min-width: 103.69rem){
      .eMnLDp{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 116.82rem){
      .eMnLDp{flex:1 1 25%;max-width:25%;}
      }
      .dTdtCa{margin-right:auto;margin-left:auto;max-width:100%;box-sizing:border-box;}
      @media only screen and (min-width: 1rem){
      .dTdtCa{padding-left:1rem;padding-right:1rem;}
      }
      @media only screen and (min-width: 37.5rem){
      .dTdtCa{padding-left:1rem;padding-right:1rem;}
      }
      @media only screen and (min-width: 45rem){
      .dTdtCa{padding-left:1.5rem;padding-right:1.5rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .dTdtCa{padding-left:1.5rem;padding-right:1.5rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .dTdtCa{padding-left:1.5rem;padding-right:1.5rem;}
      }
      @media only screen and (min-width: 1rem){
      .dTdtCa{width:100%;}
      }
      @media only screen and (min-width: 37.5rem){
      .dTdtCa{width:100%;}
      }
      @media only screen and (min-width: 45rem){
      .dTdtCa{width:100%;}
      }
      @media only screen and (min-width: 52.5rem){
      .dTdtCa{width:79.5rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .dTdtCa{width:79.5rem;}
      }
      .lpoEoZ{box-sizing:border-box;flex:1 0 auto;max-width:100%;display:flex;flex-direction:column;}
      @media only screen and (min-width: 1rem){
      .lpoEoZ{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 37.5rem){
      .lpoEoZ{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 45rem){
      .lpoEoZ{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .lpoEoZ{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 71.19rem){
      .lpoEoZ{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 78.69rem){
      .lpoEoZ{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .lpoEoZ{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 91.19rem){
      .lpoEoZ{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 103.69rem){
      .lpoEoZ{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 116.82rem){
      .lpoEoZ{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .lpoEoZ{flex:1 1 100%;max-width:100%;}
      }
      .hRTDUb{box-sizing:border-box;flex:1 0 auto;max-width:100%;display:flex;flex-direction:column;}
      @media only screen and (min-width: 1rem){
      .hRTDUb{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 37.5rem){
      .hRTDUb{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 45rem){
      .hRTDUb{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .hRTDUb{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 71.19rem){
      .hRTDUb{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 78.69rem){
      .hRTDUb{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .hRTDUb{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 91.19rem){
      .hRTDUb{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 103.69rem){
      .hRTDUb{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 116.82rem){
      .hRTDUb{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .hRTDUb{flex:1 1 66.6667%;max-width:66.6667%;}
      }
      @media only screen and (min-width: 71.19rem){
      .hRTDUb{flex:1 1 50%;max-width:50%;}
      }
      @media only screen and (min-width: 78.69rem){
      .hRTDUb{flex:1 1 50%;max-width:50%;}
      }
      @media only screen and (min-width: 79.5rem){
      .hRTDUb{flex:1 1 50%;max-width:50%;}
      }
      @media only screen and (min-width: 91.19rem){
      .hRTDUb{flex:1 1 58.3333%;max-width:58.3333%;}
      }
      @media only screen and (min-width: 103.69rem){
      .hRTDUb{flex:1 1 66.6667%;max-width:66.6667%;}
      }
      @media only screen and (min-width: 116.82rem){
      .hRTDUb{flex:1 1 66.6667%;max-width:66.6667%;}
      }
      .dBnjzp{box-sizing:border-box;flex:1 0 auto;max-width:100%;display:flex;flex-direction:column;}
      @media only screen and (min-width: 1rem){
      .dBnjzp{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 37.5rem){
      .dBnjzp{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 45rem){
      .dBnjzp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .dBnjzp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 71.19rem){
      .dBnjzp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 78.69rem){
      .dBnjzp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .dBnjzp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 91.19rem){
      .dBnjzp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 103.69rem){
      .dBnjzp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 116.82rem){
      .dBnjzp{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .dBnjzp{flex:1 1 33.3333%;max-width:33.3333%;}
      }
      @media only screen and (min-width: 71.19rem){
      .dBnjzp{flex:1 1 33.3333%;max-width:33.3333%;}
      }
      @media only screen and (min-width: 78.69rem){
      .dBnjzp{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 79.5rem){
      .dBnjzp{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 91.19rem){
      .dBnjzp{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 103.69rem){
      .dBnjzp{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 116.82rem){
      .dBnjzp{flex:1 1 25%;max-width:25%;}
      }
      .hBpmQd{box-sizing:border-box;flex:1 0 auto;max-width:100%;display:flex;flex-direction:column;}
      @media only screen and (min-width: 1rem){
      .hBpmQd{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 37.5rem){
      .hBpmQd{padding-right:0.5rem;padding-left:0.5rem;}
      }
      @media only screen and (min-width: 45rem){
      .hBpmQd{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 52.5rem){
      .hBpmQd{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 71.19rem){
      .hBpmQd{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 78.69rem){
      .hBpmQd{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 79.5rem){
      .hBpmQd{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 91.19rem){
      .hBpmQd{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 103.69rem){
      .hBpmQd{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 116.82rem){
      .hBpmQd{padding-right:0.75rem;padding-left:0.75rem;}
      }
      @media only screen and (min-width: 71.19rem){
      .hBpmQd{flex:1 1 16.6667%;max-width:16.6667%;}
      }
      @media only screen and (min-width: 78.69rem){
      .hBpmQd{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 79.5rem){
      .hBpmQd{flex:1 1 25%;max-width:25%;}
      }
      @media only screen and (min-width: 91.19rem){
      .hBpmQd{flex:1 1 16.6667%;max-width:16.6667%;}
      }
      @media only screen and (min-width: 103.69rem){
      .hBpmQd{flex:1 1 8.33333%;max-width:8.33333%;}
      }
      @media only screen and (min-width: 116.82rem){
      .hBpmQd{flex:1 1 8.33333%;max-width:8.33333%;}
      }
      .dQQnbA{background-color:rgb(229, 229, 229);height:1px;}
      @media (min-width: 52.5em){
      .dQQnbA{width:88px;}
      }
      .olx-button{-webkit-box-align:center;align-items:center;background-color:var(--button-background-color);border-color:var(--button-border);border-radius:var(--border-radius-pill);border-style:solid;border-width:var(--border-width-hairline);color:var(--button-color-font);cursor:pointer;display:inline-flex;font-family:var(--font-family);font-size:var(--button-font-size);font-weight:var(--font-weight-semibold);height:var(--button-height);-webkit-box-pack:center;justify-content:center;line-height:var(--button-line-height);min-width:72px;outline:none;padding:var(--button-padding);position:relative;text-decoration:initial;width:fit-content;}
      .olx-button--a{text-decoration:none;}
      .olx-button:active{transform:scale(0.96);}
      .olx-button:active,.olx-button:not(:active){transition:all var(--transition-duration-1) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:not(:hover){transition:all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:focus{outline:var(--color-neutral-130) solid var(--border-width-thin);outline-offset:var(--border-width-thin);transition:outline 0ms ease 0s, outline-offset 0ms ease 0s;}
      .olx-button:not(.olx-button--disabled):hover{background-color:var(--button-background-color-hover);border-color:var(--button-border-color-hover);transition:all var(--transition-duration-2) var(--transition-timing-ease-in) 0ms,outline 0ms,outline-offset 0ms;}
      .olx-button:focus:not(:focus-visible){outline:none;outline-offset:0px;}
      .olx-button--small{--button-height:32px;--button-padding:var(--spacing-1) var(--spacing-2);--button-font-size:var(--font-size-xxs);--button-line-height:var(--font-lineheight-tight);}
      .olx-button--medium{--button-height:40px;--button-padding:var(--spacing-1) var(--spacing-3);--button-font-size:var(--font-size-xs);--button-line-height:var(--font-lineheight-superdistant);}
      .olx-button--large{--button-height:48px;--button-padding:var(--spacing-2) var(--spacing-3);--button-font-size:var(--font-size-xs);--button-line-height:var(--font-lineheight-supertight);}
      .olx-button--primary{--button-background-color:var(--button-primary-background-color-base);--button-border:var(--button-primary-border-color-base);--button-color-font:var(--button-primary-color-font-base);--button-background-color-hover:var(--button-primary-background-color-hover);--button-border-color-hover:var(--button-primary-border-color-hover);}
      .olx-button--secondary{--button-background-color:var(--button-secondary-background-color-base);--button-border:var(--button-secondary-border-color-base);--button-color-font:var(--button-secondary-color-font-base);--button-background-color-hover:var(--button-secondary-background-color-hover);--button-border-color-hover:var(--button-secondary-border-color-hover);}
      .olx-button--link-button{--button-background-color:var(--button-link-button-background-color-base);--button-border:var(--button-link-button-border-color-base);--button-color-font:var(--button-link-button-color-font-base);--button-background-color-hover:var(--button-link-button-background-color-hover);--button-border-color-hover:var(--button-link-button-border-color-hover);}
      .olx-button__content-wrapper{-webkit-box-align:center;align-items:center;display:inline-flex;-webkit-box-pack:center;justify-content:center;visibility:visible;}
      .olx-button__icon-wrapper{fill:currentcolor;-webkit-box-align:center;align-items:center;display:inline-flex;height:24px;-webkit-box-pack:center;justify-content:center;margin-right:var(--spacing-1);pointer-events:none;width:24px;}
      .olx-button__icon-wrapper svg{height:24px;width:24px;}
      .olx-link{-webkit-box-align:center;align-items:center;color:var(--link-color);cursor:pointer;display:inline-flex;font-family:var(--font-family);font-size:var(--font-size);font-weight:var(--font-weight-semibold);-webkit-box-pack:center;justify-content:center;line-height:var(--font-lineheight);outline:none;text-decoration:none;transition:all var(--transition-duration-3) var(--transition-timing-ease);}
      .olx-link:active{color:var(--link-color-active);}
      .olx-link:focus{border-radius:var(--border-radius-xxs);outline:var(--border-width-thin) solid var(--color-neutral-130);}
      .olx-link:hover{color:var(--link-color-hover);text-decoration:underline;}
      .olx-link:focus:not(:focus-visible){box-shadow:none;outline:0px;}
      .olx-link--caption{--font-size:var(--font-size-xxxs);--font-lineheight:var(--font-lineheight-medium);}
      .olx-link--small{--font-size:var(--font-size-xxs);--font-lineheight:var(--font-lineheight-distant);}
      .olx-link--medium{--font-size:var(--font-size-xs);--font-lineheight:var(--font-lineheight-superdistant);}
      .olx-link--main{--link-color:var(--link-color-main-base);--link-color-hover:var(--link-color-main-hover);--link-color-active:var(--link-color-main-active);}
      .olx-link--grey{--link-color:var(--link-color-grey-base);--link-color-hover:var(--link-color-grey-hover);--link-color-active:var(--link-color-grey-active);}
      .olx-text{color:var(--text-color);display:block;font-family:var(--font-family);font-style:normal;font-weight:var(--font-weight-regular);margin:0px;padding:0px;word-break:break-word;}
      .olx-text--title-large{font-size:var(--font-size-lg);font-weight:var(--font-weight-semibold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width: 840px){
      .olx-text--title-large{font-size:var(--font-size-xxl);}
      }
      .olx-text--title-medium{font-size:var(--font-size-md);font-weight:var(--font-weight-semibold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width: 840px){
      .olx-text--title-medium{font-size:var(--font-size-lg);}
      }
      .olx-text--title-small{font-size:var(--font-size-sm);font-weight:var(--font-weight-bold);line-height:var(--font-lineheight-medium);}
      @media screen and (min-width: 840px){
      .olx-text--title-small{font-size:var(--font-size-md);}
      }
      .olx-text--body-large{font-size:var(--font-size-sm);}
      .olx-text--body-large,.olx-text--body-medium{line-height:var(--font-lineheight-superdistant);}
      .olx-text--body-medium{font-size:var(--font-size-xs);}
      .olx-text--body-small{font-size:var(--font-size-xxs);line-height:var(--font-lineheight-distant);}
      .olx-text--caption{font-size:var(--font-size-xxxs);line-height:var(--font-lineheight-medium);}
      .olx-text--light,.olx-text--regular{font-weight:var(--font-weight-regular);}
      .olx-text--semibold{font-weight:var(--font-weight-semibold);}
      .olx-text--bold{font-weight:var(--font-weight-bold);}
      .olx-text--inline{display:inline;}
      .olx-text--block{display:block;}
      .olx-text-input__input-container{-webkit-box-align:center;align-items:center;background-color:var(--textinput-background-color-base);border:none;border-radius:var(--border-radius-xs);box-shadow:0 0 0 var(--border-width-hairline) var(--textinput-border-color-empty);color:var(--textinput-color-font);display:inline-flex;position:relative;width:100%;z-index:var(--z-index-1-default,1);}
      .olx-text-input__input-container:hover{box-shadow:0 0 0 var(--border-width-thin) var(--textinput-border-color-empty-hover);}
      .olx-text-input__input-container--medium{border-radius:var(--border-radius-sm);}
      .olx-text-input__input-field{background-color:inherit;border:none;border-radius:var(--border-radius-xs);color:var(--color-neutral-130);font-family:var(--font-family);font-size:var(--font-size-xxs);font-weight:var(--font-weight-regular);outline:none;padding:var(--spacing-0-5) var(--spacing-1);position:relative;width:100%;}
      .olx-text-input__input-field--medium{border-radius:var(--border-radius-sm);font-size:var(--font-size-xs);line-height:var(--font-lineheight-distant);padding:var(--spacing-1-5) var(--spacing-2);}
      .olx-text-input__input-field::placeholder{color:var(--textinput-color-placeholder);}
      .olx-container{background-color:var(--container-background-color);border-radius:var(--border-radius-sm);overflow:hidden;padding:var(--spacing-2);}
      .olx-container--outlined{border:var(--border-width-hairline) solid var(--container-border-color-outlined);}
      .olx-divider{background-color:var(--divider-default-background-color);border:none;height:1px;margin:0px;}
      .olx-visually-hidden{clip:rect(1px, 1px, 1px, 1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-visually-hidden:focus{clip:auto;height:auto;overflow:auto;position:absolute;width:auto;}
      .olx-image-carousel{height:100%;padding:0px;position:relative;width:100%;}
      .olx-image-carousel > span{height:24px;left:8px;max-width:calc(100% - 16px);position:absolute;top:8px;z-index:var(--z-index-100-masked);}
      .olx-image-carousel span{display:block;text-overflow:ellipsis;}
      @media screen and (min-width: 566px){
      .olx-image-carousel > span{left:16px;top:16px;}
      }
      .olx-image-carousel__items{-webkit-box-align:center;align-items:center;display:flex;height:100%;-webkit-box-pack:start;justify-content:flex-start;margin:0px;overflow:scroll hidden;padding:0px;scroll-snap-type:x mandatory;scrollbar-width:none;}
      .olx-image-carousel__items::-webkit-scrollbar{display:none;}
      .olx-image-carousel__item{-webkit-box-align:center;align-items:center;display:flex;height:100%;-webkit-box-pack:center;justify-content:center;list-style:none;margin:0px;min-width:100%;overflow:hidden;padding:0px;position:relative;scroll-snap-align:start;scroll-snap-stop:always;}
      .olx-image-carousel__item *{height:100%;width:100%;}
      .olx-image-carousel__item img,.olx-image-carousel__item picture{display:block;object-fit:cover;}
      .olx-image-carousel__counter-wrapper{bottom:6px;position:absolute;right:8px;}
      .olx-ad-card{background:var(--color-neutral-70);border:1px solid var(--color-neutral-90);border-radius:var(--border-radius-sm);cursor:pointer;position:relative;transition:box-shadow var(--transition-duration-2) var(--transition-timing-ease);}
      .olx-ad-card picture img{transition:scale var(--transition-duration-5) var(--transition-timing-ease);}
      .olx-ad-card:hover{box-shadow:var(--shadow-level-6);}
      .olx-ad-card:hover picture img{scale:1.1;}
      .olx-ad-card--vertical{display:flex;flex-direction:column;max-width:400px;min-height:100%;min-width:180px;width:100%;}
      .olx-ad-card--vertical .olx-image-carousel{border-bottom:0px;border-top-left-radius:var(--border-radius-sm);border-top-right-radius:var(--border-radius-sm);height:180px;overflow:hidden;width:100%;}
      .olx-ad-card__link-wrapper{display:block;height:100%;outline:none;position:absolute;top:0px;width:100%;z-index:var(--z-index-1-default);}
      .olx-ad-card__link-wrapper:focus{border-radius:var(--border-radius-sm);outline:var(--border-width-hairline) solid var(--color-neutral-130);outline-offset:var(--border-width-hairline);}
      .olx-ad-card__content{border-radius:var(--border-radius-sm);display:flex;flex-direction:column;padding:var(--spacing-2);}
      .olx-ad-card__content--vertical{--carousel-height:180px;gap:var(--spacing-2);height:calc(100% - var(--carousel-height));}
      .olx-ad-card__top{display:flex;flex-direction:column;height:100%;width:100%;}
      @media screen and (min-width: 566px){
      .olx-ad-card__top{flex-direction:row;gap:var(--spacing-2);}
      }
      .olx-ad-card__top--vertical{flex-direction:column-reverse;gap:var(--spacing-2);-webkit-box-pack:end;justify-content:flex-end;}
      .olx-ad-card__title{-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box;font-size:14px;font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:normal;}
      .olx-ad-card__title--vertical{-webkit-line-clamp:2;--two-lines-height:37px;height:var(--two-lines-height);}
      .olx-ad-card__title-link{color:inherit;text-decoration:none;}
      .olx-ad-card__badges-items{display:flex;margin-right:0px;margin-bottom:0px;margin-left:0px;margin-top:var(--spacing-1);overflow:hidden;padding:0px;position:relative;}
      .olx-ad-card__badges-item{list-style:none;}
      .olx-ad-card__badges-item + .olx-ad-card__badges-item{padding-left:var(--spacing-1);}
      .olx-ad-card__badges-item > span{display:flex;white-space:nowrap;}
      .olx-ad-card__old-price{color:var(--color-neutral-100);text-decoration-line:line-through;width:max-content;}
      .olx-ad-card__price{width:max-content;}
      .olx-ad-card__details-ads{display:flex;flex-direction:column;}
      .olx-ad-card__bottom{-webkit-box-align:center;align-items:center;display:flex;-webkit-box-pack:justify;justify-content:space-between;width:100%;}
      .olx-ad-card__bottom-content{display:flex;flex-direction:column;overflow:hidden;}
      .olx-ad-card__location{-webkit-box-align:center;align-items:center;display:flex;flex-direction:row;gap:var(--spacing-0-5);margin-right:var(--spacing-6);padding:0px;}
      .olx-ad-card__location--vertical{align-items:flex-start;flex-direction:column;}
      .olx-ad-card__location svg{color:var(--color-neutral-120);min-width:16px;}
      .olx-ad-card__location p{color:var(--color-neutral-120);line-height:normal;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .olx-ad-card__location-date-container{align-items:flex-start;display:flex;gap:var(--spacing-0-5);width:100%;}
      .olx-alertbox{--background-color:var(--color-neutral-80);--color:var(--color-neutral-130);--svg-color:var(--color-neutral-120);background-color:var(--background-color);border-radius:var(--border-radius-sm);color:var(--color);display:flex;flex-direction:column;font-family:var(--font-family);padding:var(--spacing-2);}
      .olx-alertbox svg{color:var(--svg-color);}
      .olx-alertbox__content-wrapper{display:flex;}
      .olx-alertbox__icon-wrapper{height:24px;width:24px;}
      .olx-alertbox__content{display:flex;flex-direction:column;margin-left:var(--spacing-2);}
      .olx-alertbox__description{display:inline;font-size:var(--font-size-xxs);font-weight:var(--font-weight-regular);}
      @media screen and (min-width: 840px){
      .olx-alertbox__description{font-size:var(--font-size-xs);}
      }
      .olx-alertbox__title{-webkit-box-align:center;align-items:center;display:flex;font-size:var(--font-size-xxs);font-weight:var(--font-weight-semibold);line-height:24px;word-break:break-word;}
      @media screen and (min-width: 840px){
      .olx-alertbox__title{font-size:var(--font-size-xs);}
      }
      .olx-badge{-webkit-box-align:center;align-items:center;background:var(--badge-background-color);color:var(--badge-color);display:inline-flex;font-family:var(--font-family);font-weight:var(--font-weight-semibold);overflow:hidden;white-space:nowrap;}
      .olx-badge:not(.olx-badge--no-gap){column-gap:var(--spacing-1);}
      .olx-badge--small{border-radius:var(--border-radius-xs);font-size:var(--font-size-xxxs);}
      .olx-badge--small{padding:var(--spacing-0-5) var(--spacing-1);}
      .olx-badge--success{--badge-background-color:var(--color-feedback-success-80);--badge-color:var(--color-feedback-success-120);}
      .olx-badge--info{--badge-background-color:var(--color-feedback-info-80);--badge-color:var(--color-feedback-info-110);}
      .olx-badge svg{max-height:16px;max-width:16px;}
      .olx-autocomplete{position:relative;}
      .olx-carousel{position:relative;}
      .olx-carousel__viewport{overflow:hidden;}
      .olx-carousel__content{display:flex;}
      .olx-carousel__next{right:-24px;}
      .olx-carousel__next{-webkit-box-align:center;align-items:center;background-color:transparent;border:0px;border-radius:var(--border-radius-circle);color:var(--carousel-arrow-color);cursor:pointer;display:flex;height:48px;-webkit-box-pack:center;justify-content:center;outline:0px;padding:var(--spacing-0-5);position:absolute;top:50%;transform:translateY(-50%);width:48px;z-index:var(--z-index-300-sticky,300);}
      .olx-carousel__next:hover span{background-color:var(--carousel-arrow-background-color-hover);}
      .olx-carousel__next--hide-on-mobile{display:none;}
      @media screen and (min-width: 840px){
      .olx-carousel__next--hide-on-mobile{display:flex;}
      }
      .olx-carousel__arrow-icon{-webkit-box-align:center;align-items:center;background-color:var(--carousel-arrow-background-color-base);border-radius:var(--border-radius-circle);box-shadow:var(--shadow-level-2);}
      .olx-carousel__arrow-icon,.olx-modal{display:flex;height:100%;-webkit-box-pack:center;justify-content:center;width:100%;}
      .olx-modal{align-items:flex-end;background-color:rgba(0, 0, 0, 0.333);border:0px;opacity:0;pointer-events:none;position:fixed;right:0px;top:0px;transition:opacity var(--transition-timing-ease) var(--transition-duration-3);visibility:hidden;will-change:transform;z-index:var(--z-index-900-modal,900);}
      @media screen and (min-width: 840px){
      .olx-modal{-webkit-box-align:center;align-items:center;}
      }
      .olx-modal__dialog{background-color:var(--modal-background-color);border-bottom-left-radius:0px;border-bottom-right-radius:0px;display:flex;flex-direction:column;max-height:var(--modal-max-height);max-width:100%;min-height:200px;opacity:0;padding:var(--spacing-3) var(--spacing-4);position:relative;transform:translateY(100%) scale(0.9);transition:all var(--transition-timing-ease) var(--transition-duration-3);width:100%;}
      @media screen and (min-width: 840px){
      .olx-modal__dialog{border-radius:var(--border-radius-md);max-width:var(--modal-max-width);transform:translateY(10%) scale(0.9);}
      }
      .olx-modal__content{background-color:var(--color-neutral-70);display:flex;flex-direction:column;height:100%;overflow:hidden auto;}
      .olx-modal__content::-webkit-scrollbar{width:10px;}
      .olx-modal__content::-webkit-scrollbar-track{background:var(--color-neutral-80);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb{background:var(--color-neutral-90);border-radius:var(--border-radius-md);}
      .olx-modal__content::-webkit-scrollbar-thumb:hover{background:var(--color-neutral-110);}
      .olx-modal__close-button{-webkit-box-align:center;align-items:center;align-self:flex-end;background-color:transparent;border:none;border-radius:var(--border-radius-pill);color:var(--modal-button-color);cursor:pointer;display:flex;height:48px;-webkit-box-pack:center;justify-content:center;min-height:48px;width:48px;}
      .olx-modal__close-button:hover{background-color:var(--modal-button-background-color-hover);}
      .olx-logo-olx{min-height:12px;min-width:12px;width:100%;}
      .olx-logo-olx--o{fill:var(--color-secondary-100);}
      .olx-logo-olx--l{fill:var(--color-feedback-success-90);}
      .olx-logo-olx--x{fill:var(--color-primary-100);}
      .olx-default-footer{border-top:1px solid var(--divider-default-background-color);padding:var(--spacing-2) var(--spacing-2) var(--spacing-8);}
      @media screen and (min-width: 840px){
      .olx-default-footer{padding:var(--spacing-2) var(--spacing-4) var(--spacing-3);}
      }
      @media screen and (min-width: 1200px){
      .olx-default-footer{padding:var(--spacing-2) var(--spacing-9) var(--spacing-3);}
      }
      @media screen and (min-width: 1720px){
      .olx-default-footer{display:grid;grid-template-columns:1576px;-webkit-box-pack:center;justify-content:center;}
      }
      .olx-default-footer__links-container{flex-direction:column;gap:var(--spacing-2);padding-bottom:var(--spacing-2);}
      @media screen and (min-width: 840px){
      .olx-default-footer__links-container{flex-direction:row;gap:var(--spacing-4);}
      }
      .olx-static-footer__links-container{display:flex;flex-direction:column;gap:var(--spacing-3);padding-top:var(--spacing-2);}
      @media screen and (min-width: 1200px){
      .olx-static-footer__links-container{display:grid;grid-template-columns:1fr auto;}
      }
      .olx-static-footer__legal-container,.olx-static-footer__legal-container-links{display:flex;flex-direction:column;-webkit-box-pack:center;justify-content:center;row-gap:var(--spacing-1-5);}
      @media screen and (min-width: 840px){
      .olx-static-footer__legal-container-links{column-gap:var(--spacing-2);flex-direction:row;-webkit-box-pack:start;justify-content:flex-start;}
      }
      .olx-static-footer__social-container{display:grid;gap:var(--spacing-1);grid-template-columns:repeat(3, 48px);grid-template-rows:repeat(2, 48px);-webkit-box-pack:center;justify-content:center;}
      @media screen and (min-width: 600px){
      .olx-static-footer__social-container{grid-template-columns:repeat(6, 48px);grid-template-rows:48px;}
      }
      @media screen and (min-width: 1200px){
      .olx-static-footer__social-container{-webkit-box-pack:end;justify-content:flex-end;}
      }
      .olx-static-footer__legal-container-address{display:block;text-align:center;}
      @media screen and (min-width: 840px){
      .olx-static-footer__legal-container-address{text-align:left;}
      }
      .olx-static-footer__icon-wrapper{-webkit-box-align:center;align-items:center;display:inline-flex;height:48px;-webkit-box-pack:center;justify-content:center;width:48px;}
      .olx-static-footer__social-link{border-radius:100%;padding:var(--spacing-1);transition:all 0.3s ease 0s;}
      .olx-static-footer__social-link:active svg,.olx-static-footer__social-link:hover svg{color:var(--color-neutral-70);}
      .olx-static-footer__facebook-link:active,.olx-static-footer__facebook-link:hover{background-color:rgb(58, 89, 152);}
      .olx-static-footer__youtube-link:active,.olx-static-footer__youtube-link:hover{background-color:red;}
      .olx-static-footer__tiktok-link:active,.olx-static-footer__tiktok-link:hover{background-color:rgb(4, 0, 0);}
      .olx-static-footer__linkedin-link:active,.olx-static-footer__linkedin-link:hover{background-color:rgb(0, 132, 191);}
      .olx-static-footer__instagram-link:active,.olx-static-footer__instagram-link:hover{background-color:rgb(225, 48, 108);}
      .olx-static-footer__twitter-link:active,.olx-static-footer__twitter-link:hover{background-color:rgb(4, 0, 0);}
      .olx-header{display:flex;flex-direction:column;font-family:var(--font-family);-webkit-box-pack:center;justify-content:center;position:relative;z-index:var(--z-index-400-header,400);}
      .olx-header__skip-links{clip:rect(1px, 1px, 1px, 1px);height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-header__skip-links:focus{clip:auto;background-color:var(--color-neutral-70);box-shadow:0 0 0 2px var(--color-neutral-70);color:var(--color-neutral-130);display:inline-block;height:50px;left:0px;outline:var(--border-width-thin) solid var(--color-neutral-130);overflow:initial;top:50%;transform:translateY(-50%);transition:none 0s ease 0s;white-space:normal;width:60px;z-index:2;}
      .olx-header__main-menu{background-color:var(--color-neutral-70);border-bottom:1px solid var(--color-neutral-90);display:flex;flex-direction:column;-webkit-box-pack:center;justify-content:center;min-height:80px;padding:var(--spacing-2) var(--spacing-2);transition:transform var(--transition-duration-5) var(--transition-timing-ease-in-out);}
      @media screen and (min-width: 840px){
      .olx-header__main-menu{padding:var(--spacing-2) var(--spacing-4);}
      }
      @media screen and (min-width: 1200px){
      .olx-header__main-menu{padding:var(--spacing-2) var(--spacing-9);}
      }
      .olx-header__items{-webkit-box-align:center;align-items:center;display:flex;margin:0px;padding:0px;}
      @media screen and (min-width: 1200px){
      .olx-header__items{column-gap:var(--spacing-2);}
      }
      @media screen and (min-width: 1500px){
      .olx-header__items{column-gap:var(--spacing-3);}
      }
      .olx-header__icon-button{-webkit-box-align:center;align-items:center;background-color:transparent;border:none;color:var(--color-neutral-130);cursor:pointer;display:flex;height:48px;-webkit-box-pack:center;justify-content:center;margin:0px;outline:none;padding:0px;width:48px;}
      .olx-header__icon-button :hover{color:var(--link-color-main-hover);}
      .olx-header__icon-button :focus{border-radius:var(--border-radius-xxs);outline:var(--border-width-thin) solid var(--color-neutral-130);}
      .olx-header__item{-webkit-box-align:center;align-items:center;display:flex;list-style:none;}
      .olx-header__item[data-variant="anunciar"]{margin-left:var(--spacing-1-5);}
      @media screen and (max-width: 1200px){
      .olx-header__item[data-myads="true"],.olx-header__item[data-professional="true"]{display:none;}
      }
      @media screen and (min-width: 1200px){
      .olx-header__item[data-variant="anunciar"]{margin-left:0px;}
      }
      .olx-header__link{column-gap:var(--spacing-1);}
      @media screen and (max-width: 1200px){
      .olx-header__link{padding:12px;}
      }
      .olx-header__link:hover{text-decoration:none;}
      .olx-header__primary-menu{display:flex;flex-direction:row;-webkit-box-pack:justify;justify-content:space-between;margin:0px auto;max-width:1576px;width:100%;}
      .olx-header__burger-menu{height:48px;-webkit-box-pack:start;justify-content:flex-start;width:48px;}
      .olx-header__burger-menu:focus{border-radius:var(--border-radius-xxs);outline:var(--color-neutral-130) solid var(--border-width-thin);}
      @media screen and (max-width: 360px){
      .olx-header__burger-menu{height:44px;width:44px;}
      }
      @media screen and (min-width: 840px){
      .olx-header__burger-menu{display:none;}
      }
      .olx-header__column-left{-webkit-box-align:center;align-items:center;display:flex;flex:1 1 0%;position:relative;}
      .olx-header__column-right{display:flex;transition:all var(--transition-duration-5) var(--transition-timing-ease);}
      .olx-header__olx-container{-webkit-box-align:center;align-items:center;color:var(--color-neutral-130);column-gap:32px;display:flex;font-size:var(--font-size-xxs);height:48px;width:48px;}
      .olx-header__logo-wrapper{height:24px;width:24px;}
      @media screen and (max-width: 1200px){
      .olx-header__label{clip:rect(1px, 1px, 1px, 1px);display:flex;height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      .olx-header__label[data-variant="chat"],.olx-header__label[data-variant="notification"]{clip:auto;display:initial;height:auto;overflow:initial;position:static;white-space:normal;width:auto;}
      }
      @media screen and (max-width: 840px){
      .olx-header__label[data-variant="chat"],.olx-header__label[data-variant="notification"]{clip:rect(1px, 1px, 1px, 1px);display:flex;height:1px;overflow:hidden;position:absolute;white-space:nowrap;width:1px;}
      }
      .olx-header__desapegar-button{font-size:var(--font-size-xxs);}
      @media screen and (max-width: 840px){
      .olx-header__desapegar-button{height:36px;padding:var(--spacing-1) var(--spacing-2);}
      }
      .olx-header__profile-item{-webkit-box-align:center;align-items:center;display:flex;list-style:none;}
      .olx-header__profile-link{-webkit-box-align:center;align-items:center;background-color:transparent;border:1px solid var(--color-neutral-90);border-radius:var(--border-radius-pill);color:var(--color-neutral-130);cursor:pointer;display:flex;font-family:var(--font-family);font-size:var(--font-size-xxs);font-weight:var(--font-weight-semibold);height:40px;-webkit-box-pack:center;justify-content:center;line-height:var(--font-lineheight-medium);padding:var(--spacing-0-5);transition:all ease var(--transition-duration-3);width:135px;}
      .olx-header__profile-link:hover{border-color:var(--color-secondary-100);color:var(--link-color-main-hover);text-decoration:none;}
      .olx-header__profile-link:focus{border-radius:var(--border-radius-pill);box-shadow:none;outline:var(--border-width-thin) solid var(--color-neutral-130);}
      @media screen and (max-width: 840px){
      .olx-header__profile-link{display:none;}
      }
      .olx-header__search{margin-left:var(--spacing-3);margin-right:var(--spacing-1-5);width:100%;}
      @media screen and (min-width: 840px){
      .olx-header__search{margin-right:var(--spacing-3);}
      }
      @media screen and (max-width: 840px){
      .olx-header__search[data-hasnavbar="false"],.olx-header__search[data-hasnavbar="false"] .olx-text-input__input-field{display:none;}
      }
      .olx-header__search-fluid{padding-left:var(--spacing-3);padding-right:var(--spacing-3);padding-top:var(--spacing-2);width:100%;}
      @media screen and (min-width: 840px){
      .olx-header__search-fluid,.olx-header__search-fluid .olx-text-input__input-field{display:none;}
      }
      @media screen and (max-width: 840px){
      .olx-header__search-fluid{padding-left:0px;padding-right:0px;}
      }
      .olx-header__overlay{background:var(--color-neutral-130);height:calc(-100% + 100svh);left:0px;opacity:0;pointer-events:none;position:absolute;top:100%;transition:opacity 1s ease 0s;width:100%;}
      @media screen and (min-width: 840px){
      .olx-header__overlay{display:none;}
      }
      .olx-header__overflow{background-color:var(--color-neutral-70);box-shadow:var(--shadow-level-2);height:0px;list-style:none;opacity:0;padding-bottom:2px;padding-top:2px;pointer-events:none;position:absolute;scroll-behavior:smooth;top:64px;transition:transform ease var(--transition-duration-3),opacity ease var(--transition-duration-3);width:280px;z-index:var(--z-index-700-overlay);}
      @media screen and (min-width: 840px){
      .olx-header__overflow{border-radius:var(--border-radius-sm);}
      .olx-header__overflow[data-islogged="false"]{display:none;}
      }
      @media screen and (max-width: 840px){
      .olx-header__overflow:not([data-hasnavbar="true"]){border-radius:0px;height:calc(-100% + 100svh);left:0px;overflow:hidden;padding-bottom:50px;top:100%;transform:translateX(-100%);}
      }
      .olx-header__overflow-item[data-divider="true"]{border-bottom:1px solid var(--color-neutral-90);margin-bottom:var(--spacing-0-5);}
      .olx-header__overflow-link{color:var(--color-neutral-130);column-gap:16px;cursor:pointer;display:inline-flex;font-size:var(--font-size-xxs);-webkit-box-pack:start;justify-content:flex-start;padding:var(--spacing-2);position:relative;text-decoration:none;transition:all ease var(--transition-duration-3);width:100%;}
      .olx-header__overflow-link:hover{background:var(--color-neutral-80);text-decoration:none;}
      .olx-header__overflow-link:focus{transform:scale(0.98);}
      .olx-color-primary-100{color:white}
      .olx-color-secondary-100{color:var(--color-secondary-100);}
      .olx-color-neutral-70{color:var(--color-neutral-70);}
      .olx-color-neutral-100{color:var(--color-neutral-100);}
      .olx-color-neutral-120{color:var(--color-neutral-120);}
      .olx-color-feedback-success-120{color:var(--color-feedback-success-120);}
      .olx-d-flex{display:flex;}
      .olx-ai-flex-start{align-items:flex-start;}
      .olx-ai-center{-webkit-box-align:center;align-items:center;}
      .olx-fd-row{flex-direction:row;}
      .olx-fd-column{flex-direction:column;}
      .olx-fd-column-reverse{flex-direction:column-reverse;}
      .olx-jc-flex-start{-webkit-box-pack:start;justify-content:flex-start;}
      .olx-jc-center{-webkit-box-pack:center;justify-content:center;}
      .olx-jc-space-between{-webkit-box-pack:justify;justify-content:space-between;}
      .olx-ml-0-5{margin-left:var(--spacing-0-5);}
      .olx-ml-1{margin-left:var(--spacing-1);}
      .olx-ml-2{margin-left:var(--spacing-2);}
      .olx-mr-2{margin-right:var(--spacing-2);}
      .olx-mt-1{margin-top:var(--spacing-1);}
      .olx-mt-2{margin-top:var(--spacing-2);}
      .olx-mt-3{margin-top:var(--spacing-3);}
      .olx-mb-2{margin-bottom:var(--spacing-2);}
      .olx-mb-3{margin-bottom:var(--spacing-3);}
      .olx-mb-4{margin-bottom:var(--spacing-4);}
      .olx-pl-1{padding-left:var(--spacing-1);}
      .olx-pr-1{padding-right:var(--spacing-1);}
      .olx-pt-6{padding-top:var(--spacing-6);}
      .olx-pb-4{padding-bottom:var(--spacing-4);}
      .olx-mb-stack-quarck{margin-bottom:var(--spacing-stack-quarck);}
      .ajfs2S{-webkit-box-align:center;align-items:center;background:transparent;border:none;border-radius:var(--border-radius-lg);cursor:pointer;display:flex;height:44px;-webkit-box-pack:center;justify-content:center;outline:none;position:absolute;right:4px;top:50%;transform:translateY(-50%);transition:var(--transition-duration-2);width:44px;z-index:var(--z-index-1-default);}
      .ajfs2S svg{color:var(--color-neutral-130);}
      .ajfs2S:active,.ajfs2S:hover{background:var(--color-neutral-90);}
      .ajfs2S:focus{outline:var(--color-secondary-100) solid var(--border-width-thin);}
      ._2dsuYh{-webkit-box-align:center;align-items:center;display:flex;height:32px;-webkit-box-pack:center;justify-content:center;width:32px;}
      .S6FMF5{height:48px;margin:0px;position:relative;}
      .S6FMF5 input{padding-right:var(--spacing-6);}
      .rec-gallery-galleries,.rec-gallery-gallery{display:flex;flex-direction:column;}
      .rec-gallery-gallery + .rec-gallery-gallery{margin-top:var(--spacing-6);}
      .rec-gallery-carousel__viewport{margin-left:calc(var(--spacing-1)*-1);padding-left:var(--spacing-0-25);}
      .rec-gallery-carousel__slide{flex:0 0 240px;min-width:0px;padding-left:var(--spacing-2);position:relative;}
      @media screen and (min-width: 840px){
      .rec-gallery-carousel__slide{flex:0 0 25%;}
      }
      @media screen and (min-width: 1200px){
      .rec-gallery-carousel__slide{flex:0 0 20%;}
      }
      @media screen and (min-width: 1500px){
      .rec-gallery-carousel__slide{flex:0 0 16.66%;}
      }
      .rec-gallery-carousel__slide[data-reduced="true"]{flex:0 0 240px;}
      .rec-gallery-adcard{height:396px;}
      .rec-gallery-title__wrapper{display:flex;-webkit-box-pack:justify;justify-content:space-between;margin-bottom:var(--spacing-3);width:100%;}
      .dggish{flex-direction:row;-webkit-box-align:center;align-items:center;-webkit-box-pack:justify;justify-content:space-between;margin-bottom:var(--spacing-1);}
      @media (min-width: 52.5em){
      .dggish{max-width:330px;}
      }
      .dRVOMM{display:flex;flex-direction:column;}
      .eIrngG{text-decoration:underline;}
      @media (min-width: 52.5em){
      .liXIVx{width:330px;}
      }
      .JPPzB{z-index:1;position:absolute;top:0px;right:0px;height:48px;width:56px;background-color:transparent;display:flex;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;align-items:center;}
      @media (min-width: 52.5em){
      .JPPzB{height:40px;}
      }
      .jpvXFy{position:relative;width:100%;}
      @media (min-width: 52.5em){
      .jpvXFy{width:unset;}
      }
      .iylYKg{display:flex;}
      @media (min-width: 52.5em){
      .iylYKg{display:none;}
      }
      .jzHSCO{display:none;flex-direction:row;-webkit-box-pack:start;justify-content:flex-start;-webkit-box-align:center;align-items:center;}
      @media (min-width: 52.5em){
      .jzHSCO{display:flex;}
      }
      .emZFka{margin:0px;}
      @media (min-width: 52.5em){
      .leAFmU{height:277.594px;}
      }
      .dNnIOE{display:flex;margin-top:var(--spacing-1);gap:var(--spacing-1);}
      .jxzxsG{display:flex;flex-direction:row;gap:var(--spacing-1);margin-top:var(--spacing-3);}
      .fRPkcW{display:flex;flex-direction:row;gap:var(--spacing-1);}
      .iAjmOH{border:1px solid rgb(229, 229, 229);border-radius:8px;padding:16px 16px 8px;background-color:rgb(249, 249, 249);}
      .eqAese{margin-bottom:8px;}
      .bkeCVY{display:flex;margin-bottom:16px;}
      .iPanMd{display:flex;-webkit-box-pack:center;justify-content:center;}
      .eiDnJG{margin-right:8px;}
      .mgOeD{display:flex;-webkit-box-pack:start;justify-content:flex-start;-webkit-box-align:center;align-items:center;}
      .gHOHKj{display:flex;-webkit-box-pack:end;justify-content:flex-end;-webkit-box-align:center;align-items:center;}
      .fldqIs{display:flex;flex-direction:column;align-items:flex-start;}
      .dmVzsi{display:flex;flex-direction:row;align-items:flex-start;}
      .eUuwVa{display:flex;cursor:pointer;}
      .jwSNhR{display:flex;margin-right:8px;-webkit-box-align:center;align-items:center;}
      .iUJOli{margin-top:var(--spacing-0-5);padding:var(--spacing-0-5) 0;}
      .cVKnwm{margin-top:0px;padding:var(--spacing-0-5) 0;}
      .bcmKlD{margin-bottom:var(--spacing-2);min-height:96px;}
      @media (max-width: 480px){
      .bcmKlD{margin:0px auto;}
      }
      .AerSA{overflow-y:auto;gap:var(--spacing-2);}
      .bLAmFD{margin:0px;display:flex;flex-direction:column;gap:var(--spacing-0-5);}
      .cLuAeg{display:flex;gap:var(--spacing-1);}
      .kasWSD{display:flex;flex-direction:column;background-color:var(--color-secondary-lightest);padding:var(--spacing-stack-xxxs);gap:var(--spacing-stack-xxs);border-radius:var(--border-radius-sm);}
      .gNDsRI{display:flex;}
      .cCkxId{display:flex;flex-direction:column;}
      .fWQvnR{padding:0px;text-align:left;font-size:13px;}
      .kSFdbo{margin-right:var(--spacing-inline-nano);}
      .hRKSON{display:grid;gap:var(--spacing-2);grid-template-columns:64px 1fr;-webkit-box-align:center;align-items:center;}
      .iKOnDg{display:flex;flex-direction:column;gap:var(--spacing-2);}
      @media (max-width: 480px){
      .iKOnDg{padding-bottom:64px;}
      }
      .vlJew{display:flex;gap:var(--spacing-stack-nano);flex-wrap:wrap;}
      .UbaFz{margin-top:var(--spacing-2);}
      .hoHpcC{font-weight:var(--font-weight-regular);font-size:var(--font-size-xxl);}
      @media (min-width: 52.5em){
      .hoHpcC{font-size:var(--font-size-lg);}
      }
      .iFeCCh{text-decoration:line-through;}
      @media (min-width: 52.5em){
      .iFeCCh{font-size:var(--font-size-xxs);}
      }
      .bVPwgc{background-color:transparent;}
      @media (min-width: 52.5em){
      .bVPwgc{flex-direction:column-reverse;padding-bottom:0px;}
      }
      .iKICED{flex-direction:column;}
      @media (min-width: 52.5em){
      .iKICED{flex-direction:row;-webkit-box-align:center;align-items:center;}
      }
      .ibUBVa{margin:0px;}
      .fBIVnd{border-top-right-radius:8px;border-bottom-right-radius:8px;padding:10px 0px 10px 8px;background-color:var(--color-secondary-100);flex:1 1 0%;}
      .dnbBJL{font-weight:var(--font-weight-regular);line-height:44px;}
      @media (min-width: 52.5em){
      .dnbBJL{margin-right:var(--spacing-0-5);}
      }
      @media (min-width: 79.5em){
      .dnbBJL{margin-right:var(--spacing-1);}
      }
      @media (min-width: 52.5em){
      .kkAwSq{flex-direction:row;-webkit-box-align:center;align-items:center;-webkit-box-pack:start;justify-content:flex-start;}
      }
      .dLCxtV{margin-block:0px;display:-webkit-box}
      .focuCb{white-space:pre-line;}
      .fMgwdS{word-break:break-word;}
      .lfYRqx{width:50%;}
      @media (min-width: 45em){
      .lfYRqx{padding-left:0px;width:100%;font-size:var(--font-size-xxs);color:var(--color-neutral-120);}
      }
      .cpGpXB{box-sizing:border-box;padding-left:16px;width:50%;}
      .cpGpXB::before{display:none;}
      @media (min-width: 45em){
      .cpGpXB{padding-left:0px;width:100%;}
      }
      .hakxne{padding-left:var(--spacing-2);outline:none;width:50%;}
      @media (min-width: 45em){
      .hakxne{padding-left:0px;width:100%;}
      }
      .efnZpq{flex-direction:row;}
      @media (min-width: 45em){
      .efnZpq{flex-direction:column;}
      }
      .jQLBWs{margin-bottom:var(--spacing-0-5);display:flex;}
      @media (min-width: 1em) and (max-width: 52.4375em){
      .jQLBWs{display:block;order:1;width:100%;margin:var(--spacing-1) 0 0 0;}
      }
      .kClAQl{display:flex;flex-direction:column;margin-right:var(--spacing-1);-webkit-box-align:baseline;align-items:baseline;}
      .dsBvGq{margin-right:4px;margin-left:-2px;}
      .gQpQiy{flex-wrap:wrap;margin-bottom:-16px;}
      .jmFfeO{height:24px;}
      .bKbctQ{display:flex;flex-direction:column;}
      .bKCVhH{margin-right:4px;margin-left:4px;}
      .dWayMW{font-size:var(--font-size-xs);}
      @media (min-width: 52.5em){
      .dWayMW{font-size:var(--font-size-xxxs);}
      }
      .hjLLUR{font-size:var(--font-size-xs);}
      @media (min-width: 52.5em){
      .hjLLUR{font-size:var(--font-size-xxxs);}
      }
      .IoqnP{position:relative;width:100%;display:flex;flex-direction:row;-webkit-box-pack:justify;justify-content:space-between;}
      @media (min-width: 839px){
      .IoqnP{flex-direction:row;-webkit-box-pack:justify;justify-content:space-between;width:auto;}
      }
      .dfQibb{border:none;background-color:transparent;padding:0px;height:auto;min-width:16px;margin-left:4px;margin-right:4px;}
      .dfQibb:hover{background-color:transparent;}
      .dfQibb:focus{box-shadow:0 0 0 var(--border-width-thick) var(--button-primary-color-outline);}
      .kxFGLZ{height:50px;position:fixed;top:-60px;left:0px;width:100vw;text-align:center;z-index:10;transition:all 0.3s ease 0s;}
      .kVvckl{max-width:100%;max-height:35px;}
      .ccAPWz{background-color:var(--color-neutral-80);padding-top:0px;overflow:hidden;}
      .djeeke{display:block;}
      @media (min-width: 116.82em){
      .djeeke{display:block;vertical-align:top;}
      }
      @media (min-width: 116.82em){
      .GYHge{display:flex;-webkit-box-pack:center;justify-content:center;}
      }
      .brSEGL{display:none;}
      @media (min-width: 116.82em){
      .brSEGL{display:block;vertical-align:top;min-width:300px;}
      }
      .fZtGUy{padding:0px 4px;}
      @media (min-width: 52.5em){
      .fZtGUy{font-size:var(--font-size-xxxs);line-height:var(--font-lineheight-supertight);}
      }
      .OtLeB{text-align:center;flex:1 1 0%;margin-left:calc(var(--spacing-2) * -1);margin-right:calc(var(--spacing-2) * -1);}
      @media (min-width: 45em){
      .OtLeB{margin-left:calc(var(--spacing-3) * -1);margin-right:calc(var(--spacing-3) * -1);}
      }
      @media (min-width: 52.5em){
      .OtLeB{margin-left:0px;margin-right:0px;}
      }
      .eXhSEm{min-width:100%;max-height:280px;background-color:var(--color-neutral-90);position:relative;font-size:0px;vertical-align:middle;}
      .fTdpFj{white-space:nowrap;overflow:scroll hidden;transform:translateZ(0px);scroll-snap-type:x mandatory;transition:all 100ms ease-out 0s;min-height:280px;}
      .fTdpFj::-webkit-scrollbar{display:none;width:0px!important;}
      .eygyzf{display:inline-block;vertical-align:middle;text-align:center;width:100%;max-height:280px;scroll-snap-align:center none;}
      .eygyzf img{max-width:100%;max-height:280px;margin:0px auto;}
      .hVWGzL{inset:auto auto 16px 50%;transform:translateX(-50%);border-radius:var(--spacing-0-5);padding:5px 10px;position:absolute;z-index:0;opacity:0.3;}
      .hVWGzL *{opacity:0.3;}
      .bcZaJY{position:absolute;top:50%;transform:translateY(-50%);padding:0px;left:0px;}
      .cNBrzd{position:absolute;top:50%;transform:translateY(-50%);padding:0px;right:0px;}
      .cNBrzd svg{filter:drop-shadow(rgb(180, 180, 180) 0px 1px 0px);}
      .hGbNNN{position:absolute;bottom:0px;z-index:2;right:0px;}
      .hKoyyV{user-select:none;position:relative;}
      .kiJqwC{text-align:center;flex:1 1 0%;margin-left:calc(var(--spacing-2) * -1);margin-right:calc(var(--spacing-2) * -1);}
      @media (min-width: 45em){
      .kiJqwC{margin-left:calc(var(--spacing-3) * -1);margin-right:calc(var(--spacing-3) * -1);}
      }
      @media (min-width: 52.5em){
      .kiJqwC{margin-left:0px;margin-right:0px;}
      }
      .gMavrr{min-width:100%;max-height:402px;background-color:var(--color-neutral-90);position:relative;font-size:0px;vertical-align:middle;border-radius:var(--spacing-1);overflow:hidden;}
      .gKdhrF{white-space:nowrap;overflow:hidden;transform:translateZ(0px);transition:all 100ms ease-out 0s;scroll-behavior:smooth;min-height:402px;border-radius:var(--spacing-1);}
      .dTEHeu{display:inline-block;vertical-align:middle;text-align:center;overflow:hidden;width:100%;max-height:402px;background-color:var(--color-neutral-100);}
      .dTEHeu .image{width:100%;max-height:402px;object-fit:contain;user-select:none;position:absolute;bottom:50%;right:50%;transform:translate(50%, 50%);}
      .bsAwfV{position:absolute;top:50%;transform:translateY(-50%);left:var(--spacing-2);}
      .cpdQZT{position:absolute;top:50%;transform:translateY(-50%);right:var(--spacing-2);}
      .cewxen{cursor:pointer;width:var(--spacing-5);height:var(--spacing-5);border-radius:50%;box-shadow:rgba(0, 0, 0, 0.2) 0px 2px 4px -1px, rgba(0, 0, 0, 0.12) 0px 1px 10px 0px, rgba(0, 0, 0, 0.14) 0px 4px 5px 0px;background-color:var(--color-neutral-70);}
      .cewxen:hover{background-color:var(--color-neutral-100);}
      .kPuCIR{position:relative;user-select:none;}
      .draTbt{display:flex;list-style:none;flex-direction:column;margin-top:0px;margin-right:0px;margin-bottom:0px;padding:0px;margin-left:var(--spacing-1);height:402px;overflow:hidden;transition:all 450ms ease-out 0s;scroll-behavior:smooth;}
      .dgkhgU{position:relative;line-height:0;padding:0 0 var(--spacing-1);}
      .dgkhgU:last-child{padding-bottom:0px;}
      .jlljou{height:var(--spacing-7);width:var(--spacing-7);border-radius:var(--spacing-0-5);overflow:hidden;position:relative;will-change:opacity;cursor:pointer;transition:all 0.2s ease-in-out 0s;opacity:1;}
      .jrVMaH{height:var(--spacing-7);width:var(--spacing-7);border-radius:var(--spacing-0-5);overflow:hidden;position:relative;will-change:opacity;cursor:pointer;transition:all 0.2s ease-in-out 0s;opacity:0.64;}
      .fOBLLY{position:absolute;left:50%;top:50%;transform:translate(-50%, -50%);border-radius:var(--spacing-0-);height:100%;width:100%;object-fit:cover;z-index:2;}
      .hWeNGQ{position:absolute;left:50%;transform:translateX(-50%);padding:0px;width:100%;text-align:center;top:0px;}
      .cSPhVH{position:absolute;left:50%;transform:translateX(-50%);padding:0px;width:100%;text-align:center;bottom:0px;}
      .gFvSWv{background-color:var(--color-neutral-70);cursor:pointer;line-height:0;}
      .csPpVM {
    background: none !important; /* Remove a mancha */
    filter: none !important; /* Remove o efeito de desfoque */
    position: relative !important; /* Evita sobreposição */
    width: auto !important;
    height: auto !important;
}
      .ckuAUr{background-image:url("https://img.olx.com.br/images/16/160405404436999.webp");background-repeat:no-repeat;background-size:cover;background-position:50% center;filter:blur(32px);position:fixed;height:120%;width:120%;transform:translate(-32px, -32px);}
      .kWJeEr{background-image:url("https://img.olx.com.br/images/16/160419403685325.webp");background-repeat:no-repeat;background-size:cover;background-position:50% center;filter:blur(32px);position:fixed;height:120%;width:120%;transform:translate(-32px, -32px);}
      .gtcngu{background-image:url("https://img.olx.com.br/images/16/162455285827844.webp");background-repeat:no-repeat;background-size:cover;background-position:50% center;filter:blur(32px);position:fixed;height:120%;width:120%;transform:translate(-32px, -32px);}
      .iJFeIe{background-image:url("https://img.olx.com.br/images/16/167419408967814.webp");background-repeat:no-repeat;background-size:cover;background-position:50% center;filter:blur(32px);position:fixed;height:120%;width:120%;transform:translate(-32px, -32px);}
      .kGMhQw{background-image:url("https://img.olx.com.br/images/16/165480047250131.webp");background-repeat:no-repeat;background-size:cover;background-position:50% center;filter:blur(32px);position:fixed;height:120%;width:120%;transform:translate(-32px, -32px);}
      .PQyCd{position:absolute;bottom:0px;z-index:2;right:64px;}
      .bixIoU{background-color:var(--color-neutral-100);width:100%;height:100%;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;align-items:center;text-align:start;}
      .kAPCkC{background-color:var(--color-neutral-70);padding:var(--spacing-1);flex-direction:column;-webkit-box-pack:center;justify-content:center;align-items:flex-start;height:100%;width:100%;max-width:238px;overflow-wrap:break-word;white-space:normal;display:inline-flex;}
      @media (min-width: 600px){
      .kAPCkC{max-width:364px;}
      }
      @media (min-width: 1272px){
      .kAPCkC{max-width:480px;}
      }
      .cmFKIN{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .iwtnNi{box-sizing:border-box;}
      .lkSSmZ{font-size:12px;font-weight:500;color:rgb(153, 153, 153);}
      .cHkaSl{margin-left:8px;position:relative;}
      .lhCjWO{margin-left:8px;position:relative;}
      .hBtBBb{margin-left:8px;position:relative;}
      .iLxMDK{position:relative;display:flex;-webkit-box-align:center;align-items:center;flex-direction:row;}
      .cijItJ{font-size:14px;color:rgb(74, 74, 74);}
      .cuZcdS{text-align:center;font-weight:600;font-size:20px;color:rgb(50, 50, 50);line-height:24px!important;}
      .fltvGW{font-size:12px;font-weight:500;color:rgb(153, 153, 153);display:flex;-webkit-box-pack:center;justify-content:center;}
      .TiUli{position:relative;display:flex;-webkit-box-align:center;align-items:center;}
      .ezXDmb{position:relative;display:flex;-webkit-box-align:center;align-items:center;flex-direction:row;}
      .iMovUU{display:inline-flex;margin-right:8px;}
      .kQoCjl{display:flex;flex-direction:column;}
      .kpaSEP{display:flex;margin-top:4px;margin-bottom:12px;}
      .gBjgVF{margin-bottom:8px;display:flex;}
      .chGUhu{display:flex;-webkit-box-pack:center;justify-content:center;margin-bottom:4px;margin-top:8px;width:100%;}
      .bVXVQs{text-overflow:ellipsis;overflow:hidden;}
      .kCHSFM{display:flex;-webkit-box-pack:center;justify-content:center;margin-bottom:8px;}
      .kJGzkt{display:flex;flex-direction:column;width:100%;}
      .cOBNwA{border-bottom:1px solid rgb(234, 234, 234);width:220px;margin-bottom:16px;margin-top:8px;}
      .fcDieZ{background-color:rgb(249, 249, 249);border:1px solid rgb(216, 216, 216);border-radius:4px;padding:16px 0px;display:flex;flex-direction:column;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;align-items:center;}
      .ZIkpr{display:flex;flex-direction:column;}
      .gmYOGU{margin-bottom:12px;}
      .lkUxIJ{margin-bottom:4px;}
      .bzASAM{display:flex;-webkit-box-align:center;align-items:center;margin-left:6px;}
      .cLiAaO{display:inline-flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;height:auto;border-radius:24px;align-self:flex-start;flex-basis:auto;white-space:nowrap;cursor:pointer;box-shadow:rgba(74, 74, 74, 0.2) 0px 3px 5px 0px;background-color:var(--color-primary-100);color:rgb(255, 255, 255);padding:12px;-webkit-tap-highlight-color:transparent;user-select:none;}
      @media (min-width: 52.5em){
      .cLiAaO{box-shadow:none;}
      }
      @media (min-width: 52.5em){
      .cLiAaO{padding:var(--spacing-1) var(--spacing-2);}
      }
      .cLiAaO:active{transition:all 0.1s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;transform:scale(0.96);background-color:rgb(227, 118, 0);}
      .cLiAaO:not(:active){transition:all 0.1s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;}
      @media (min-width: 52.5em){
      .cLiAaO:hover{transition:all 0.2s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;background-color:rgb(227, 118, 0);}
      .cLiAaO:not(:hover){transition:all 0.2s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;}
      }
      .khBCdw{display:inline-flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;height:auto;border-radius:24px;align-self:flex-start;flex-basis:auto;white-space:nowrap;cursor:pointer;box-shadow:rgba(74, 74, 74, 0.2) 0px 3px 5px 0px;background-color:#10CE64;border:var(--border-width-hairline) solid #10CE64;color:white;padding:11px;-webkit-tap-highlight-color:transparent;user-select:none;}
      @media (min-width: 52.5em){
      .khBCdw{box-shadow:none;}
      }
      @media (min-width: 52.5em){
      .khBCdw{padding:7px 15px;}
      }
      .khBCdw:active{transition:all 0.1s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;transform:scale(0.96);background-color:rgb(255, 225, 191);}
      .khBCdw:not(:active){transition:all 0.1s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;}
      @media (min-width: 52.5em){
      .khBCdw:hover{transition:all 0.2s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;background-color:rgb(255, 225, 191);}
      .khBCdw:not(:hover){transition:all 0.2s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;}
      }
      .kHCjiu{width:12px;}
      @media (min-width: 52.5em){
      .kHCjiu{width:var(--spacing-1);}
      }
      .brGTsG{margin-right:8px;}
      @media (min-width: 52.5em){
      .brGTsG{margin-right:0px;}
      }
      .lfjgSl{background-color:transparent;gap:var(--spacing-1);}
      .grIXNP{height:40px;background-color:var(--color-neutral-80);box-shadow:var(--color-neutral-90) 0px -1px 3px 0px;}
      .bpUaRp{text-overflow:ellipsis;max-width:50%;overflow:hidden;white-space:nowrap;}
      .shnO{position:relative;}
      @media (min-width: 1em) and (max-width: 52.4375em){
      .shnO{position:fixed;bottom:0px;left:0px;right:0px;z-index:4;}
      }
      .imJiRw{padding:var(--spacing-1);border:solid var(--border-width-hairline) var(--color-neutral-100);border-radius:var(--border-radius-xs);}
      .kBAeeE{line-height:var(--font-lineheight-supertight);height:14px;}
      .hEMZqE{padding:var(--spacing-4) var(--spacing-2);display:flex;margin-right:var(--spacing-2);margin-left:var(--spacing-2);border-radius:var(--border-radius-sm);border:1px solid var(--color-neutral-100);background-color:var(--color-neutral-80);}
      .fUlPzh{position:relative;margin-bottom:32px;}
      .fUlPzh .carousel.carousel-slider{overflow:initial;}
      .fUlPzh .carousel .slide{background-color:initial;}
      .fUlPzh .carousel .control-dots{padding-inline-start:0px;bottom:-32px;}
      .fUlPzh .carousel .control-dots .dot{box-shadow:none;background:var(--color-neutral-130);}
      .fUlPzh .carousel .control-dots .dot.selected,.fUlPzh .carousel .control-dots .dot:hover{background:var(--color-secondary-100);}
      .carousel{position:relative;width:100%;}
      .carousel *{box-sizing:border-box;}
      .carousel.carousel-slider{position:relative;margin:0px;overflow:hidden;}
      .carousel .slider-wrapper{overflow:hidden;margin:auto;width:100%;transition:height 0.15s ease-in 0s;}
      .carousel .slider-wrapper.axis-horizontal .slider{display:flex;}
      .carousel .slider-wrapper.axis-horizontal .slider .slide{flex-flow:column;}
      .carousel .slider{margin:0px;padding:0px;position:relative;list-style:none;width:100%;}
      .carousel .slider.animated{transition:all 0.35s ease-in-out 0s;}
      .carousel .slide{min-width:100%;margin:0px;position:relative;text-align:center;background:rgb(0, 0, 0);}
      .carousel .control-dots{position:absolute;bottom:0px;margin:10px 0px;text-align:center;width:100%;}
      @media (min-width: 960px){
      .carousel .control-dots{bottom:0px;}
      }
      .carousel .control-dots .dot{transition:opacity 0.25s ease-in 0s;opacity:0.3;box-shadow:rgba(0, 0, 0, 0.9) 1px 1px 2px;background:rgb(255, 255, 255);border-radius:50%;width:8px;height:8px;cursor:pointer;display:inline-block;margin:0px 8px;}
      .carousel .control-dots .dot.selected,.carousel .control-dots .dot:hover{opacity:1;}
      .bUfxEj{margin-left:-16px;margin-right:-16px;}
      .dOMSbE{height:8px;}
      .bIWRYE{cursor:pointer;margin-left:-18px;}
      .cTaiLm{-webkit-line-clamp:2;overflow:hidden;-webkit-box-orient:vertical;display:-webkit-inline-box;}
      .jEQdXP{border-radius:var(--border-radius-sm);border:solid var(--border-width-hairline) var(--color-neutral-90);padding:var(--spacing-2) var(--spacing-3);background-color:var(--color-neutral-80);}
      .dnuXGn{border-radius:50%;background-color:var(--color-neutral-80);padding:10px;}
      @media (min-width: 52.5em){
      .dnuXGn{padding:var(--spacing-1);}
      }
      .igTPsH{color:var(--color-neutral-130);height:20px;width:20px;}
      @media (min-width: 52.5em){
      .igTPsH{height:16px;width:16px;}
      }
      .bruiFy{margin-left:var(--spacing-1);}
      @media (min-width: 52.5em){
      .bruiFy{margin-left:12px;}
      }
      .ccFvpT{background-color:var(--color-neutral-80);border:none;padding:var(--spacing-2);position:relative;}
      .hqZrfZ{border-radius:2px;background-color:var(--color-neutral-80);height:32px;width:32px;transform:rotate(45deg) translate(20px, -10px);margin-bottom:-24px;}
      .ixznNN{display:block;width:100%;}
      @media (min-width: 52.5em){
      .ixznNN{display:none;}
      }
      .jHHMfv{cursor:pointer;color:var(--color-secondary-100);font-weight:var(--font-weight-semibold);font-size:var(--font-size-xxs);outline:none;}
      .jHHMfv:focus{box-shadow:0 0 0 2px var(--color-secondary-80);border-radius:var(--border-radius-xxs);}
      .liCkqS{margin-top:var(--spacing-1);}
      .dCywhT{display:inline;}
      @media (min-width: 52.5em){
      .dCywhT{font-size:var(--font-size-xxs);}
      }
      .fSnvRW{font-weight:var(--font-weight-bold);color:var(--color-feedback-success-100);}
      @media (min-width: 52.5em){
      .fSnvRW{font-size:var(--font-size-xxs);}
      }
      .DXPmK .ds-drawer{width:100%;outline:none;position:fixed;top:0px;bottom:0px;z-index:100;transform:translateY(9999px);}
      @media (min-width: 52.5em){
      .DXPmK .ds-drawer{display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;flex-direction:column;inset:0px;}
      }
      .DXPmK .ds-drawer .ds-drawer-mask{opacity:0;width:100%;height:100%;position:absolute;top:0px;left:0px;background-color:rgb(0, 0, 0);}
      .DXPmK .ds-drawer .ds-drawer-content-wrapper{width:100%;max-height:calc(-16px + 100vh);position:absolute;top:auto;bottom:0px;overflow:hidden;display:flex;flex-direction:column;border-radius:16px 16px 0px 0px;background-color:var(--color-neutral-70);}
      @media (min-width: 52.5em){
      .DXPmK .ds-drawer .ds-drawer-content-wrapper{border-radius:8px;box-shadow:rgba(0, 0, 0, 0.22) 0px 4px 24px, rgba(0, 0, 0, 0.2) 0px 24px 24px;}
      }
      @media (min-width: 52.5em){
      .DXPmK .ds-drawer .ds-drawer-content-wrapper{height:auto;width:600px;max-height:80vh;inset:auto;}
      @media only screen and (min-height: 200px){
      .DXPmK .ds-drawer .ds-drawer-content-wrapper{min-height:200px;}
      }
      }
      .DXPmK .ds-drawer .ds-drawer-element{display:flex;height:100%;}
      .DXPmK .ds-drawer .ds-drawer-content{width:100%;height:100%;z-index:1;position:relative;-webkit-box-flex:1;flex-grow:1;overflow:auto;}
      .DXPmK .ds-drawer{transition:transform 0.25s cubic-bezier(0.42, 0, 1, 1) 0.25s;}
      .DXPmK .ds-drawer .ds-drawer-mask{transition:opacity 0.25s cubic-bezier(0, 0, 0.58, 1) 0s;}
      .DXPmK .ds-drawer .ds-drawer-content-wrapper{transition:transform 0.25s cubic-bezier(0.42, 0, 1, 1) 0s;}
      .DXPmK .ds-drawer .ds-drawer-content{transition:transform 0.25s cubic-bezier(0.42, 0, 1, 1) 0s;}
      .htWpRo .ds-drawer{width:100%;outline:none;position:fixed;top:0px;bottom:0px;z-index:100;transform:translateY(9999px);}
      @media (min-width: 52.5em){
      .htWpRo .ds-drawer{display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;flex-direction:column;inset:0px;}
      }
      .htWpRo .ds-drawer .ds-drawer-mask{opacity:0;width:100%;height:100%;position:absolute;top:0px;left:0px;background-color:rgb(0, 0, 0);}
      .htWpRo .ds-drawer .ds-drawer-content-wrapper{width:100%;max-height:calc(-16px + 100vh);position:absolute;top:auto;bottom:0px;overflow:hidden;display:flex;flex-direction:column;border-radius:16px 16px 0px 0px;background-color:var(--color-neutral-70);}
      @media (min-width: 52.5em){
      .htWpRo .ds-drawer .ds-drawer-content-wrapper{border-radius:8px;box-shadow:rgba(0, 0, 0, 0.22) 0px 4px 24px, rgba(0, 0, 0, 0.2) 0px 24px 24px;}
      }
      @media (min-width: 52.5em){
      .htWpRo .ds-drawer .ds-drawer-content-wrapper{height:auto;width:800px;max-height:80vh;inset:auto;}
      @media only screen and (min-height: 200px){
      .htWpRo .ds-drawer .ds-drawer-content-wrapper{min-height:200px;}
      }
      }
      .htWpRo .ds-drawer .ds-drawer-element{display:flex;height:100%;}
      .htWpRo .ds-drawer .ds-drawer-content{width:100%;height:100%;z-index:1;position:relative;-webkit-box-flex:1;flex-grow:1;overflow:auto;}
      .htWpRo .ds-drawer{transition:transform 0.25s cubic-bezier(0.42, 0, 1, 1) 0.25s;}
      .htWpRo .ds-drawer .ds-drawer-mask{transition:opacity 0.25s cubic-bezier(0, 0, 0.58, 1) 0s;}
      .htWpRo .ds-drawer .ds-drawer-content-wrapper{transition:transform 0.25s cubic-bezier(0.42, 0, 1, 1) 0s;}
      .htWpRo .ds-drawer .ds-drawer-content{transition:transform 0.25s cubic-bezier(0.42, 0, 1, 1) 0s;}
      .bwrWbg{align-self:flex-end;padding-bottom:var(--spacing-2);}
      @media (min-width: 52.5em){
      .bwrWbg{padding-bottom:var(--spacing-1);}
      }
      .fIeUxH{background-color:var(--color-neutral-70);position:sticky;top:0px;padding:var(--spacing-3) 0;}
      @media (min-width: 52.5em){
      .fIeUxH{padding-top:var(--spacing-4);}
      }
      .gDAxRz{display:flex;flex:1 1 0%;flex-direction:column;}
      .kuLCig{cursor:pointer;}
      .bxegPI{display:flex;flex:1 1 0%;flex-direction:column;min-height:189px;padding:0 var(--spacing-3) var(--spacing-3) var(--spacing-3);}
      @media (min-width: 52.5em){
      .bxegPI{min-height:auto;padding-top:0px;}
      }
      .fZvZjF{display:flex;flex:1 1 0%;}
      @media (min-width: 52.5em){
      .fZvZjF{padding-bottom:var(--spacing-2);}
      }
      .lfCyKC{width:100%;min-height:48px;padding:8px;border-radius:4px;-webkit-box-align:center;align-items:center;-webkit-box-pack:justify;justify-content:space-between;}
      .hMxsdK{width:100%;-webkit-box-align:center;align-items:center;flex-direction:column;}
      .byfXzK{-webkit-box-pack:justify;flex-direction:column;width:100%;}
      @media (min-width: 52.5em){
      .bFqvpB{margin-bottom:8px;}
      }
      .krAlvT{cursor:pointer;border-width:0px;padding:4px 8px;font-family:"Nunito Sans";font-size:12px;line-height:16px;color:var(--color-neutral-70);background-color:var(--color-secondary-100);border-radius:4px;text-transform:uppercase;position:absolute;bottom:16px;right:16px;height:auto;min-width:auto;}
      .krAlvT:focus{outline:none;}
      .krAlvT:hover{background-color:var(--color-secondary-100);}
      .giMena{display:none;}
      @media (min-width: 71.19em){
      .giMena{display:block;}
      }
      .glvOvk{border-radius:50%;background-color:var(--color-neutral-80);width:40px;height:40px;}
      .kySTeR{overflow:hidden;}
      .bklcRt{margin-left:8px;white-space:nowrap;max-width:200px;text-align:right;display:inline;}
      @media (min-width: 52.5em){
      .bklcRt{font-size:var(--font-size-xs);}
      }
      .joFrXy{margin-left:8px;white-space:nowrap;max-width:200px;text-align:right;display:inline;font-weight:var(--font-weight-bold);color:var(--color-feedback-success-100);}
      @media (min-width: 52.5em){
      .joFrXy{font-size:var(--font-size-xs);}
      }
      .exRDe{text-overflow:ellipsis;overflow:hidden;white-space:nowrap;}
      @media (min-width: 52.5em){
      .exRDe{font-size:var(--font-size-xs);}
      }
      .hlhAKE{text-overflow:ellipsis;overflow:hidden;white-space:nowrap;}
      @media (min-width: 52.5em){
      .hlhAKE{font-size:var(--font-size-xxs);}
      }
      .bLkPBq{width:100%;margin-left:16px;overflow:hidden;}
      .kOcpyi{width:100%;height:1px;background-color:var(--color-neutral-80);margin:var(--spacing-2) 0;}
      .gGjonz{display:flex;}
      .ekmhza{margin-right:var(--spacing-0-5);text-decoration:line-through;color:var(--color-neutral-100);display:inline;}
      @media (min-width: 52.5em){
      .ekmhza{font-size:var(--font-size-xs);}
      }
      .gDCssy{flex:1 1 0%;}
      .lkXMNS{margin-left:-1rem;}
      @media (min-width: 52.5em){
      .lkXMNS{margin-left:0px;}
      }
      .iSULFY{flex-shrink:1;box-sizing:border-box;flex-wrap:wrap;background-color:transparent;align-content:center;}
      @media (min-width: 1201px){
      .iSULFY{width:1140px;}
      }
      @media (min-width: 701px) and (max-width: 1200px){
      .iSULFY{width:632px;}
      }
      @media (max-width: 701px){
      .iSULFY{width:316px;}
      }
      .lnCrpH{flex-basis:150px;background-color:var(--color-neutral-80);box-sizing:border-box;margin-bottom:var(--spacing-1);margin-right:var(--spacing-1);}
      .hLpjwU{background-color:var(--color-neutral-80);padding:0 var(--spacing-2);}
      .hcmLgx{-webkit-box-flex:0;flex-grow:0;background-color:transparent;width:100%;}
      .giadtl{text-align:left;-webkit-line-clamp:2;overflow:hidden;-webkit-box-orient:vertical;display:-webkit-inline-box;font-size:var(--font-size-xxxs);}
      .faOAuq{display:flex;flex-direction:column;}
      .gRffJZ{margin-top:var(--spacing-3);margin-bottom:var(--spacing-2);}
      .bOqIXI{margin-top:-34px;}
      .jdyRVD{position:relative;z-index:0;}
      .jHiBXE{position:relative;z-index:300;}
      .dNsour{background-color:var(--color-neutral-80);margin-left:-1rem;margin-right:-1rem;padding-top:32px;-webkit-box-pack:center;justify-content:center;}
      @media (min-width: 52.5em){
      .dNsour{background-color:transparent;padding-top:0px;margin-left:0px;margin-right:0px;justify-content:left;}
      }
      .hplqOl{display:flex;}
      .eoZZuW{display:block;margin:0px;padding:0px;font-family:var(--font-family);word-break:break-word;color:var(--text-color);font-weight:var(--font-weight-regular);line-height:var(--font-lineheight-distant);font-size:var(--font-size-xxs);font-style:normal;}
      .fxfeXq{display:block;margin-right:0px;margin-bottom:0px;margin-left:0px;padding:0px;font-family:var(--font-family);word-break:break-word;color:var(--text-color);font-weight:var(--font-weight-semibold);line-height:var(--font-lineheight-superdistant);font-size:var(--font-size-xs);font-style:normal;margin-top:var(--font-size-xxxs);}
      .fDNJHX{display:block;margin:0px;padding:0px;font-style:normal;font-family:var(--font-family);word-break:break-word;color:var(--text-color);font-weight:var(--font-weight-regular);line-height:var(--font-lineheight-medium);font-size:var(--font-size-xxxs);}
      .isGkDG{margin-top:var(--spacing-2);justify-content:center;align-items:center;background:var(--color-neutral-80);border:1px solid var(--color-neutral-90);border-radius:var(--spacing-0-5);}
      .culsWI{max-width:328px;max-height:217px;padding:12px;background:var(--color-neutral-80);}
      .fEPFJw{display:flex;flex-grow:1;flex-shrink:1;width:82px;height:128px;flex-direction:column;justify-content:center;align-items:center;text-align:center;border-right-width:var(--border-width-hairline);border-right-style:solid;border-right-color:var(--color-neutral-100);}
      .dAarSr{display:flex;flex-grow:1;flex-shrink:1;width:82px;height:128px;flex-direction:column;justify-content:center;align-items:center;text-align:center;}
      .jemGPt{display:flex;flex-wrap:wrap;justify-content:center;place-items:center;margin-bottom:var(--spacing-2);}
      .erd_scroll_detection_container > div::-webkit-scrollbar{display:none;}
      .erd_scroll_detection_container_animation_active{-webkit-animation-duration:0.1s;animation-duration:0.1s;-webkit-animation-name:erd_scroll_detection_container_animation;animation-name:erd_scroll_detection_container_animation;}
      .iwtnNi{box-sizing:border-box;}
      @-webkit-keyframes erd_scroll_detection_container_animation{0%{opacity:1;}50%{opacity:0;}100%{opacity:1;}}
      @keyframes erd_scroll_detection_container_animation{0%{opacity:1;}50%{opacity:0;}100%{opacity:1;}}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tCKQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tCKQ.woff2) format('woff2');unicode-range:U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tCKQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tCKQ.woff2) format('woff2');unicode-range:U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-s.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tCKQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tCKQ.woff2) format('woff2');unicode-range:U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tCKQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tCKQ.woff2) format('woff2');unicode-range:U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-s.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tCKQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tCKQ.woff2) format('woff2');unicode-range:U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tCKQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tCKQ.woff2) format('woff2');unicode-range:U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-s.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tCKQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tCKQ.woff2) format('woff2');unicode-range:U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tCKQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tCKQ.woff2) format('woff2');unicode-range:U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-s.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tCKQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tCKQ.woff2) format('woff2');unicode-range:U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tCKQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tCKQ.woff2) format('woff2');unicode-range:U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:300;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-s.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tCKQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tCKQ.woff2) format('woff2');unicode-range:U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tCKQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tCKQ.woff2) format('woff2');unicode-range:U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:400;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-s.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tCKQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tCKQ.woff2) format('woff2');unicode-range:U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tCKQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tCKQ.woff2) format('woff2');unicode-range:U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:600;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-s.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t4R-tCKQ.woff2) format('woff2');unicode-range:U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7txR-tCKQ.woff2) format('woff2');unicode-range:U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t6R-tCKQ.woff2) format('woff2');unicode-range:U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t7R-tCKQ.woff2) format('woff2');unicode-range:U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;}
      @font-face{font-family:'Nunito Sans';font-style:normal;font-weight:700;font-stretch:100%;font-display:swap;src:url(https://fonts.gstatic.com/s/nunitosans/v15/pe0TMImSLYBIv1o4X1M8ce2xCx3yop4tQpF_MeTm0lfGWVpNn64CL7U8upHZIbMV51Q42ptCp7t1R-s.woff2) format('woff2');unicode-range:U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}
    </style>
    <link rel="stylesheet" href="./index_files/tobii.min.css">
    <style>/*! CSS Used from: https://static.olx.com.br/design-system/olx-reset.min.css */
      *,*::before,*::after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:'Nunito Sans','Helvetica Neue',Helvetica,Arial,sans-serif;font-display:swap;-webkit-font-smoothing:antialiased;}
      img{max-width:100%;display:block;}
      @media (prefers-reduced-motion:reduce){
      *,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important;}
      }
      /*! CSS Used from: Embedded */
      *,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:currentColor;}
      :before,:after{--tw-content:"";}
      :disabled{cursor:default;}
      img{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,:before,:after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      /*! CSS Used from: Embedded */
      *,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:currentColor;}
      :before,:after{--tw-content:"";}
      :disabled{cursor:default;}
      img{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,:before,:after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      /*! CSS Used from: Embedded */
      *,::before,::after{box-sizing:border-box;border-width:0px;border-style:solid;border-color:currentcolor;}
      ::before,::after{--tw-content:"";}
      :disabled{cursor:default;}
      img{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,::before,::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      *,::before,::after{box-sizing:border-box;border-width:0px;border-style:solid;border-color:currentcolor;}
      ::before,::after{--tw-content:"";}
      :disabled{cursor:default;}
      img{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,::before,::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      *,::before,::after{box-sizing:border-box;border-width:0px;border-style:solid;border-color:currentcolor;}
      ::before,::after{--tw-content:"";}
      :disabled{cursor:default;}
      img{display:block;vertical-align:middle;}
      img{max-width:100%;height:auto;}
      *,::before,::after{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scroll-snap-strictness:proximity;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgb(59 130 246 / .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;}
      .kaNiaQ{color:rgb(74, 74, 74);line-height:24px;font-size:16px;font-weight:600;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .fWUyFm{color:rgb(74, 74, 74);line-height:16px;font-size:12px;font-weight:400;font-family:"Nunito Sans", "Helvetica Neue", HelveticaNeue, Helvetica, Arial, sans-serif;margin:0px;}
      .gblpgD{width:100%;display:flex;place-items:center;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;flex-direction:row;margin:10px 0px 8px;cursor:pointer;}
      .hOEjgl{display:flex;flex-direction:row;}
      .eIahbx{width:15px;height:14px;margin-right:4px;}
      .hBeJQt{font-size:16px;font-weight:400;line-height:24px;}
    </style>
    <link rel="stylesheet" href="./index_files/swiper-bundle.min.css">
  </head>
  <body style="" cz-shortcut-listen="true" class="">
    <a href="https://www.youtube.com/embed/0JfyoIHW1tM?autoplay=1" data-type="iframe" data-group="iframe-youtube" data-width="1120px" data-height="630px" id="openVideo" class="lightbox" style="display: none;"></a>
    <div id="root">
      <div id="adview" class="ad__sc-qp0wh1-2 jdyRVD">
        <div class="ad__sc-h3us20-2 vKKEq">
          <div></div>
        </div>
        <div class="ad__sc-qp0wh1-3 jHiBXE">
          <header id="header" data-ds-component="DS-Header" class="olx-header" data-open="false" data-fixed="false">
            <nav class="olx-header__main-menu" aria-label="Menu principal">
              <div class="olx-header__primary-menu">
                <div class="olx-header__column-left">
                  <div><a data-ds-component="DS-Header-Link" class="olx-link olx-link--caption olx-link--main olx-header__skip-links" href="https://olx.comprasegurasx.com.br/produto/5GBkLNJZ#header" data-header-keyboard-navigation="true">Ir para o menu principal</a><a data-ds-component="DS-Header-Link" class="olx-link olx-link--caption olx-link--main olx-header__skip-links" href="https://olx.comprasegurasx.com.br/produto/5GBkLNJZ#main" data-header-keyboard-navigation="true">Ir para o conteúdo da página</a><a data-ds-component="DS-Header-Link" class="olx-link olx-link--caption olx-link--main olx-header__skip-links" href="https://olx.comprasegurasx.com.br/produto/5GBkLNJZ#footer" data-header-keyboard-navigation="true">Ir para o rodapé</a></div>
                  <button data-ds-component="DS-Header-Button" class="olx-header__icon-button olx-header__burger-menu" aria-controls="ds-overflow-menu" aria-expanded="false" data-header-keyboard-navigation="true" data-header-burger-menu="true">
                    <span class="olx-header__logo-wrapper">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" fill-rule="evenodd" d="M3,12.75 C2.58578644,12.75 2.25,12.4142136 2.25,12 C2.25,11.5857864 2.58578644,11.25 3,11.25 L21,11.25 C21.4142136,11.25 21.75,11.5857864 21.75,12 C21.75,12.4142136 21.4142136,12.75 21,12.75 L3,12.75 Z M3,6.75 C2.58578644,6.75 2.25,6.41421356 2.25,6 C2.25,5.58578644 2.58578644,5.25 3,5.25 L21,5.25 C21.4142136,5.25 21.75,5.58578644 21.75,6 C21.75,6.41421356 21.4142136,6.75 21,6.75 L3,6.75 Z M3,18.75 C2.58578644,18.75 2.25,18.4142136 2.25,18 C2.25,17.5857864 2.58578644,17.25 3,17.25 L21,17.25 C21.4142136,17.25 21.75,17.5857864 21.75,18 C21.75,18.4142136 21.4142136,18.75 21,18.75 L3,18.75 Z"></path>
                      </svg>
                    </span>
                    <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Menu</span>
                  </button>
                  <a data-ds-component="DS-Header-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/" data-header-keyboard-navigation="true">
                    <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Página inicial</span>
                    <span class="olx-header__olx-container">
                      <svg data-ds-component="DS-Header-LogoOLX" viewBox="0 0 40 40" class="olx-logo-olx" aria-hidden="true">
                        <g fill="none" fill-rule="evenodd">
                          <path class="olx-logo-olx--o" d="M7.579 26.294c-2.282 0-3.855-1.89-3.855-4.683 0-2.82 1.573-4.709 3.855-4.709 2.28 0 3.855 1.889 3.855 4.682 0 2.82-1.574 4.71-3.855 4.71m0 3.538c4.222 0 7.578-3.512 7.578-8.248 0-4.682-3.173-8.22-7.578-8.22C3.357 13.363 0 16.874 0 21.61c0 4.763 3.173 8.221 7.579 8.221"></path>
                          <path class="olx-logo-olx--l" d="M18.278 23.553h7.237c.499 0 .787-.292.787-.798V20.44c0-.505-.288-.798-.787-.798h-4.851V9.798c0-.505-.288-.798-.787-.798h-2.386c-.498 0-.787.293-.787.798v12.159c0 1.038.551 1.596 1.574 1.596"></path>
                          <path class="olx-logo-olx--x" d="M28.112 29.593l4.353-5.082 4.222 5.082c.367.452.839.452 1.258.08l1.705-1.517c.42-.373.472-.851.079-1.277l-4.694-5.321 4.274-4.869c.367-.426.34-.878-.078-1.277l-1.6-1.463c-.42-.4-.892-.373-1.259.08l-3.907 4.602-3.986-4.603c-.367-.425-.84-.479-1.259-.08l-1.652 1.49c-.42.4-.446.825-.053 1.278l4.354 4.868-4.747 5.348c-.393.452-.34.905.079 1.277l1.652 1.464c.42.372.891.345 1.259-.08"></path>
                        </g>
                      </svg>
                    </span>
                  </a>
                  <div data-hasnavbar="false" class="olx-header__search">
                    <form class="S6FMF5" data-variant="primary" data-hidesuggestions="true">
                      <div data-ds-component="DS-Autocomplete" class="olx-autocomplete">
                        <div class="combobox-wrapper">
                          <div id="oraculo-157-combobox" data-testid="oraculo-157-combobox">
                            <div data-ds-component="DS-TextInput" class="olx-text-input"><span class="olx-text-input__input-container olx-text-input__input-container--medium"><input id="oraculo-157-input" type="text" aria-label="Autocomplete" class="olx-text-input__input-field olx-text-input__input-field--medium" aria-autocomplete="both" placeholder="Buscar" role="combobox" aria-controls="autocomplete-list" aria-expanded="false" aria-busy="false" autocomplete="off" spellcheck="false" value=""></span></div>
                          </div>
                        </div>
                      </div>
                      <button class="ajfs2S" data-variant="primary" data-ds-component="Oraculo-Button">
                        <span class="_2dsuYh" data-variant="primary">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                            <path fill="currentColor" fill-rule="evenodd" d="M16.8399523,15.7792921 L21.5303301,20.4696699 C21.8232233,20.7625631 21.8232233,21.2374369 21.5303301,21.5303301 C21.2374369,21.8232233 20.7625631,21.8232233 20.4696699,21.5303301 L15.7792921,16.8399523 C14.3486717,18.0325324 12.5081226,18.75 10.5,18.75 C5.94365081,18.75 2.25,15.0563492 2.25,10.5 C2.25,5.94365081 5.94365081,2.25 10.5,2.25 C15.0563492,2.25 18.75,5.94365081 18.75,10.5 C18.75,12.5081226 18.0325324,14.3486717 16.8399523,15.7792921 L16.8399523,15.7792921 Z M15.3290907,15.2161873 C16.517579,13.9994267 17.25,12.3352464 17.25,10.5 C17.25,6.77207794 14.2279221,3.75 10.5,3.75 C6.77207794,3.75 3.75,6.77207794 3.75,10.5 C3.75,14.2279221 6.77207794,17.25 10.5,17.25 C12.3352464,17.25 13.9994267,16.517579 15.2161873,15.3290907 C15.2327733,15.3085794 15.2506009,15.2887389 15.2696699,15.2696699 C15.2887389,15.2506009 15.3085794,15.2327733 15.3290907,15.2161873 L15.3290907,15.2161873 Z"></path>
                          </svg>
                        </span>
                        <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Buscar</span>
                      </button>
                    </form>
                  </div>
                </div>
                <div class="olx-header__column-right">
                  <ul class="olx-header__items">
                    <li class="olx-header__item" data-professional="true">
                      <a data-ds-component="DS-Header-Link" class="olx-link olx-link--small olx-link--grey olx-header__link" href="https://planoprofissional.olx.com.br/" data-header-keyboard-navigation="true">
                        <span class="olx-header__logo-wrapper">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                            <path fill="currentColor" fill-rule="evenodd" d="M7.25,6.25 L7.25,5 C7.25,3.48121694 8.48121694,2.25 10,2.25 L14,2.25 C15.5187831,2.25 16.75,3.48121694 16.75,5 L16.75,6.25 L20,6.25 C21.5187831,6.25 22.75,7.48121694 22.75,9 L22.75,19 C22.75,20.5187831 21.5187831,21.75 20,21.75 L4,21.75 C2.48121694,21.75 1.25,20.5187831 1.25,19 L1.25,9 C1.25,7.48121694 2.48121694,6.25 4,6.25 L7.25,6.25 Z M8.75,6.25 L15.25,6.25 L15.25,5 C15.25,4.30964406 14.6903559,3.75 14,3.75 L10,3.75 C9.30964406,3.75 8.75,4.30964406 8.75,5 L8.75,6.25 Z M4,7.75 C3.30964406,7.75 2.75,8.30964406 2.75,9 L2.75,19 C2.75,19.6903559 3.30964406,20.25 4,20.25 L20,20.25 C20.6903559,20.25 21.25,19.6903559 21.25,19 L21.25,9 C21.25,8.30964406 20.6903559,7.75 20,7.75 L4,7.75 Z"></path>
                          </svg>
                        </span>
                        <span class="olx-header__label">Plano Profissional</span>
                      </a>
                    </li>
                    <li class="olx-header__item" data-myads="true">
                      <a data-ds-component="DS-Header-Link" class="olx-link olx-link--small olx-link--grey olx-header__link" href="https://conta.olx.com.br/anuncios" data-header-keyboard-navigation="true">
                        <span class="olx-header__logo-wrapper">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                            <path fill="currentColor" fill-rule="evenodd" d="M3,2.25 L10,2.25 C10.4142136,2.25 10.75,2.58578644 10.75,3 L10.75,10 C10.75,10.4142136 10.4142136,10.75 10,10.75 L3,10.75 C2.58578644,10.75 2.25,10.4142136 2.25,10 L2.25,3 C2.25,2.58578644 2.58578644,2.25 3,2.25 Z M3.75,9.25 L9.25,9.25 L9.25,3.75 L3.75,3.75 L3.75,9.25 Z M14,2.25 L21,2.25 C21.4142136,2.25 21.75,2.58578644 21.75,3 L21.75,10 C21.75,10.4142136 21.4142136,10.75 21,10.75 L14,10.75 C13.5857864,10.75 13.25,10.4142136 13.25,10 L13.25,3 C13.25,2.58578644 13.5857864,2.25 14,2.25 Z M14.75,9.25 L20.25,9.25 L20.25,3.75 L14.75,3.75 L14.75,9.25 Z M14,13.25 L21,13.25 C21.4142136,13.25 21.75,13.5857864 21.75,14 L21.75,21 C21.75,21.4142136 21.4142136,21.75 21,21.75 L14,21.75 C13.5857864,21.75 13.25,21.4142136 13.25,21 L13.25,14 C13.25,13.5857864 13.5857864,13.25 14,13.25 Z M14.75,20.25 L20.25,20.25 L20.25,14.75 L14.75,14.75 L14.75,20.25 Z M3,13.25 L10,13.25 C10.4142136,13.25 10.75,13.5857864 10.75,14 L10.75,21 C10.75,21.4142136 10.4142136,21.75 10,21.75 L3,21.75 C2.58578644,21.75 2.25,21.4142136 2.25,21 L2.25,14 C2.25,13.5857864 2.58578644,13.25 3,13.25 Z M3.75,20.25 L9.25,20.25 L9.25,14.75 L3.75,14.75 L3.75,20.25 Z"></path>
                          </svg>
                        </span>
                        <span class="olx-header__label">Meus Anúncios</span>
                      </a>
                    </li>
                    <li class="olx-header__item">
                      <a data-ds-component="DS-Header-Link" class="olx-link olx-link--small olx-link--grey olx-header__link" href="https://conta.olx.com.br/chats" data-header-keyboard-navigation="true">
                        <span class="olx-header__logo-wrapper">
                          <span class="olx-header__notification-wrapper" data-counter="0">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                              <path fill="currentColor" fill-rule="evenodd" d="M20.7708784,15.6353225 C19.2048634,18.7687087 16.003219,20.748673 12.5019554,20.7500259 C11.170068,20.7534985 9.85486501,20.4655356 8.64815212,19.9078805 L3.23717082,21.711541 C2.6508523,21.9069805 2.09304802,21.3491762 2.28848753,20.7628577 L4.09214783,15.3518768 C3.53449285,14.1451723 3.24652977,12.8300832 3.25000006,11.4997383 C3.25135552,7.99680952 5.23131982,4.79516511 8.36185998,3.23057996 C9.64541532,2.58225315 11.063961,2.2462818 12.5,2.24999749 L13.0413141,2.25116725 C17.7388283,2.51032529 21.4897032,6.26120016 21.7500285,11.0000285 L21.7500285,11.4990722 C21.7535911,12.9367242 21.4176256,14.3549096 20.7708784,15.6353225 Z M8.46282918,18.388516 C8.65253857,18.3252795 8.85964607,18.3404222 9.03814002,18.43058 C10.1108155,18.9723909 11.2963033,19.2531643 12.4997098,19.2500285 C15.434596,19.2488929 18.1170549,17.5900039 19.4305515,14.9618885 C19.9723624,13.889213 20.2531358,12.7037252 20.2500025,11.5019839 L20.2511388,11.0413426 C20.0340974,7.10723797 16.8927905,3.96593107 13,3.75 L12.4980446,3.75 C11.2963033,3.74689267 10.1108155,4.02766611 9.03529406,4.57090694 C6.41002461,5.88297361 4.7511356,8.56543244 4.74999745,11.5019839 C4.74686419,12.7037252 5.02763762,13.889213 5.56944852,14.9618885 C5.65960624,15.1403824 5.67474894,15.3474899 5.61151247,15.5371993 L4.18585412,19.8141744 L8.46282918,18.388516 Z"></path>
                            </svg>
                          </span>
                        </span>
                        <span data-variant="chat" class="olx-header__label">Chat</span>
                      </a>
                    </li>
                    <li class="olx-header__item">
                      <a data-ds-component="DS-Header-Link" class="olx-link olx-link--small olx-link--grey olx-header__link" href="https://conta.olx.com.br/notificacoes" data-header-keyboard-navigation="true">
                        <span class="olx-header__logo-wrapper">
                          <span class="olx-header__notification-wrapper" data-counter="0">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                              <path fill="currentColor" fill-rule="evenodd" d="M22,17.75 L2,17.75 C1,17.75 1,16.25 2,16.25 C3.24264069,16.25 4.25,15.2426406 4.25,13.9999999 L4.25,8.99999988 C4.25,4.71979312 7.71979323,1.25 12,1.25 C16.2802068,1.25 19.75,4.71979312 19.75,8.9999999 L19.75,13.9999999 C19.75,15.2426406 20.7573593,16.25 22,16.25 C23,16.25 23,17.75 22,17.75 Z M18.25,13.9999999 L18.25,8.99999991 C18.2499999,5.54822026 15.4517797,2.75 12,2.75 C8.54822035,2.75 5.75000005,5.54822026 5.75,8.9999999 L5.75,13.9999999 C5.75,14.8442043 5.47104138,15.6232545 5.00027464,16.25 L18.9997254,16.25 C18.5289586,15.6232545 18.25,14.8442043 18.25,13.9999999 Z M14.37875,21.3763288 C13.8867781,22.2244348 12.9804693,22.7464562 12,22.7464562 C11.0195307,22.7464562 10.1132219,22.2244348 9.62125,21.3763288 C9.33120937,20.8763304 9.69196714,20.2499999 10.27,20.2499999 L13.73,20.2499999 C14.3080329,20.2499999 14.6687906,20.8763304 14.37875,21.3763288 Z"></path>
                            </svg>
                          </span>
                        </span>
                        <span data-variant="notification" class="olx-header__label">Notificações</span>
                      </a>
                    </li>
                    <li class="olx-header__profile-item">
                      <a data-ds-component="DS-Header-Link" class="olx-link olx-link--caption olx-link--main olx-header__profile-link" href="https://conta.olx.com.br/anuncios" data-header-keyboard-navigation="true">Entrar</a>
                      <div class="olx-header__overlay" data-open="false" data-testid="mobile-overlay-overflow-menu"></div>
                      <ul id="ds-overflow-menu" aria-hidden="true" data-expanded="false" data-fixed="false" data-islogged="false" data-testid="overflow-menu" class="olx-header__overflow">
                        <li data-open="false" class="olx-header__overflow-item" data-testid="overflow-content-lazy">
                          <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main olx-header__overflow-link" href="https://conta.olx.com.br/anuncios" tabindex="-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
                              <path fill="currentColor" fill-rule="evenodd" d="M13.1893398,12.75 L3,12.75 C2.58578644,12.75 2.25,12.4142136 2.25,12 C2.25,11.5857864 2.58578644,11.25 3,11.25 L13.1893398,11.25 L10.4696699,8.53033009 C10.1767767,8.23743687 10.1767767,7.76256313 10.4696699,7.46966991 C10.7625631,7.1767767 11.2374369,7.1767767 11.5303301,7.46966991 L15.5303301,11.4696699 C15.8232233,11.7625631 15.8232233,12.2374369 15.5303301,12.5303301 L11.5303301,16.5303301 C11.2374369,16.8232233 10.7625631,16.8232233 10.4696699,16.5303301 C10.1767767,16.2374369 10.1767767,15.7625631 10.4696699,15.4696699 L13.1893398,12.75 L13.1893398,12.75 Z M14,22.75 C13.5857864,22.75 13.25,22.4142136 13.25,22 C13.25,21.5857864 13.5857864,21.25 14,21.25 L19,21.25 C19.6903559,21.25 20.25,20.6903559 20.25,20 L20.25,4 C20.25,3.30964406 19.6903559,2.75 19,2.75 L14,2.75 C13.5857864,2.75 13.25,2.41421356 13.25,2 C13.25,1.58578644 13.5857864,1.25 14,1.25 L19,1.25 C20.5187831,1.25 21.75,2.48121694 21.75,4 L21.75,20 C21.75,21.5187831 20.5187831,22.75 19,22.75 L14,22.75 Z"></path>
                            </svg>
                            Entrar
                          </a>
                        </li>
                        <li data-open="false" data-divider="true" class="olx-header__overflow-item" data-testid="overflow-content-lazy">
                          <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main olx-header__overflow-link" href="https://conta.olx.com.br/chats" tabindex="-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
                              <path fill="currentColor" fill-rule="evenodd" d="M20.7708784,15.6353225 C19.2048634,18.7687087 16.003219,20.748673 12.5019554,20.7500259 C11.170068,20.7534985 9.85486501,20.4655356 8.64815212,19.9078805 L3.23717082,21.711541 C2.6508523,21.9069805 2.09304802,21.3491762 2.28848753,20.7628577 L4.09214783,15.3518768 C3.53449285,14.1451723 3.24652977,12.8300832 3.25000006,11.4997383 C3.25135552,7.99680952 5.23131982,4.79516511 8.36185998,3.23057996 C9.64541532,2.58225315 11.063961,2.2462818 12.5,2.24999749 L13.0413141,2.25116725 C17.7388283,2.51032529 21.4897032,6.26120016 21.7500285,11.0000285 L21.7500285,11.4990722 C21.7535911,12.9367242 21.4176256,14.3549096 20.7708784,15.6353225 Z M8.46282918,18.388516 C8.65253857,18.3252795 8.85964607,18.3404222 9.03814002,18.43058 C10.1108155,18.9723909 11.2963033,19.2531643 12.4997098,19.2500285 C15.434596,19.2488929 18.1170549,17.5900039 19.4305515,14.9618885 C19.9723624,13.889213 20.2531358,12.7037252 20.2500025,11.5019839 L20.2511388,11.0413426 C20.0340974,7.10723797 16.8927905,3.96593107 13,3.75 L12.4980446,3.75 C11.2963033,3.74689267 10.1108155,4.02766611 9.03529406,4.57090694 C6.41002461,5.88297361 4.7511356,8.56543244 4.74999745,11.5019839 C4.74686419,12.7037252 5.02763762,13.889213 5.56944852,14.9618885 C5.65960624,15.1403824 5.67474894,15.3474899 5.61151247,15.5371993 L4.18585412,19.8141744 L8.46282918,18.388516 Z"></path>
                            </svg>
                            Chat
                          </a>
                        </li>
                        <li data-open="false" class="olx-header__overflow-item" data-testid="overflow-content-lazy">
                          <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main olx-header__overflow-link" href="https://conta.olx.com.br/anuncios" tabindex="-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
                              <path fill="currentColor" fill-rule="evenodd" d="M3,2.25 L10,2.25 C10.4142136,2.25 10.75,2.58578644 10.75,3 L10.75,10 C10.75,10.4142136 10.4142136,10.75 10,10.75 L3,10.75 C2.58578644,10.75 2.25,10.4142136 2.25,10 L2.25,3 C2.25,2.58578644 2.58578644,2.25 3,2.25 Z M3.75,9.25 L9.25,9.25 L9.25,3.75 L3.75,3.75 L3.75,9.25 Z M14,2.25 L21,2.25 C21.4142136,2.25 21.75,2.58578644 21.75,3 L21.75,10 C21.75,10.4142136 21.4142136,10.75 21,10.75 L14,10.75 C13.5857864,10.75 13.25,10.4142136 13.25,10 L13.25,3 C13.25,2.58578644 13.5857864,2.25 14,2.25 Z M14.75,9.25 L20.25,9.25 L20.25,3.75 L14.75,3.75 L14.75,9.25 Z M14,13.25 L21,13.25 C21.4142136,13.25 21.75,13.5857864 21.75,14 L21.75,21 C21.75,21.4142136 21.4142136,21.75 21,21.75 L14,21.75 C13.5857864,21.75 13.25,21.4142136 13.25,21 L13.25,14 C13.25,13.5857864 13.5857864,13.25 14,13.25 Z M14.75,20.25 L20.25,20.25 L20.25,14.75 L14.75,14.75 L14.75,20.25 Z M3,13.25 L10,13.25 C10.4142136,13.25 10.75,13.5857864 10.75,14 L10.75,21 C10.75,21.4142136 10.4142136,21.75 10,21.75 L3,21.75 C2.58578644,21.75 2.25,21.4142136 2.25,21 L2.25,14 C2.25,13.5857864 2.58578644,13.25 3,13.25 Z M3.75,20.25 L9.25,20.25 L9.25,14.75 L3.75,14.75 L3.75,20.25 Z"></path>
                            </svg>
                            Meus anúncios
                          </a>
                        </li>
                        <li data-open="false" class="olx-header__overflow-item" data-testid="overflow-content-lazy">
                          <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main olx-header__overflow-link" href="https://meus-pedidos.olx.com.br/minhas-vendas" tabindex="-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
                              <path fill="currentColor" fill-rule="evenodd" d="M10.25,21.25 L10.25,14 C10.25,13.5857864 10.5857864,13.25 11,13.25 L17,13.25 C17.4142136,13.25 17.75,13.5857864 17.75,14 L17.75,21.25 L19,21.25 C19.6903559,21.25 20.25,20.6903559 20.25,20 L20.25,12.5 C20.25,12.0857864 20.5857864,11.75 21,11.75 C21.4142136,11.75 21.75,12.0857864 21.75,12.5 L21.75,20 C21.75,21.5187831 20.5187831,22.75 19,22.75 L5,22.75 C3.48121694,22.75 2.25,21.5187831 2.25,20 L2.25,12.5 C2.25,12.0857864 2.58578644,11.75 3,11.75 C3.41421356,11.75 3.75,12.0857864 3.75,12.5 L3.75,20 C3.75,20.6903559 4.30964406,21.25 5,21.25 L10.25,21.25 Z M11.75,21.25 L16.25,21.25 L16.25,14.75 L11.75,14.75 L11.75,21.25 Z M1.58397485,9.62403772 C1.28315242,9.42348943 1.16822224,9.0368715 1.31064123,8.70456053 L4.31064123,1.70456053 C4.42882532,1.42879764 4.69997892,1.25 5,1.25 L19,1.25 C19.3000211,1.25 19.5711747,1.42879764 19.6893588,1.70456053 L22.6893588,8.70456053 C22.8317778,9.0368715 22.7168476,9.42348943 22.4160251,9.62403772 C21.2982422,10.3692264 20.1559213,10.75 19,10.75 C18.215551,10.75 17.7625592,10.5852757 17.0028958,10.1511824 C16.4500592,9.8352757 16.215551,9.75 15.75,9.75 C15.346735,9.75 15.087201,9.82716974 14.6425309,10.047928 C14.5954819,10.0712856 14.5255066,10.1065818 14.3979102,10.1708204 C13.5934972,10.5730269 12.9740913,10.75 12,10.75 C11.0259087,10.75 10.4065028,10.5730269 9.6020898,10.1708204 C9.47449341,10.1065818 9.40451809,10.0712856 9.35746911,10.047928 C8.91279898,9.82716974 8.65326496,9.75 8.25,9.75 C7.78444903,9.75 7.54994085,9.8352757 6.9971042,10.1511824 C6.23744085,10.5852757 5.78444903,10.75 5,10.75 C3.84407872,10.75 2.70175782,10.3692264 1.58397485,9.62403772 Z M5,9.25 C5.46555097,9.25 5.70005915,9.1647243 6.2528958,8.84881764 C7.01255915,8.4147243 7.46555097,8.25 8.25,8.25 C8.92083957,8.25 9.3905066,8.3896506 10.0244753,8.70438686 C10.0767286,8.73032821 10.1522427,8.7684182 10.2729102,8.82917961 C10.8851638,9.13530642 11.2865913,9.25 12,9.25 C12.7134087,9.25 13.1148362,9.13530642 13.7270898,8.82917961 C13.8477573,8.7684182 13.9232714,8.73032821 13.9755247,8.70438686 C14.6094934,8.3896506 15.0791604,8.25 15.75,8.25 C16.534449,8.25 16.9874408,8.4147243 17.7471042,8.84881764 C18.2999408,9.1647243 18.534449,9.25 19,9.25 C19.6739066,9.25 20.3564826,9.06776276 21.0532942,8.69496303 L18.5054529,2.75 L5.49454712,2.75 L2.94670582,8.69496303 C3.64351742,9.06776276 4.32609336,9.25 5,9.25 Z"></path>
                            </svg>
                            Minhas vendas
                          </a>
                        </li>
                        <li data-open="false" data-divider="true" class="olx-header__overflow-item" data-testid="overflow-content-lazy">
                          <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main olx-header__overflow-link" href="https://planoprofissional.olx.com.br/" tabindex="-1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
                              <path fill="currentColor" fill-rule="evenodd" d="M7.25,6.25 L7.25,5 C7.25,3.48121694 8.48121694,2.25 10,2.25 L14,2.25 C15.5187831,2.25 16.75,3.48121694 16.75,5 L16.75,6.25 L20,6.25 C21.5187831,6.25 22.75,7.48121694 22.75,9 L22.75,19 C22.75,20.5187831 21.5187831,21.75 20,21.75 L4,21.75 C2.48121694,21.75 1.25,20.5187831 1.25,19 L1.25,9 C1.25,7.48121694 2.48121694,6.25 4,6.25 L7.25,6.25 Z M8.75,6.25 L15.25,6.25 L15.25,5 C15.25,4.30964406 14.6903559,3.75 14,3.75 L10,3.75 C9.30964406,3.75 8.75,4.30964406 8.75,5 L8.75,6.25 Z M4,7.75 C3.30964406,7.75 2.75,8.30964406 2.75,9 L2.75,19 C2.75,19.6903559 3.30964406,20.25 4,20.25 L20,20.25 C20.6903559,20.25 21.25,19.6903559 21.25,19 L21.25,9 C21.25,8.30964406 20.6903559,7.75 20,7.75 L4,7.75 Z"></path>
                            </svg>
                            Plano profissional
                          </a>
                        </li>
                        <li data-open="false" class="olx-header__overflow-item" data-testid="overflow-content-lazy">
                          <a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main olx-header__overflow-link" href="https://meus-pedidos.olx.com.br/minhas-compras" tabindex="-1">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                              <path d="M6 2L3 6V20C3 20.5304 3.21071 21.0391 3.58579 21.4142C3.96086 21.7893 4.46957 22 5 22H19C19.5304 22 20.0391 21.7893 20.4142 21.4142C20.7893 21.0391 21 20.5304 21 20V6L18 2H6Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                              <path d="M3 6H21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                              <path d="M16 10C16 11.0609 15.5786 12.0783 14.8284 12.8284C14.0783 13.5786 13.0609 14 12 14C10.9391 14 9.92172 13.5786 9.17157 12.8284C8.42143 12.0783 8 11.0609 8 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                            Minhas compras
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li data-variant="anunciar" class="olx-header__item"><a data-ds-component="DS-Header-Button" class="olx-button olx-button--primary olx-button--medium olx-button--a olx-header__desapegar-button" href="https://www2.olx.com.br/desapega" data-header-keyboard-navigation="true"><span class="olx-button__content-wrapper">Anunciar</span></a></li>
                  </ul>
                </div>
              </div>
              <div class="olx-header__search-fluid">
                <form class="S6FMF5" data-variant="primary" data-hidesuggestions="true">
                  <div data-ds-component="DS-Autocomplete" class="olx-autocomplete">
                    <div class="combobox-wrapper">
                      <div id="oraculo-161-combobox" data-testid="oraculo-161-combobox">
                        <div data-ds-component="DS-TextInput" class="olx-text-input"><span class="olx-text-input__input-container olx-text-input__input-container--medium"><input id="oraculo-161-input" type="text" aria-label="Autocomplete" class="olx-text-input__input-field olx-text-input__input-field--medium" aria-autocomplete="both" placeholder="Buscar" role="combobox" aria-controls="autocomplete-list" aria-expanded="false" aria-busy="false" autocomplete="off" spellcheck="false" value=""></span></div>
                      </div>
                    </div>
                  </div>
                  <button class="ajfs2S" data-variant="primary" data-ds-component="Oraculo-Button">
                    <span class="_2dsuYh" data-variant="primary">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" fill-rule="evenodd" d="M16.8399523,15.7792921 L21.5303301,20.4696699 C21.8232233,20.7625631 21.8232233,21.2374369 21.5303301,21.5303301 C21.2374369,21.8232233 20.7625631,21.8232233 20.4696699,21.5303301 L15.7792921,16.8399523 C14.3486717,18.0325324 12.5081226,18.75 10.5,18.75 C5.94365081,18.75 2.25,15.0563492 2.25,10.5 C2.25,5.94365081 5.94365081,2.25 10.5,2.25 C15.0563492,2.25 18.75,5.94365081 18.75,10.5 C18.75,12.5081226 18.0325324,14.3486717 16.8399523,15.7792921 L16.8399523,15.7792921 Z M15.3290907,15.2161873 C16.517579,13.9994267 17.25,12.3352464 17.25,10.5 C17.25,6.77207794 14.2279221,3.75 10.5,3.75 C6.77207794,3.75 3.75,6.77207794 3.75,10.5 C3.75,14.2279221 6.77207794,17.25 10.5,17.25 C12.3352464,17.25 13.9994267,16.517579 15.2161873,15.3290907 C15.2327733,15.3085794 15.2506009,15.2887389 15.2696699,15.2696699 C15.2887389,15.2506009 15.3085794,15.2327733 15.3290907,15.2161873 L15.3290907,15.2161873 Z"></path>
                      </svg>
                    </span>
                    <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Buscar</span>
                  </button>
                </form>
              </div>
            </nav>
          </header>
        </div>
        <div id="content" class="ad__sc-18p038x-3 GYHge">
          <div id="leftside" class="ad__sc-18p038x-4 brSEGL"></div>
          <div class="ad__sc-18p038x-2 djeeke" style="
            margin-top: 15px;
            ">
            <div class="sc-bdVaJa ad__sc-h3us20-1 ad__sc-h3us20-0 dTdtCa">
              <div class="sc-bwzfXH ad__sc-h3us20-0 lbubah">
                <div class="ad__sc-duvuxf-0 ad__sc-h3us20-0 hRTDUb">
                  <div class="ad__sc-h3us20-6 bTEwpS">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div>
                        <div class="ad__sc-1rbejcw-0 kxFGLZ">
                          <div id="pub-top-adview-pinned" data-google-query-id="" style="display: none;">
                            <div id="google_ads_iframe_/73314699/OLX/15000/15020/Adview_0__container__" style="border: 0pt none; width: 320px; height: 50px;"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class=" bgoMCM">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      
                        <div class=" OtLeB">
                          <div class="eXhSEm swiper-container swiper-initialized swiper-horizontal swiper-watch-progress swiper-backface-hidden" style="overflow: hidden;">
                           
                            <div class="hGbNNN  swiper-wrapper" id="swiper-wrapper-1054cc48a182942f7" aria-live="polite" style="transition-duration: 0ms; transition-delay: 0ms; transform: translate3d(0px, 0px, 0px);">
                              <div class="eygyzf swiper-slide swiper-slide-active swiper-slide-visible swiper-slide-fully-visible" style="display: flex; justify-content: center; align-items: center; height: 100%; width: 367px;" role="group" aria-label="1 / 1">
                                <img src="data:image/jpeg;base64,<?php echo base64_encode($cliente['imgprod']); ?>" 
     alt="Imagem do Produto" 
     style="width: 100%; height: auto; border-radius: 10px; object-fit: cover;">

                              </div>
                             
                              
                            </div>
                            <div>
                              <div class="bcZaJY swiper-button-prev swiper-button-lock swiper-button-disabled" tabindex="-1" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-1054cc48a182942f7" aria-disabled="true">
                                 <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-70)">
                                 <path fill="var(--color-neutral-70)" fill-rule="evenodd" d="M14.5303301,6.53033009 C14.8232233,6.23743687 14.8232233,5.76256313 14.5303301,5.46966991 C14.2374369,5.1767767 13.7625631,5.1767767 13.4696699,5.46966991 L7.46966991,11.4696699 C7.1767767,11.7625631 7.1767767,12.2374369 7.46966991,12.5303301 L13.4696699,18.5303301 C13.7625631,18.8232233 14.2374369,18.8232233 14.5303301,18.5303301 C14.8232233,18.2374369 14.8232233,17.7625631 14.5303301,17.4696699 L9.06066017,12 L14.5303301,6.53033009 Z"></path>
                                 </svg>
                              </div>
                              <div class="cNBrzd swiper-button-next swiper-button-lock swiper-button-disabled" tabindex="-1" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-1054cc48a182942f7" aria-disabled="true">
                                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-70)">
                                  <path fill="var(--color-neutral-70)" fill-rule="evenodd" d="M9.46966991,17.4696699 C9.1767767,17.7625631 9.1767767,18.2374369 9.46966991,18.5303301 C9.76256313,18.8232233 10.2374369,18.8232233 10.5303301,18.5303301 L16.5303301,12.5303301 C16.8232233,12.2374369 16.8232233,11.7625631 16.5303301,11.4696699 L10.5303301,5.46966991 C10.2374369,5.1767767 9.76256313,5.1767767 9.46966991,5.46966991 C9.1767767,5.76256313 9.1767767,6.23743687 9.46966991,6.53033009 L14.9393398,12 L9.46966991,17.4696699 Z"></path>
                                </svg>
                              </div>
                            </div>
                            
                          
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 iwowFd">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 ccoOnh"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 eXkntI">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 jtSpqv"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 biWSIX">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 YSXKQ"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 fJvuvt">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 dmeyOb"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 jMBOCG">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 gbSaoO"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 duuEbc">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 hnWKZq"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 kRruSJ">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 jZVVT"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 gVgMGW">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 jZVVT"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 fehGuf">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 jZVVT"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 eHwusb">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                      <div class="ad__sc-h3us20-5 kyiLNg"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 jxfkIO">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div class="sc-drlKqa vlJew">
                          <div class="sc-drlKqa vlJew">
                            <span data-ds-component="DS-Badge" class="olx-badge olx-badge--info olx-badge--small olx-badge--rectangle" aria-label="Garantia da OLX">
                              <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.21764 14.976C8.07431 15.008 7.92569 15.008 7.78236 14.976C5.85547 14.5463 4.13296 13.4718 2.89968 11.9302C1.6666 10.3889 0.996455 8.47291 1.00001 6.49905V3.5C1.00001 2.83696 1.26341 2.20107 1.73225 1.73223C2.20109 1.26339 2.83697 1 3.50001 1H12.5C13.163 1 13.7989 1.26339 14.2678 1.73223C14.7366 2.20107 15 2.83696 15 3.5V6.49946C15.0035 8.47317 14.3333 10.389 13.1003 11.9302C11.867 13.4718 10.1445 14.5463 8.21764 14.976ZM14 6.49999V3.5C14 3.10217 13.842 2.72064 13.5606 2.43934C13.2793 2.15803 12.8978 2 12.5 2H3.50001C3.10219 2 2.72066 2.15803 2.43935 2.43934C2.15805 2.72064 2.00001 3.10217 2.00001 3.5V6.49999C1.99667 8.24646 2.58953 9.94177 3.68054 11.3055C4.77156 12.6693 6.29538 13.6199 8 14C9.70462 13.6199 11.2284 12.6693 12.3195 11.3055C13.4105 9.94177 14.0033 8.24646 14 6.49999Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.96854 3.30058C9.27671 3.36855 9.47144 3.67348 9.40348 3.98167L9.29586 4.46968C9.35232 4.48999 9.40816 4.51229 9.46337 4.53658C9.62377 4.60577 9.77232 4.68583 9.90902 4.77675C10.1547 4.94017 10.1488 5.28322 9.93905 5.49079C9.71547 5.71207 9.34845 5.68735 9.06991 5.54117L9.04949 5.53063C8.8607 5.43471 8.65303 5.38675 8.42649 5.38675C8.1738 5.38675 7.9487 5.45651 7.7512 5.59602C7.5537 5.73554 7.45495 5.91865 7.45495 6.14536C7.45495 6.25872 7.49706 6.36481 7.58129 6.46363C7.66842 6.56245 7.78024 6.65256 7.91675 6.73394C8.05326 6.81532 8.20284 6.89961 8.36549 6.98681C8.53104 7.0711 8.69514 7.16992 8.85779 7.28328C9.02335 7.39373 9.17438 7.51726 9.31089 7.65386C9.4474 7.78756 9.55777 7.95469 9.64199 8.15524C9.72913 8.3558 9.7727 8.57815 9.7727 8.8223C9.7727 9.1798 9.67249 9.50679 9.47209 9.80326C9.27459 10.0968 9.00737 10.3264 8.67046 10.4921C8.43451 10.6081 8.18361 10.6835 7.91775 10.7183L7.80358 11.236C7.73562 11.5442 7.43069 11.7389 7.1225 11.6709C6.81432 11.603 6.61958 11.298 6.68755 10.9898L6.76527 10.6374C6.60488 10.594 6.44994 10.5368 6.30043 10.466C6.07745 10.3586 5.87237 10.2289 5.6852 10.077C5.45521 9.89032 5.47698 9.54767 5.69536 9.34753C5.92999 9.13251 6.29845 9.16868 6.55855 9.35207C6.61361 9.39089 6.67134 9.42794 6.73174 9.46319C6.97571 9.60271 7.25454 9.67247 7.56822 9.67247C7.72796 9.67247 7.88335 9.64195 8.03438 9.58091C8.18832 9.51697 8.31902 9.4196 8.42649 9.2888C8.53395 9.1551 8.58768 9.00251 8.58768 8.83102C8.58768 8.67988 8.54412 8.54327 8.45698 8.42119C8.37275 8.29621 8.26238 8.18867 8.12587 8.09857C7.98936 8.00846 7.83833 7.91981 7.67278 7.83262C7.51013 7.74542 7.34603 7.65096 7.18048 7.54923C7.01492 7.4475 6.86389 7.3356 6.72738 7.21352C6.59087 7.09145 6.47905 6.93885 6.39192 6.75574C6.30769 6.56972 6.26557 6.36335 6.26557 6.13664C6.26557 5.79076 6.35997 5.47831 6.54876 5.19928C6.73755 4.92025 6.99314 4.70371 7.31553 4.54966C7.57472 4.42348 7.85549 4.34802 8.15786 4.32328L8.28748 3.73554C8.35544 3.42735 8.66036 3.23261 8.96854 3.30058Z" fill="currentColor"></path>
                              </svg>
                              Garantia da OLX
                            </span>
                            <span data-ds-component="DS-Badge" class="olx-badge olx-badge--info olx-badge--small olx-badge--rectangle" aria-label="Entrega fácil">
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.97925 12.3004C3.97925 11.9096 4.29606 11.5928 4.68688 11.5928H7.98914C8.37995 11.5928 8.69677 11.9096 8.69677 12.3004C8.69677 12.6912 8.37995 13.008 7.98914 13.008H4.68688C4.29606 13.008 3.97925 12.6912 3.97925 12.3004Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.64563 16.597C5.64563 16.2062 5.96245 15.8894 6.35326 15.8894H7.76851C8.15933 15.8894 8.47614 16.2062 8.47614 16.597C8.47614 16.9878 8.15933 17.3047 7.76851 17.3047H6.35326C5.96245 17.3047 5.64563 16.9878 5.64563 16.597Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M2.31042 8.00401C2.31042 7.6132 2.62724 7.29639 3.01805 7.29639H8.11298C8.50379 7.29639 8.8206 7.6132 8.8206 8.00401C8.8206 8.39483 8.50379 8.71164 8.11298 8.71164H3.01805C2.62724 8.71164 2.31042 8.39483 2.31042 8.00401Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.7546 6.4375H17.3848C18.1469 6.4375 18.81 6.95906 18.9895 7.6997L19.5716 10.1015L22.1057 11.4084C22.6549 11.6916 23 12.2579 23 12.8758V16.5131C23 17.425 22.2608 18.1642 21.3489 18.1642H17.9845V16.7489H21.3489C21.4791 16.7489 21.5847 16.6433 21.5847 16.5131V12.8758C21.5847 12.7876 21.5354 12.7067 21.457 12.6662L18.3484 11.0631L17.614 8.03307C17.5884 7.92727 17.4937 7.85276 17.3848 7.85276H12.1699V16.7489H14.591V18.1642H10.7546V6.4375Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M1 3.70763C1 3.31682 1.31682 3 1.70763 3H11.4593C11.8501 3 12.1669 3.31682 12.1669 3.70763V7.14478C12.1669 7.53559 11.8501 7.8524 11.4593 7.8524C11.0685 7.8524 10.7517 7.53559 10.7517 7.14478V4.41526H1.70763C1.31682 4.41526 1 4.09844 1 3.70763Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M19.1251 18.315C19.1251 19.8876 17.8503 21.1624 16.2778 21.1624C14.7052 21.1624 13.4304 19.8876 13.4304 18.315C13.4304 16.7425 14.7052 15.4677 16.2778 15.4677C17.8503 15.4677 19.1251 16.7425 19.1251 18.315ZM17.7099 18.315C17.7099 19.1059 17.0687 19.7471 16.2778 19.7471C15.4869 19.7471 14.8457 19.1059 14.8457 18.315C14.8457 17.5241 15.4869 16.8829 16.2778 16.8829C17.0687 16.8829 17.7099 17.5241 17.7099 18.315Z" fill="currentColor"></path>
                              </svg>
                              Entrega fácil
                            </span>
                            <span data-ds-component="DS-Badge" class="olx-badge olx-badge--info olx-badge--small olx-badge--rectangle" aria-label="Pague online">
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <path d="M6 2L3 6V20C3 20.5304 3.21071 21.0391 3.58579 21.4142C3.96086 21.7893 4.46957 22 5 22H19C19.5304 22 20.0391 21.7893 20.4142 21.4142C20.7893 21.0391 21 20.5304 21 20V6L18 2H6Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M3 6H21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M16 10C16 11.0609 15.5786 12.0783 14.8284 12.8284C14.0783 13.5786 13.0609 14 12 14C10.9391 14 9.92172 13.5786 9.17157 12.8284C8.42143 12.0783 8 11.0609 8 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                              </svg>
                              Pague online
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 hVBMMM">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div data-ds-component="DS-Flex" class="ad__sc-1ukaq78-0 kkAwSq olx-d-flex olx-ai-flex-start olx-fd-column olx-jc-space-between">
                          <div class="ad__sc-en9h1n-0 IoqnP">
                            <div data-ds-component="DS-Flex" class="ad__sc-1wimjbb-3 bVPwgc olx-d-flex olx-ai-flex-start olx-fd-column-reverse">
                              <div data-ds-component="DS-Flex" class="ad__sc-1wimjbb-4 iKICED olx-d-flex">
                                <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-center olx-jc-flex-start"><span data-ds-component="DS-Text" class="olx-text olx-text--title-large olx-text--block ad__sc-1wimjbb-1 hoHpcC">R$ <?php echo $cliente['valor']; ?></span></div>
                                <div class="ad__sc-h3us20-3 dFeJTI">
                                  <div class="ad__sc-1wimjbb-0 UbaFz">
                                    <div class="sc-hBbWxd mgOeD">
                                      <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                                        <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-9" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:464px;--modal-max-width:400px">
                                          <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                                            <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                              <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                                            </svg>
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="ad__sc-h3us20-2 eqqGqr"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 eUxWSm">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div>
                        <div class="ad__sc-h3us20-5 VkedQ"></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 ipeowV">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <h1 data-ds-component="DS-Text" class="olx-text olx-text--title-medium olx-text--block ad__sc-45jt43-0 htAiPK"><?php echo $cliente['produto']; ?></h1>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 hpznci">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div>
                        <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-1oq8jzc-0 dWayMW olx-color-neutral-120">
                          Publicado em<!-- --> <!-- --><?php echo $cliente['datapublicada']; ?> às <?php echo $cliente['horapublicada']; ?>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 ldCVRg">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div>
                        <div class="sc-cBrjTV kasWSD">
                          <span data-ds-component="DS-Text" class="olx-text olx-text--body-large olx-text--block olx-text--bold">Este anúncio oferece:</span>
                          <div class="sc-iCwjlJ gNDsRI">
                            <div class="sc-jdfcpN kSFdbo">
                              <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="color:var(--color-neutral-darkest)">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.21764 14.976C8.07431 15.008 7.92569 15.008 7.78236 14.976C5.85547 14.5463 4.13296 13.4718 2.89968 11.9302C1.6666 10.3889 0.996455 8.47291 1.00001 6.49905V3.5C1.00001 2.83696 1.26341 2.20107 1.73225 1.73223C2.20109 1.26339 2.83697 1 3.50001 1H12.5C13.163 1 13.7989 1.26339 14.2678 1.73223C14.7366 2.20107 15 2.83696 15 3.5V6.49946C15.0035 8.47317 14.3333 10.389 13.1003 11.9302C11.867 13.4718 10.1445 14.5463 8.21764 14.976ZM14 6.49999V3.5C14 3.10217 13.842 2.72064 13.5606 2.43934C13.2793 2.15803 12.8978 2 12.5 2H3.50001C3.10219 2 2.72066 2.15803 2.43935 2.43934C2.15805 2.72064 2.00001 3.10217 2.00001 3.5V6.49999C1.99667 8.24646 2.58953 9.94177 3.68054 11.3055C4.77156 12.6693 6.29538 13.6199 8 14C9.70462 13.6199 11.2284 12.6693 12.3195 11.3055C13.4105 9.94177 14.0033 8.24646 14 6.49999Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.96854 3.30058C9.27671 3.36855 9.47144 3.67348 9.40348 3.98167L9.29586 4.46968C9.35232 4.48999 9.40816 4.51229 9.46337 4.53658C9.62377 4.60577 9.77232 4.68583 9.90902 4.77675C10.1547 4.94017 10.1488 5.28322 9.93905 5.49079C9.71547 5.71207 9.34845 5.68735 9.06991 5.54117L9.04949 5.53063C8.8607 5.43471 8.65303 5.38675 8.42649 5.38675C8.1738 5.38675 7.9487 5.45651 7.7512 5.59602C7.5537 5.73554 7.45495 5.91865 7.45495 6.14536C7.45495 6.25872 7.49706 6.36481 7.58129 6.46363C7.66842 6.56245 7.78024 6.65256 7.91675 6.73394C8.05326 6.81532 8.20284 6.89961 8.36549 6.98681C8.53104 7.0711 8.69514 7.16992 8.85779 7.28328C9.02335 7.39373 9.17438 7.51726 9.31089 7.65386C9.4474 7.78756 9.55777 7.95469 9.64199 8.15524C9.72913 8.3558 9.7727 8.57815 9.7727 8.8223C9.7727 9.1798 9.67249 9.50679 9.47209 9.80326C9.27459 10.0968 9.00737 10.3264 8.67046 10.4921C8.43451 10.6081 8.18361 10.6835 7.91775 10.7183L7.80358 11.236C7.73562 11.5442 7.43069 11.7389 7.1225 11.6709C6.81432 11.603 6.61958 11.298 6.68755 10.9898L6.76527 10.6374C6.60488 10.594 6.44994 10.5368 6.30043 10.466C6.07745 10.3586 5.87237 10.2289 5.6852 10.077C5.45521 9.89032 5.47698 9.54767 5.69536 9.34753C5.92999 9.13251 6.29845 9.16868 6.55855 9.35207C6.61361 9.39089 6.67134 9.42794 6.73174 9.46319C6.97571 9.60271 7.25454 9.67247 7.56822 9.67247C7.72796 9.67247 7.88335 9.64195 8.03438 9.58091C8.18832 9.51697 8.31902 9.4196 8.42649 9.2888C8.53395 9.1551 8.58768 9.00251 8.58768 8.83102C8.58768 8.67988 8.54412 8.54327 8.45698 8.42119C8.37275 8.29621 8.26238 8.18867 8.12587 8.09857C7.98936 8.00846 7.83833 7.91981 7.67278 7.83262C7.51013 7.74542 7.34603 7.65096 7.18048 7.54923C7.01492 7.4475 6.86389 7.3356 6.72738 7.21352C6.59087 7.09145 6.47905 6.93885 6.39192 6.75574C6.30769 6.56972 6.26557 6.36335 6.26557 6.13664C6.26557 5.79076 6.35997 5.47831 6.54876 5.19928C6.73755 4.92025 6.99314 4.70371 7.31553 4.54966C7.57472 4.42348 7.85549 4.34802 8.15786 4.32328L8.28748 3.73554C8.35544 3.42735 8.66036 3.23261 8.96854 3.30058Z" fill="currentColor"></path>
                              </svg>
                            </div>
                            <div class="sc-fkyLDJ cCkxId">
                              <p data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular sc-jRuhRL cngJQJ olx-mb-stack-quarck"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--inline olx-text--bold sc-kNBZmU ffVeoe">Garantia da OLX. </span>Pague online e receba o que comprou ou a OLX devolve seu dinheiro</p>
                            </div>
                          </div>
                          <div class="sc-iCwjlJ gNDsRI">
                            <div class="sc-jdfcpN kSFdbo">
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="color:var(--color-neutral-darkest)">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.97925 12.3004C3.97925 11.9096 4.29606 11.5928 4.68688 11.5928H7.98914C8.37995 11.5928 8.69677 11.9096 8.69677 12.3004C8.69677 12.6912 8.37995 13.008 7.98914 13.008H4.68688C4.29606 13.008 3.97925 12.6912 3.97925 12.3004Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.64563 16.597C5.64563 16.2062 5.96245 15.8894 6.35326 15.8894H7.76851C8.15933 15.8894 8.47614 16.2062 8.47614 16.597C8.47614 16.9878 8.15933 17.3047 7.76851 17.3047H6.35326C5.96245 17.3047 5.64563 16.9878 5.64563 16.597Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M2.31042 8.00401C2.31042 7.6132 2.62724 7.29639 3.01805 7.29639H8.11298C8.50379 7.29639 8.8206 7.6132 8.8206 8.00401C8.8206 8.39483 8.50379 8.71164 8.11298 8.71164H3.01805C2.62724 8.71164 2.31042 8.39483 2.31042 8.00401Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.7546 6.4375H17.3848C18.1469 6.4375 18.81 6.95906 18.9895 7.6997L19.5716 10.1015L22.1057 11.4084C22.6549 11.6916 23 12.2579 23 12.8758V16.5131C23 17.425 22.2608 18.1642 21.3489 18.1642H17.9845V16.7489H21.3489C21.4791 16.7489 21.5847 16.6433 21.5847 16.5131V12.8758C21.5847 12.7876 21.5354 12.7067 21.457 12.6662L18.3484 11.0631L17.614 8.03307C17.5884 7.92727 17.4937 7.85276 17.3848 7.85276H12.1699V16.7489H14.591V18.1642H10.7546V6.4375Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M1 3.70763C1 3.31682 1.31682 3 1.70763 3H11.4593C11.8501 3 12.1669 3.31682 12.1669 3.70763V7.14478C12.1669 7.53559 11.8501 7.8524 11.4593 7.8524C11.0685 7.8524 10.7517 7.53559 10.7517 7.14478V4.41526H1.70763C1.31682 4.41526 1 4.09844 1 3.70763Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M19.1251 18.315C19.1251 19.8876 17.8503 21.1624 16.2778 21.1624C14.7052 21.1624 13.4304 19.8876 13.4304 18.315C13.4304 16.7425 14.7052 15.4677 16.2778 15.4677C17.8503 15.4677 19.1251 16.7425 19.1251 18.315ZM17.7099 18.315C17.7099 19.1059 17.0687 19.7471 16.2778 19.7471C15.4869 19.7471 14.8457 19.1059 14.8457 18.315C14.8457 17.5241 15.4869 16.8829 16.2778 16.8829C17.0687 16.8829 17.7099 17.5241 17.7099 18.315Z" fill="currentColor"></path>
                              </svg>
                            </div>
                            <div class="sc-fkyLDJ cCkxId">
                              <p data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular sc-jRuhRL cngJQJ olx-mb-stack-quarck"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--inline olx-text--bold sc-kNBZmU ffVeoe">Entrega fácil. </span>Receba ou retire seu produto onde quiser com segurança.</p>
                            </div>
                          </div>
                          <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                            <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-10" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:90vh;--modal-max-width:600px">
                              <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                                <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                  <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                                </svg>
                              </button>
                              <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-10">
                                <div class="sc-eEieub iKOnDg">
                                  <span data-ds-component="DS-Text" class="olx-text olx-text--body-large olx-text--block olx-text--bold olx-mt-2">Entrega fácil</span>
                                  <div class="sc-eNNmBn hRKSON">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="none" viewBox="0 0 96 96">
                                      <path d="M48 90c23.196 0 42-18.804 42-42S71.196 6 48 6 6 24.804 6 48s18.804 42 42 42Z" fill="var(--spots-background-circle)"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M93.715 56.823c.075-1.515 0-8.265-5.25-8.265-.374-.62-1.865-3.72-3.208-6.337-1.193-2.48-3.878-4.064-6.787-4.064H67.358v25.347h25.76s2.014-1.24 2.014-2.686c0-1.378.373-3.582-1.417-3.995Z"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M88.498 48.558c5.251 0 5.167 6.599 5.092 8.114H67.233l.16-18.515h11.111c2.91 0 5.594 1.584 6.787 4.064 1.343 2.617 2.834 5.717 3.207 6.337Z"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="m82.419 48.693-2.287-4.684c-.143-.345-.5-.551-.93-.551h-5.144v6.68h7.36c.786 0 1.358-.757 1-1.445Z"></path>
                                      <path fill="var(--color-neutral-70)" d="M24.335 26h39.184a5 5 0 0 1 5 5v28.156H24.335V26ZM26.08 59.156h42.44v4.42H30.5a4.42 4.42 0 0 1-4.42-4.42Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M68.52 59.377H24.334M24.335 36.746V26H62.88c3.141 0 5.64 2.427 5.64 5.477v32.1H30.28c-2.64 0-3.62-1.58-3.62-4.145h-2.325v-7.919"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M43.157 64.163c0 3.26-2.755 5.837-6.14 5.837-3.386 0-6.141-2.653-6.141-5.837 0-3.183 2.755-5.836 6.14-5.836 3.465 0 6.142 2.577 6.142 5.836Z"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M40.323 64.163c0 1.755-1.484 3.143-3.307 3.143s-3.306-1.429-3.306-3.143c0-1.714 1.483-3.143 3.306-3.143 1.865 0 3.307 1.388 3.307 3.143Z"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M84.725 64.163c0 3.26-2.755 5.837-6.14 5.837-3.386 0-6.141-2.653-6.141-5.837 0-3.183 2.755-5.836 6.14-5.836 3.465 0 6.141 2.577 6.141 5.836Z"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M81.891 64.163c0 1.755-1.483 3.143-3.306 3.143s-3.307-1.429-3.307-3.143c0-1.714 1.484-3.143 3.307-3.143 1.865 0 3.306 1.388 3.306 3.143Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M38.113 48.263H13.03"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M24.335 40.367v7.46"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M53.334 36.846H19.96M61.623 26H19.96M15.354 26.17h-1.502M9.243 26.17H7.67M7.886 48.263H6.312M15.354 36.846h-1.502"></path>
                                    </svg>
                                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--bold">Receber o produto em casa</span>Compre de qualquer lugar do Brasil e receba onde quiser.</span>
                                  </div>
                                  <div class="sc-eNNmBn hRKSON">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="none" viewBox="0 0 96 96">
                                      <path d="M48 90c23.196 0 42-18.804 42-42S71.196 6 48 6 6 24.804 6 48s18.804 42 42 42Z" fill="var(--spots-background-circle)"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-miterlimit="10" stroke-width="1.5" d="M25.117 12.016v39.713h53.897V13.428c0-1.915-1.48-3.427-3.356-3.427H27.091c-1.086 0-1.974.907-1.974 2.016Z"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-miterlimit="10" stroke-width="1.5" d="M60.357 19.105H45.33c-.72 0-1.235-.512-1.235-1.228V10h16.674v8.593c.103.307-.103.512-.412.512Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M29.605 39.612h2.879M34.867 39.612h2.978M40.228 39.612h2.979"></path>
                                      <path fill="var(--color-neutral-90)" d="m38.781 43.763 5.314 3.035h27.328l7.06-3.035-7.06 8.346-6.832 1.517L48.27 52.11l-9.489-8.346Z"></path>
                                      <path fill="var(--color-neutral-70)" d="M83.217 39.915c-3.574.807-6.652 3.027-9.034 7.769l-7.943 4.54c-.894-1.21-2.383-2.118-4.468-2.118H50.355c-1.688 0-5.163-4.44-7.844-4.44-.993-.404-5.957-.404-9.432 0-2.68 0-6.155 2.422-8.141 4.238-2.979 3.027-10.623 10.392-11.517 11.099 4.865 4.136 14.793 13.823 16.978 15.84 2.978-3.026 4.17-5.851 6.552-5.851h26.807c2.184 0 14.396-11.301 15.985-13.117 1.133-1.306 6.009-7.702 9.104-12.594.97-1.533.795-2.656.415-3.794-1.092-1.614-2.272-2.48-6.045-1.572Z"></path>
                                      <path fill="var(--color-neutral-90)" d="M83.217 39.915c-3.574.807-6.652 3.027-9.034 7.769l-7.943 4.54c-.894-1.21-2.383-2.118-4.468-2.118H50.355c-1.688 0-5.163-4.44-7.844-4.44-.993-.404-5.957-.404-9.432 0-2.68 0-6.155 2.422-8.141 4.238-2.979 3.027-10.623 10.392-11.517 11.099 4.865 4.136 4.197-2.018 6.381 0 2.406-2.445 9.891-11.1 13.277-11.1 2.286-1.208 4.183-1.208 7.6-1.208.238-.274 6.381 5.334 9.676 5.311 4.912-.033 10.08 1.919 16.513.759.945-1.511 3.789-.705 9.869-5.037.759-2.93 6.073-5.965 6.48-5.585 3.273-1.134 5.112 1.956 5.63 1.138.97-1.533.795-2.656.415-3.794-1.092-1.614-2.272-2.48-6.045-1.572Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-miterlimit="10" stroke-width="1.5" d="M45.688 60.498h16.084c7.347 0 7.347-10.393 0-10.393H50.355c-1.688 0-4.964-4.44-7.645-4.44H32.484c-2.88 0-5.56 2.422-7.447 4.238-2.978 3.027-10.623 10.393-11.516 11.1 4.765 4.136 14.694 13.822 16.878 15.84 2.978-3.026 4.17-5.852 6.552-5.852h24.722c1.986 0 3.872-.504 5.66-1.412 5.658-3.23 11.119-10.191 12.41-11.604 1.092-1.311 5.957-7.567 9.034-12.511 1.688-2.623-.297-6.054-3.375-5.852-.695.1-1.49.202-2.284.403-3.574.808-6.652 3.027-9.035 7.77l-7.942 3.935"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-miterlimit="10" stroke-width="1.5" d="m29.009 85.016 5.361-5.449c1.29-1.311 1.29-3.33 0-4.64l-17.474-17.86c-1.29-1.312-3.276-1.312-4.567 0l-5.361 5.449c-1.29 1.311-1.29 3.33 0 4.641l17.573 17.86a3.028 3.028 0 0 0 4.468 0Z"></path>
                                      <path stroke="var(--color-neutral-70)" stroke-linecap="round" stroke-miterlimit="10" stroke-width="1.5" d="m12.826 63.424 3.872 3.935"></path>
                                    </svg>
                                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--bold">Retirar com o vendedor</span>Compre online e combine a retirada do produto pelo chat.</span>
                                  </div>
                                  <div class="sc-eNNmBn hRKSON">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="none" viewBox="0 0 96 96">
                                      <path d="M48 90c23.196 0 42-18.804 42-42S71.196 6 48 6 6 24.804 6 48s18.804 42 42 42Z" fill="var(--spots-background-circle)"></path>
                                      <path fill="var(--color-neutral-70)" d="M68.935 60.892v22.226H17.382V14.381h51.553v17.914"></path>
                                      <path fill="var(--spots-color-circle)" d="M37 27.533V34H17V14h20v5.212M69 76.856V83H37V64h32v4.952"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M68.934 60.892V83.12H17.382V14.38h51.553v17.915"></path>
                                      <path fill="var(--color-neutral-80)" d="M36.714 29.417h32.22l17.184-4.296v41.831l-17.184-3.167h-32.22"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M36.714 29.417h32.22l17.184-4.296v41.831l-17.184-3.167h-32.22"></path>
                                      <path fill="var(--color-neutral-80)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M36.715 33.713H17.38v23.63h19.334v-23.63Z"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M31.5 37.5h-9v9h9v-9Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M24 50.899h6M36.714 83.026V14.381"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M73.23 35.862H43.159v21.48h30.073v-21.48Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M65.1 53.046h2.74"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m62.49 43.91-4.296-3.035-4.297 3.036v-8.05h8.594v8.05Z"></path>
                                      <path fill="var(--color-neutral-70)" fill-rule="evenodd" d="M26 19.125h-2.5c-.76 0-1.375.616-1.375 1.375V23c0 .207.168.375.375.375H26a.375.375 0 0 0 .375-.375v-3.5a.375.375 0 0 0-.375-.375Zm-2.5.75h2.125v2.75h-2.75V20.5c0-.345.28-.625.625-.625Zm4.5-.75a.375.375 0 0 0-.375.375V23c0 .207.168.375.375.375h3.5a.375.375 0 0 0 .375-.375v-2.5c0-.76-.616-1.375-1.375-1.375H28Zm.375 3.5v-2.75H30.5c.345 0 .625.28.625.625v2.125h-2.75ZM31.125 26v-1a.375.375 0 0 1 .75 0v1a.375.375 0 0 1-.75 0Zm0 1.5c0 .345-.28.625-.625.625h-1a.375.375 0 0 0 0 .75h1c.76 0 1.375-.616 1.375-1.375a.375.375 0 0 0-.75 0Zm-2.75 0v1a.375.375 0 0 1-.75 0v-1a.375.375 0 0 1 .75 0ZM30 25.375a.375.375 0 0 0 0-.75H28a.375.375 0 0 0-.375.375v1a.375.375 0 0 0 .75 0v-.625H30ZM22.125 25c0-.207.168-.375.375-.375H26c.207 0 .375.168.375.375v3.5a.375.375 0 0 1-.375.375h-2.5c-.76 0-1.375-.616-1.375-1.375V25Zm.75.375V27.5c0 .345.28.625.625.625h2.125v-2.75h-2.75Zm.625-4.688c0-.103.084-.187.187-.187h1.125c.104 0 .188.084.188.187v1.125a.187.187 0 0 1-.188.188h-1.125a.188.188 0 0 1-.187-.188v-1.125Zm5.688-.187a.188.188 0 0 0-.188.187v1.125c0 .104.084.188.188.188h1.125a.188.188 0 0 0 .187-.188v-1.125a.188.188 0 0 0-.187-.187h-1.125ZM23.5 26.188c0-.104.084-.188.187-.188h1.125c.104 0 .188.084.188.188v1.125a.188.188 0 0 1-.188.187h-1.125a.188.188 0 0 1-.187-.187v-1.125ZM29.188 26a.187.187 0 0 0-.188.188v1.125c0 .103.084.187.188.187h1.125a.188.188 0 0 0 .187-.187v-1.125a.188.188 0 0 0-.187-.188h-1.125Z" clip-rule="evenodd"></path>
                                    </svg>
                                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--bold">Retirar no armário CliqueRetire</span>Compre online e retire seu produto em um dos armários CliqueRetire disponíveis na sua região.</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                            <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-11" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:90vh;--modal-max-width:600px">
                              <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                                <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                  <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                                </svg>
                              </button>
                              <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-11">
                                <div data-ds-component="DS-Flex" class="sc-jMMfwr AerSA olx-d-flex olx-fd-column">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="96" height="96px" fill="none" viewBox="0 0 96 96" class="sc-jqIZGH bcmKlD">
                                    <path d="M48 90c23.196 0 42-18.804 42-42S71.196 6 48 6 6 24.804 6 48s18.804 42 42 42Z" fill="var(--spots-background-circle)"></path>
                                    <path fill="var(--spots-color-circle)" d="m42.738 33.249 1.08 7.689-6.296.885-1.193-8.485s-1.941-16.22 13.768-18.428c15.71-2.208 18.47 12.613 18.47 12.613l1.378 9.81-6.363.895-1.36-9.678s-2.064-8.43-10.748-7.21c-8.683 1.221-8.994 9.106-8.736 11.909Z"></path>
                                    <path stroke="var(--color-neutral-70)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="m39.534 39.31.289 2.054"></path>
                                    <path fill="var(--color-neutral-70)" d="m70.633 36.976-34.291 4.82c-6.715.944-9.156 5.527-8.425 10.725l3.132 22.287c.721 5.133 5.596 8.412 11.007 7.651l34.291-4.819c5.344-.75 9.457-3.385 7.8-10.295L81.015 45.06c-.89-6.332-3.331-9.073-10.382-8.083ZM59.366 60.36c-.117.15-.234.298-.207.493l.786 5.588c.182 1.3-.745 2.556-2.165 2.756l-.812.114c-1.352.19-2.648-.688-2.84-2.053l-.785-5.588c-.028-.194-.114-.315-.335-.416-2.5-1.107-3.917-3.823-3.074-6.658.525-1.664 1.84-3.108 3.553-3.68 3.61-1.302 7.308.961 7.792 4.405.264 1.884-.504 3.78-1.913 5.04Z"></path>
                                    <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M29.941 45.118a7.176 7.176 0 0 1 4.797-2.905l38.048-5.347c3.911-.55 7.54 2.185 8.09 6.096l3.698 26.316c.55 3.91-2.185 7.54-6.096 8.089L42.087 82.48"></path>
                                    <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="m70.002 37.259-1.24-8.816c-1.257-8.949-9.573-15.216-18.522-13.958-8.949 1.258-15.282 9.583-14.024 18.532l1.24 8.816 6.495-.913-1.239-8.816a9.884 9.884 0 0 1 8.432-11.19 9.884 9.884 0 0 1 11.189 8.432l1.239 8.816M57.547 69.359a2.471 2.471 0 0 1-2.797-2.108l-.8-5.7c-.029-.2-.114-.323-.331-.428-2.459-1.141-3.863-3.918-3.052-6.803.506-1.694 1.787-3.158 3.464-3.732a5.71 5.71 0 0 1 7.667 4.533c.27 1.922-.473 3.852-1.915 5.136-.114.151-.228.302-.2.501l.802 5.7a2.47 2.47 0 0 1-2.108 2.798l-.73.103Z"></path>
                                    <path stroke="var(--color-neutral-70)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M42.928 20.653c-3.264 3.23-4.884 8.054-4.167 13.158l.457 3.248"></path>
                                    <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="m77.463 49.042 2.078 14.786M80.108 67.858l.378 2.689"></path>
                                    <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M28.69 50.159s-6.376 6.574-12.408 7.422L18.266 71.7c.41 2.916 1.976 5.4 4.245 6.636 2.269 1.236 9.153 4.527 9.437 4.622l1.447.675 1.204-1.048c.238-.236 5.957-5.23 7.855-7.12 1.783-1.737 2.67-4.566 2.25-7.549L42.73 53.864c-6.098.857-14.04-3.705-14.04-3.705Z"></path>
                                    <path fill="var(--color-neutral-70)" fill-rule="evenodd" stroke="var(--color-neutral-70)" stroke-width="1.5" d="M26.153 67.891a.428.428 0 0 0-.597.106.43.43 0 0 0 .105.598l3.313 2.326c.194.137.461.09.597-.105l5.098-7.301a.43.43 0 0 0-.106-.599.428.428 0 0 0-.597.106l-4.852 6.949-2.961-2.08Z" clip-rule="evenodd"></path>
                                  </svg>
                                  <span data-ds-component="DS-Text" class="olx-text olx-text--body-large olx-text--block olx-text--bold">Receba o que comprou ou seu dinheiro de volta</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Com a garantia da OLX suas compras estão protegidas. Compre diretamente pelo app ou site, clicando no botão Comprar, e nós garantimos o reembolso do valor caso haja algum problema com a sua compra.</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--bold">Situações de Cobertura</span>
                                  <ul class="sc-jGxEUC bLAmFD">
                                    <li class="sc-jdeSqf cLuAeg">
                                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.5337 11.5971C20.5337 11.1926 20.8616 10.8646 21.2662 10.8646C21.6707 10.8646 21.9987 11.1926 21.9987 11.5971V12.5059C21.996 17.1557 18.9353 21.2499 14.4763 22.5683C10.0173 23.8867 5.22224 22.1151 2.69145 18.2144C0.160657 14.3136 0.496999 9.21289 3.51808 5.67823C6.53916 2.14357 11.5253 1.01701 15.7726 2.90949C16.1421 3.07414 16.3082 3.50718 16.1435 3.87671C15.9789 4.24624 15.5458 4.41233 15.1763 4.24768C11.5217 2.61927 7.23128 3.58863 4.63175 6.63008C2.03221 9.67154 1.7428 14.0606 3.92046 17.417C6.09812 20.7735 10.2241 22.2978 14.0609 21.1634C17.8977 20.029 20.5314 16.506 20.5337 12.5054V11.5971ZM11.4994 13.4229L21.7249 3.19735C22.0109 2.91129 22.4747 2.91129 22.7608 3.19735C23.0469 3.48342 23.0469 3.94722 22.7608 4.23328L12.0173 14.9768C11.7313 15.2628 11.2675 15.2628 10.9814 14.9768L8.05136 12.0467C7.7653 11.7607 7.7653 11.2969 8.05136 11.0108C8.33743 10.7247 8.80123 10.7247 9.08729 11.0108L11.4994 13.4229Z" fill="var(--color-secondary-100)"></path>
                                      </svg>
                                      <span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Produto diferente do anunciado</span>
                                    </li>
                                    <li class="sc-jdeSqf cLuAeg">
                                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.5337 11.5971C20.5337 11.1926 20.8616 10.8646 21.2662 10.8646C21.6707 10.8646 21.9987 11.1926 21.9987 11.5971V12.5059C21.996 17.1557 18.9353 21.2499 14.4763 22.5683C10.0173 23.8867 5.22224 22.1151 2.69145 18.2144C0.160657 14.3136 0.496999 9.21289 3.51808 5.67823C6.53916 2.14357 11.5253 1.01701 15.7726 2.90949C16.1421 3.07414 16.3082 3.50718 16.1435 3.87671C15.9789 4.24624 15.5458 4.41233 15.1763 4.24768C11.5217 2.61927 7.23128 3.58863 4.63175 6.63008C2.03221 9.67154 1.7428 14.0606 3.92046 17.417C6.09812 20.7735 10.2241 22.2978 14.0609 21.1634C17.8977 20.029 20.5314 16.506 20.5337 12.5054V11.5971ZM11.4994 13.4229L21.7249 3.19735C22.0109 2.91129 22.4747 2.91129 22.7608 3.19735C23.0469 3.48342 23.0469 3.94722 22.7608 4.23328L12.0173 14.9768C11.7313 15.2628 11.2675 15.2628 10.9814 14.9768L8.05136 12.0467C7.7653 11.7607 7.7653 11.2969 8.05136 11.0108C8.33743 10.7247 8.80123 10.7247 9.08729 11.0108L11.4994 13.4229Z" fill="var(--color-secondary-100)"></path>
                                      </svg>
                                      <span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Produto não recebido</span>
                                    </li>
                                    <li class="sc-jdeSqf cLuAeg">
                                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.5337 11.5971C20.5337 11.1926 20.8616 10.8646 21.2662 10.8646C21.6707 10.8646 21.9987 11.1926 21.9987 11.5971V12.5059C21.996 17.1557 18.9353 21.2499 14.4763 22.5683C10.0173 23.8867 5.22224 22.1151 2.69145 18.2144C0.160657 14.3136 0.496999 9.21289 3.51808 5.67823C6.53916 2.14357 11.5253 1.01701 15.7726 2.90949C16.1421 3.07414 16.3082 3.50718 16.1435 3.87671C15.9789 4.24624 15.5458 4.41233 15.1763 4.24768C11.5217 2.61927 7.23128 3.58863 4.63175 6.63008C2.03221 9.67154 1.7428 14.0606 3.92046 17.417C6.09812 20.7735 10.2241 22.2978 14.0609 21.1634C17.8977 20.029 20.5314 16.506 20.5337 12.5054V11.5971ZM11.4994 13.4229L21.7249 3.19735C22.0109 2.91129 22.4747 2.91129 22.7608 3.19735C23.0469 3.48342 23.0469 3.94722 22.7608 4.23328L12.0173 14.9768C11.7313 15.2628 11.2675 15.2628 10.9814 14.9768L8.05136 12.0467C7.7653 11.7607 7.7653 11.2969 8.05136 11.0108C8.33743 10.7247 8.80123 10.7247 9.08729 11.0108L11.4994 13.4229Z" fill="var(--color-secondary-100)"></path>
                                      </svg>
                                      <div><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Produto defeituoso</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--light">Exceto nos casos de anúncios que explicitam essa condição.</span></div>
                                    </li>
                                  </ul>
                                  <div data-ds-componet="DS-Alertbox" class="olx-alertbox olx-alertbox--default" role="status" title="Não recebeu o que esperava?">
                                    <div class="olx-alertbox__content-wrapper">
                                      <span class="olx-alertbox__icon-wrapper" aria-hidden="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                          <path fill="currentColor" fill-rule="evenodd" d="M12,22.75 C6.06293894,22.75 1.25,17.9370611 1.25,12 C1.25,6.06293894 6.06293894,1.25 12,1.25 C17.9370611,1.25 22.75,6.06293894 22.75,12 C22.75,17.9370611 17.9370611,22.75 12,22.75 Z M12,21.25 C17.1086339,21.25 21.25,17.1086339 21.25,12 C21.25,6.89136606 17.1086339,2.75 12,2.75 C6.89136606,2.75 2.75,6.89136606 2.75,12 C2.75,17.1086339 6.89136606,21.25 12,21.25 Z M12.75,16 C12.75,16.4142136 12.4142136,16.75 12,16.75 C11.5857864,16.75 11.25,16.4142136 11.25,16 L11.25,12 C11.25,11.5857864 11.5857864,11.25 12,11.25 C12.4142136,11.25 12.75,11.5857864 12.75,12 L12.75,16 Z M12,10 C11.4477153,10 11,9.55228475 11,9 C11,8.44771525 11.4477153,8 12,8 C12.5522847,8 13,8.44771525 13,9 C13,9.55228475 12.5522847,10 12,10 Z"></path>
                                        </svg>
                                      </span>
                                      <div class="olx-alertbox__content">
                                        <span class="olx-alertbox__title" title="Não recebeu o que esperava?">Não recebeu o que esperava?</span>
                                        <div class="olx-alertbox__description">Acesse “Preciso de ajuda” em “Detalhes da Compra” e nós resolveremos pra você.</div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 hIQvOE">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div>
                        <div class="ad__sc-h3us20-5 fRFGxf"></div>
                        <div data-ds-component="DS-Flex" class="ad__sc-en9h1n-1 dlIVkT olx-d-flex olx-pl-1 olx-pr-1 olx-jc-space-between">
                          <button data-ds-component="DS-Button" class="olx-button olx-button--primary olx-button--medium ad__sc-en9h1n-3 dfQibb">
                            <span class="olx-button__content-wrapper">
                              <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Adicionar aos favoritos</span>
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-secondary-100)">
                                <path fill="var(--color-secondary-100)" fill-rule="evenodd" d="M20.1410488,11.9192144 C21.0111169,11.0495546 21.5,9.86964349 21.5,8.63933177 C21.5,7.40903732 21.0111291,6.22912113 20.1406731,5.35907349 C19.2709033,4.48889534 18.0909972,4 16.8606682,4 C15.6303392,4 14.4504331,4.48889534 13.5804144,5.35932248 L13.0603975,5.8793394 C12.4746111,6.46512582 11.5248636,6.46512581 10.9390772,5.87933938 L10.418938,5.35920023 C8.60737139,3.54763364 5.67024159,3.54763366 3.85867497,5.35920027 C2.04710836,7.17076689 2.04710834,10.1078967 3.85867491,11.9194633 L11.9997374,20.0605258 L20.1410488,11.9192144 Z M11.9997374,4.81867921 L12.5197543,4.29866229 C13.6726655,3.14627475 15.2333397,2.5 16.8606682,2.5 C18.488944,2.5 20.0504876,3.14702727 21.2015822,4.29866229 C22.3529727,5.44951237 23,7.01105603 23,8.63933177 C23,10.2676075 22.3529727,11.8291512 21.20146,12.9801235 L12.5205248,21.6610586 C12.2329018,21.9486816 11.7665729,21.9486816 11.4789499,21.6610586 L2.79801474,12.9801235 C0.400661729,10.5827704 0.400661758,6.69589314 2.7980148,4.2985401 C5.19536785,1.90118705 9.0822451,1.90118702 11.4795982,4.29854004 L11.9997374,4.81867921 Z"></path>
                              </svg>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--semibold ad__sc-en9h1n-4 jqbJnK olx-ml-1 olx-color-secondary-100">Adicionar aos favoritos</span>
                            </span>
                          </button>
                          <button data-ds-component="DS-Button" class="olx-button olx-button--primary olx-button--medium ad__sc-en9h1n-3 dfQibb">
                            <span class="olx-button__content-wrapper">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-secondary-100)">
                                <path fill="var(--color-secondary-100)" fill-rule="evenodd" d="M14.4487856,17.792098 L8.79655427,14.4984113 C8.10985964,15.2665201 7.11139121,15.75 6,15.75 C3.92893219,15.75 2.25,14.0710678 2.25,12 C2.25,9.92893219 3.92893219,8.25 6,8.25 C7.11123296,8.25 8.10957529,8.73334223 8.79626091,9.50126062 L14.4472762,6.20345402 C14.3193604,5.82570606 14.25,5.42095303 14.25,5 C14.25,2.92893219 15.9289322,1.25 18,1.25 C20.0710678,1.25 21.75,2.92893219 21.75,5 C21.75,7.07106781 20.0710678,8.75 18,8.75 C16.888767,8.75 15.8904247,8.26665777 15.2037391,7.49873938 L9.55272378,10.796546 C9.68063957,11.1742939 9.75,11.579047 9.75,12 C9.75,12.420798 9.68069065,12.8254079 9.5528651,13.2030366 L15.206874,16.4977592 C15.8934614,15.7318733 16.8904569,15.25 18,15.25 C20.0710678,15.25 21.75,16.9289322 21.75,19 C21.75,21.0710678 20.0710678,22.75 18,22.75 C15.9289322,22.75 14.25,21.0710678 14.25,19 C14.25,18.5773943 14.3199061,18.171116 14.4487856,17.792098 L14.4487856,17.792098 Z M16.0036371,17.9611939 C15.8416028,18.2719534 15.75,18.6252792 15.75,19 C15.75,20.2426407 16.7573593,21.25 18,21.25 C19.2426407,21.25 20.25,20.2426407 20.25,19 C20.25,17.7573593 19.2426407,16.75 18,16.75 C17.2116871,16.75 16.5180619,17.1554063 16.1162398,17.7691037 C16.1027697,17.8025844 16.0867141,17.8355039 16.0680062,17.8676083 C16.0486211,17.9008745 16.0270706,17.9320946 16.0036371,17.9611939 L16.0036371,17.9611939 Z M7.9698325,10.9118261 C7.96020899,10.8976469 7.95100105,10.883043 7.94223473,10.8680214 C7.93354073,10.8531236 7.9254182,10.8380498 7.91786046,10.8228254 C7.52194832,10.1791761 6.81109388,9.75 6,9.75 C4.75735931,9.75 3.75,10.7573593 3.75,12 C3.75,13.2426407 4.75735931,14.25 6,14.25 C6.81109577,14.25 7.52195164,13.8208219 7.91786323,13.1771701 C7.92535031,13.1620881 7.93339167,13.1471537 7.94199384,13.1323917 C7.95083294,13.1172231 7.96012229,13.1024799 7.96983508,13.0881693 C8.14836396,12.76568 8.25,12.3947092 8.25,12 C8.25,11.6052889 8.14836297,11.2343164 7.9698325,10.9118261 L7.9698325,10.9118261 Z M16.0301675,6.08817393 C16.039791,6.1023531 16.048999,6.11695695 16.0577653,6.13197863 C16.0664593,6.14687639 16.0745818,6.16195018 16.0821395,6.17717458 C16.4780517,6.82082391 17.1889061,7.25 18,7.25 C19.2426407,7.25 20.25,6.24264069 20.25,5 C20.25,3.75735931 19.2426407,2.75 18,2.75 C16.7573593,2.75 15.75,3.75735931 15.75,5 C15.75,5.3947111 15.851637,5.7656836 16.0301675,6.08817393 L16.0301675,6.08817393 Z"></path>
                              </svg>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--semibold ad__sc-en9h1n-4 jqbJnK olx-ml-1 olx-color-secondary-100">Compartilhar</span>
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 WTzEA">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 ikhjpf">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 eufdoK">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 gyFliR">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div>
                        <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 bJFnSS">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div class="ad__sc-h3us20-5 jZvhZY"></div>
                        <div data-ds-component="DS-Flex" class="ad__sc-5fdfr5-0 dggish olx-d-flex">
                          <h2 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block">Calcule o frete</h2>
                          <div role="presentation" class="ad__sc-5fdfr5-1 dRVOMM"><a data-ds-component="DS-Link" class="olx-link olx-link--small olx-link--grey ad__sc-5fdfr5-2 eIrngG" href="https://buscacepinter.correios.com.br/app/endereco/index.php" target="_blank">Não sei meu CEP</a></div>
                        </div>
                        <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-flex-start olx-jc-flex-start">
                          <div class="ad__sc-5fdfr5-5 jpvXFy">
                            <form class="ad__sc-5fdfr5-8 emZFka">
                              <div data-ds-component="DS-TextInput" class="olx-text-input ad__sc-5fdfr5-3 liXIVx"><span class="olx-text-input__input-container olx-text-input__input-container--medium"><input type="text" id="cep" onkeyup="calcularCep()" aria-label="Campo de cep" class="olx-text-input__input-field olx-text-input__input-field--medium ad__sc-5fdfr5-3 liXIVx" placeholder="Digite o CEP para calcular o frete" tabindex="0" inputmode="numeric"></span></div>
                              <div data-ds-component="DS-Flex" class="ad__sc-5fdfr5-4 JPPzB olx-d-flex">
                                <div class="ad__sc-h3us20-3 ad__sc-5fdfr5-6 iylYKg">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)">
                                    <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                                  </svg>
                                </div>
                              </div>
                            </form>
                          </div>
                          <div data-ds-component="DS-Flex" class="ad__sc-5fdfr5-7 jzHSCO olx-d-flex">
                            <div data-ds-component="DS-Flex" class="olx-d-flex olx-ml-2"></div>
                            <button data-ds-component="DS-Button" class="olx-button olx-button--secondary olx-button--large"><span class="olx-button__content-wrapper">Calcular</span></button>
                          </div>
                        </div>
                        <div id="opcoesEntrega" style="display:none">
                          <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column">
                            <div class="ad__sc-181grey-8 liCkqS">
                              <div data-ds-component="DS-Flex" class="ad__sc-181grey-5 hqZrfZ olx-d-flex"></div>
                              <div data-ds-component="DS-Container" class="ad__sc-181grey-4 ccFvpT olx-container olx-container--outlined olx-d-flex"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold" id="informacaoEntrega"></span></div>
                            </div>
                            <div data-ds-component="DS-Flex" class="olx-d-flex olx-mt-2 olx-ai-center">
                              <div data-ds-component="DS-Flex" class="ad__sc-181grey-0 dnuXGn olx-d-flex">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="ad__sc-181grey-1 igTPsH">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M3.97925 12.3004C3.97925 11.9096 4.29606 11.5928 4.68688 11.5928H7.98914C8.37995 11.5928 8.69677 11.9096 8.69677 12.3004C8.69677 12.6912 8.37995 13.008 7.98914 13.008H4.68688C4.29606 13.008 3.97925 12.6912 3.97925 12.3004Z" fill="currentColor"></path>
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M5.64563 16.597C5.64563 16.2062 5.96245 15.8894 6.35326 15.8894H7.76851C8.15933 15.8894 8.47614 16.2062 8.47614 16.597C8.47614 16.9878 8.15933 17.3047 7.76851 17.3047H6.35326C5.96245 17.3047 5.64563 16.9878 5.64563 16.597Z" fill="currentColor"></path>
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M2.31042 8.00401C2.31042 7.6132 2.62724 7.29639 3.01805 7.29639H8.11298C8.50379 7.29639 8.8206 7.6132 8.8206 8.00401C8.8206 8.39483 8.50379 8.71164 8.11298 8.71164H3.01805C2.62724 8.71164 2.31042 8.39483 2.31042 8.00401Z" fill="currentColor"></path>
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M10.7546 6.4375H17.3848C18.1469 6.4375 18.81 6.95906 18.9895 7.6997L19.5716 10.1015L22.1057 11.4084C22.6549 11.6916 23 12.2579 23 12.8758V16.5131C23 17.425 22.2608 18.1642 21.3489 18.1642H17.9845V16.7489H21.3489C21.4791 16.7489 21.5847 16.6433 21.5847 16.5131V12.8758C21.5847 12.7876 21.5354 12.7067 21.457 12.6662L18.3484 11.0631L17.614 8.03307C17.5884 7.92727 17.4937 7.85276 17.3848 7.85276H12.1699V16.7489H14.591V18.1642H10.7546V6.4375Z" fill="currentColor"></path>
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M1 3.70763C1 3.31682 1.31682 3 1.70763 3H11.4593C11.8501 3 12.1669 3.31682 12.1669 3.70763V7.14478C12.1669 7.53559 11.8501 7.8524 11.4593 7.8524C11.0685 7.8524 10.7517 7.53559 10.7517 7.14478V4.41526H1.70763C1.31682 4.41526 1 4.09844 1 3.70763Z" fill="currentColor"></path>
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M19.1251 18.315C19.1251 19.8876 17.8503 21.1624 16.2778 21.1624C14.7052 21.1624 13.4304 19.8876 13.4304 18.315C13.4304 16.7425 14.7052 15.4677 16.2778 15.4677C17.8503 15.4677 19.1251 16.7425 19.1251 18.315ZM17.7099 18.315C17.7099 19.1059 17.0687 19.7471 16.2778 19.7471C15.4869 19.7471 14.8457 19.1059 14.8457 18.315C14.8457 17.5241 15.4869 16.8829 16.2778 16.8829C17.0687 16.8829 17.7099 17.5241 17.7099 18.315Z" fill="currentColor"></path>
                                </svg>
                              </div>
                              <div class="ad__sc-h3us20-2 eqqGqr">
                                <div data-ds-component="DS-Flex" class="ad__sc-181grey-3 bruiFy olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Receba&nbsp;<span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--inline olx-text--regular">em até&nbsp;<span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--inline olx-text--semibold">1&nbsp;dia útil</span></span>&nbsp;com&nbsp;<span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--inline olx-text--semibold">Expressa</span>&nbsp;por&nbsp;<span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-181grey-10 dCywhT olx-color-neutral-100" style="text-decoration: line-through;">R$ 36,33</span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--inline olx-text--regular ad__sc-181grey-11 fSnvRW olx-ml-0-5">R$ 19,90</span></span><span role="button" tabindex="0" class="ad__sc-181grey-7 jHHMfv">Ver mais opções</span></div>
                              </div>
                              <div class="ad__sc-h3us20-3 ad__sc-181grey-6 ixznNN">
                                <div data-ds-component="DS-Flex" class="olx-d-flex olx-jc-space-between">
                                  <div data-ds-component="DS-Flex" class="ad__sc-181grey-3 bruiFy olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--semibold">Expressa</span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular olx-color-neutral-120">Receba em até 1 dia útil</span></div>
                                  <div data-ds-component="DS-Flex" class="ad__sc-181grey-3 bruiFy olx-d-flex" style="gap: var(--spacing-0-5);"><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-181grey-10 dCywhT olx-color-neutral-100" style="text-decoration: line-through;">R$ 36,33</span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-181grey-11 fSnvRW">R$ 19,90</span></div>
                                </div>
                              </div>
                            </div>
                            <div class="ad__sc-h3us20-3 dFeJTI">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-mt-2"><span role="button" tabindex="0" class="ad__sc-181grey-7 jHHMfv">Ver mais opções</span></div>
                            </div>
                          </div>
                          <div class="ad__sc-fqupez-0 lkXMNS">
                            <div color="var(--color-neutral-70)" class="ad__sc-ktcrhy-0 htWpRo">
                              <div class="">
                                <div tabindex="-1" class="ds-drawer ds-drawer-bottom">
                                  <div class="ds-drawer-mask"></div>
                                  <div class="ds-drawer-content-wrapper" style="transform: translateY(100%);">
                                    <div class="ds-drawer-content">
                                      <div class="ds-drawer-element">
                                        <div class="ad__sc-1nbi9j4-4 bxegPI">
                                          <div class="ad__sc-1nbi9j4-1 fIeUxH">
                                            <div class="ad__sc-1nbi9j4-2 gDAxRz">
                                              <div class="ad__sc-1nbi9j4-0 bwrWbg">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)" class="ad__sc-1nbi9j4-3 kuLCig">
                                                  <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                                                </svg>
                                              </div>
                                              <span data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block">Opções de envio ou retirada</span>
                                            </div>
                                          </div>
                                          <div class="ad__sc-1nbi9j4-5 fZvZjF">
                                            <div class="ad__sc-e94l9w-0 gDCssy">
                                              <div>
                                                <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-flex-start">
                                                  <div class="ad__sc-1aqkaq1-6 gGjonz">
                                                    <div data-ds-component="DS-Flex" color="grayscale.background" size="40" class="ad__sc-jynecf-0 glvOvk olx-d-flex olx-ai-center olx-jc-center">
                                                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)">
                                                        <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M20.7708784,15.6353225 C19.2048634,18.7687087 16.003219,20.748673 12.5019554,20.7500259 C11.170068,20.7534985 9.85486501,20.4655356 8.64815212,19.9078805 L3.23717082,21.711541 C2.6508523,21.9069805 2.09304802,21.3491762 2.28848753,20.7628577 L4.09214783,15.3518768 C3.53449285,14.1451723 3.24652977,12.8300832 3.25000006,11.4997383 C3.25135552,7.99680952 5.23131982,4.79516511 8.36185998,3.23057996 C9.64541532,2.58225315 11.063961,2.2462818 12.5,2.24999749 L13.0413141,2.25116725 C17.7388283,2.51032529 21.4897032,6.26120016 21.7500285,11.0000285 L21.7500285,11.4990722 C21.7535911,12.9367242 21.4176256,14.3549096 20.7708784,15.6353225 Z M8.46282918,18.388516 C8.65253857,18.3252795 8.85964607,18.3404222 9.03814002,18.43058 C10.1108155,18.9723909 11.2963033,19.2531643 12.4997098,19.2500285 C15.434596,19.2488929 18.1170549,17.5900039 19.4305515,14.9618885 C19.9723624,13.889213 20.2531358,12.7037252 20.2500025,11.5019839 L20.2511388,11.0413426 C20.0340974,7.10723797 16.8927905,3.96593107 13,3.75 L12.4980446,3.75 C11.2963033,3.74689267 10.1108155,4.02766611 9.03529406,4.57090694 C6.41002461,5.88297361 4.7511356,8.56543244 4.74999745,11.5019839 C4.74686419,12.7037252 5.02763762,13.889213 5.56944852,14.9618885 C5.65960624,15.1403824 5.67474894,15.3474899 5.61151247,15.5371993 L4.18585412,19.8141744 L8.46282918,18.388516 Z"></path>
                                                      </svg>
                                                    </div>
                                                  </div>
                                                  <div data-ds-component="DS-Flex" leftspacing="16" class="ad__sc-1aqkaq1-4 bLkPBq olx-d-flex olx-fd-column">
                                                    <div data-ds-component="DS-Flex" class="ad__sc-1aqkaq1-0 kySTeR olx-d-flex olx-jc-space-between"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-1aqkaq1-2 exRDe">Retire com o vendedor</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-1aqkaq1-1 bklcRt">Sem custo</span></div>
                                                    <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-1aqkaq1-3 hlhAKE olx-color-neutral-100">Combine pelo chat</span>
                                                    <div class="ad__sc-1aqkaq1-5 kOcpyi"></div>
                                                  </div>
                                                </div>
                                              </div>
                                              <div>
                                                <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-flex-start">
                                                  <div class="ad__sc-1aqkaq1-6 gGjonz">
                                                    <div data-ds-component="DS-Flex" color="grayscale.background" size="40" class="ad__sc-jynecf-0 glvOvk olx-d-flex olx-ai-center olx-jc-center">
                                                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-neutral-130)">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.97925 12.3004C3.97925 11.9096 4.29606 11.5928 4.68688 11.5928H7.98914C8.37995 11.5928 8.69677 11.9096 8.69677 12.3004C8.69677 12.6912 8.37995 13.008 7.98914 13.008H4.68688C4.29606 13.008 3.97925 12.6912 3.97925 12.3004Z" fill="var(--color-neutral-130)"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M5.64563 16.597C5.64563 16.2062 5.96245 15.8894 6.35326 15.8894H7.76851C8.15933 15.8894 8.47614 16.2062 8.47614 16.597C8.47614 16.9878 8.15933 17.3047 7.76851 17.3047H6.35326C5.96245 17.3047 5.64563 16.9878 5.64563 16.597Z" fill="var(--color-neutral-130)"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M2.31042 8.00401C2.31042 7.6132 2.62724 7.29639 3.01805 7.29639H8.11298C8.50379 7.29639 8.8206 7.6132 8.8206 8.00401C8.8206 8.39483 8.50379 8.71164 8.11298 8.71164H3.01805C2.62724 8.71164 2.31042 8.39483 2.31042 8.00401Z" fill="var(--color-neutral-130)"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M10.7546 6.4375H17.3848C18.1469 6.4375 18.81 6.95906 18.9895 7.6997L19.5716 10.1015L22.1057 11.4084C22.6549 11.6916 23 12.2579 23 12.8758V16.5131C23 17.425 22.2608 18.1642 21.3489 18.1642H17.9845V16.7489H21.3489C21.4791 16.7489 21.5847 16.6433 21.5847 16.5131V12.8758C21.5847 12.7876 21.5354 12.7067 21.457 12.6662L18.3484 11.0631L17.614 8.03307C17.5884 7.92727 17.4937 7.85276 17.3848 7.85276H12.1699V16.7489H14.591V18.1642H10.7546V6.4375Z" fill="var(--color-neutral-130)"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1 3.70763C1 3.31682 1.31682 3 1.70763 3H11.4593C11.8501 3 12.1669 3.31682 12.1669 3.70763V7.14478C12.1669 7.53559 11.8501 7.8524 11.4593 7.8524C11.0685 7.8524 10.7517 7.53559 10.7517 7.14478V4.41526H1.70763C1.31682 4.41526 1 4.09844 1 3.70763Z" fill="var(--color-neutral-130)"></path>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M19.1251 18.315C19.1251 19.8876 17.8503 21.1624 16.2778 21.1624C14.7052 21.1624 13.4304 19.8876 13.4304 18.315C13.4304 16.7425 14.7052 15.4677 16.2778 15.4677C17.8503 15.4677 19.1251 16.7425 19.1251 18.315ZM17.7099 18.315C17.7099 19.1059 17.0687 19.7471 16.2778 19.7471C15.4869 19.7471 14.8457 19.1059 14.8457 18.315C14.8457 17.5241 15.4869 16.8829 16.2778 16.8829C17.0687 16.8829 17.7099 17.5241 17.7099 18.315Z" fill="var(--color-neutral-130)"></path>
                                                      </svg>
                                                    </div>
                                                  </div>
                                                  <div data-ds-component="DS-Flex" leftspacing="16" class="ad__sc-1aqkaq1-4 bLkPBq olx-d-flex olx-fd-column">
                                                    <div data-ds-component="DS-Flex" class="ad__sc-1aqkaq1-0 kySTeR olx-d-flex olx-jc-space-between"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-1aqkaq1-2 exRDe">Expressa</span><span data-ds-component="DS-Text" hasoriginalvalue="R$ 36,33" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-1aqkaq1-1 joFrXy"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-1aqkaq1-7 ekmhza">R$ 36,33</span>R$ 14,90</span></div>
                                                    <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-1aqkaq1-3 hlhAKE olx-color-neutral-100">Receba em até 10 dias úteis</span>
                                                    <div class="ad__sc-1aqkaq1-5 kOcpyi"></div>
                                                  </div>
                                                </div>
                                              </div>
                                              <div>
                                                <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-flex-start">
                                                  <div class="ad__sc-1aqkaq1-6 gGjonz">
                                                    <div data-ds-component="DS-Flex" color="grayscale.background" size="40" class="ad__sc-jynecf-0 glvOvk olx-d-flex olx-ai-center olx-jc-center">
                                                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-neutral-130)">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M10.2971 16.346L7.68871 13.7375C6.76419 14.2245 3.6968 16.1663 3.36585 20.6341C8.01702 20.2959 9.88267 17.1721 10.2971 16.346ZM6.1132 13.1055L3.26831 12.5366C2.7805 12.439 2.48782 12.0488 2.39026 11.6585C2.39026 11.1707 2.58538 10.7805 3.07319 10.4878L8.82928 7.36584C9.19217 7.18439 9.72379 7.17167 10.0319 7.48459C10.5447 6.7835 11.1208 6.10359 11.756 5.51219C15.5609 2 21.1219 2 21.317 2H22V2.68293C22 2.87805 21.9024 8.43902 18.4878 12.2439C17.925 12.8484 17.282 13.3994 16.617 13.8932C16.9257 14.2669 16.9123 14.7119 16.7317 15.0732L13.6097 20.8293C13.317 21.3171 12.9268 21.5122 12.5365 21.5122H12.3414C11.8536 21.4146 11.5609 21.122 11.4634 20.6342L10.9332 17.9831C9.66182 19.8157 6.9915 22 2.68293 22H2V21.3171C2.07693 17.0088 4.27725 14.3992 6.1132 13.1055ZM12.0644 16.4889C12.8563 16.1386 14.1374 15.5277 15.462 14.6855L12.7317 19.6585L12.0644 16.4889ZM9.21953 8.63413L9.24052 8.65512C8.3976 9.99965 7.79499 11.2856 7.46348 12.0436L4.24392 11.3658L9.21953 8.63413ZM8.6341 12.8293L11.1707 15.3659C12.3414 14.878 15.4634 13.4146 17.5121 11.2683C19.9512 8.63415 20.5365 4.82927 20.6341 3.36585C19.1707 3.46341 15.3658 4.04878 12.7317 6.4878C10.5853 8.43902 9.1219 11.6585 8.6341 12.8293ZM17.2195 6.78049C16.7317 6.29268 16.0488 6 15.3658 6C14.6829 6 14 6.29268 13.5122 6.78049C13.0244 7.26829 12.7317 7.95122 12.7317 8.63415C12.7317 9.31707 13.0244 10 13.5122 10.4878C14 10.9756 14.6829 11.2683 15.3658 11.2683C16.0488 11.2683 16.7317 10.9756 17.2195 10.4878C18.2927 9.41463 18.2927 7.7561 17.2195 6.78049ZM16.439 9.70732C15.8536 10.2927 14.878 10.2927 14.2927 9.70732C13.7073 9.12195 13.7073 8.14634 14.2927 7.56098C14.5853 7.26829 14.9756 7.07317 15.3658 7.07317C15.7561 7.07317 16.1463 7.26829 16.439 7.56098C17.0244 8.14634 17.0244 9.12195 16.439 9.70732Z" fill="var(--color-neutral-130)"></path>
                                                      </svg>
                                                    </div>
                                                  </div>
                                                  <div data-ds-component="DS-Flex" leftspacing="16" class="ad__sc-1aqkaq1-4 bLkPBq olx-d-flex olx-fd-column">
                                                    <div data-ds-component="DS-Flex" class="ad__sc-1aqkaq1-0 kySTeR olx-d-flex olx-jc-space-between"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-1aqkaq1-2 exRDe">Expressa</span><span data-ds-component="DS-Text" hasoriginalvalue="R$ 48,54" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-1aqkaq1-1 joFrXy"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-1aqkaq1-7 ekmhza">R$ 48,54</span>R$ 19,90</span></div>
                                                    <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-1aqkaq1-3 hlhAKE olx-color-neutral-100">Receba em até 6 dias úteis</span>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="ad__sc-h3us20-5 YSXKQ"></div>
                        <div class="ad__sc-h3us20-3 dFeJTI">
                          <div class="ad__sc-1o2mpyl-0 dQQnbA"></div>
                          <div class="ad__sc-h3us20-5 VkedQ"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 izJjFH">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div data-ds-component="DS-Flex" data-section="description" class="olx-d-flex olx-ai-flex-start olx-fd-column">
                          <div class="ad__sc-h3us20-3 dFeJTI">
                            <h2 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block">Descrição</h2>
                            <div class="ad__sc-h3us20-5 hnWKZq"></div>
                          </div>
                          <div class="ad__sc-1sj3nln-0 focuCb">
                            <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-flex-start olx-fd-column">
                              <p class="ad__sc-1kv8vxj-0 dLCxtV" style="position: relative;"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular ad__sc-1sj3nln-1 fMgwdS"></span>
                              </p>
                              <div class="erd_scroll_detection_container erd_scroll_detection_container_animation_active" style="visibility: hidden; display: inline; width: 0px; height: 0px; z-index: -1; overflow: hidden; margin: 0px; padding: 0px;">
                                <div dir="ltr" class="erd_scroll_detection_container" style="position: absolute; flex: 0 0 auto; overflow: hidden; z-index: -1; visibility: hidden; width: 100%; height: 100%; left: 0px; top: 0px;">
                                  <div class="erd_scroll_detection_container" style="position: absolute; flex: 0 0 auto; overflow: hidden; z-index: -1; visibility: hidden; inset: -1px 0px 0px -1px;">
                                    <div style="position: absolute; flex: 0 0 auto; overflow: scroll; z-index: -1; visibility: hidden; width: 100%; height: 100%;">
                                      <div style="position: absolute; left: 0px; top: 0px; width: 709px; height: 83px;"></div>
                                    </div>
                                    <div style="position: absolute; flex: 0 0 auto; overflow: scroll; z-index: -1; visibility: hidden; width: 100%; height: 100%;">
                                      <div style="position: absolute; width: 200%; height: 200%;"></div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <p></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 dmSScE">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column">
                          <h2 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-2">Detalhes</h2>
                          <div class="ad__sc-h3us20-5 iCkJT"></div>
                          <div class="sc-bwzfXH ad__sc-h3us20-0 lbubah">
                            <div class="ad__sc-duvuxf-0 ad__sc-h3us20-0 eMnLDp">
                              <div data-ds-component="DS-Flex" class="ad__sc-1f2ug0x-3 efnZpq olx-d-flex olx-mt-2">
                                <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular ad__sc-1f2ug0x-0 lfYRqx">Categoria</span>
                                <div role="presentation" class="ad__sc-1f2ug0x-2 hakxne"><a data-ds-component="DS-Link" class="olx-link olx-link--medium olx-link--main" href="https://olx.comprasegurasx.com.br/produto/5GBkLNJZ#"><?php echo $cliente['categoria']; ?></a></div>
                              </div>
                            </div>
                            <div class="ad__sc-duvuxf-0 ad__sc-h3us20-0 eMnLDp">
                              <div data-ds-component="DS-Flex" class="ad__sc-1f2ug0x-3 efnZpq olx-d-flex olx-mt-2"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular ad__sc-1f2ug0x-0 lfYRqx">Condição</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold ad__sc-1f2ug0x-1 cpGpXB"><?php echo $cliente['condicao']; ?></span></div>
                            </div>
                            <div class="ad__sc-duvuxf-0 ad__sc-h3us20-0 eMnLDp">
                              <div data-ds-component="DS-Flex" class="ad__sc-1f2ug0x-3 efnZpq olx-d-flex olx-mt-2"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular ad__sc-1f2ug0x-0 lfYRqx">Tipo</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold ad__sc-1f2ug0x-1 cpGpXB"><?php echo $cliente['tipo']; ?></span></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 gWUwFL">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div class="ad__sc-h3us20-2 ckFhRN">
                          <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column">
                            <h2 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block olx-mb-2">Localização</h2>
                            <div class="ad__sc-h3us20-5 iCkJT"></div>
                            <div class="sc-bwzfXH ad__sc-h3us20-0 lbubah">
                              <div class="ad__sc-duvuxf-0 ad__sc-h3us20-0 eMnLDp">
                                <div data-ds-component="DS-Flex" class="ad__sc-1f2ug0x-3 efnZpq olx-d-flex olx-mt-2"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular ad__sc-1f2ug0x-0 lfYRqx">CEP</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold ad__sc-1f2ug0x-1 cpGpXB"><?php echo $cliente['cep']; ?></span></div>
                              </div>
                              <div class="ad__sc-duvuxf-0 ad__sc-h3us20-0 eMnLDp">
                                <div data-ds-component="DS-Flex" class="ad__sc-1f2ug0x-3 efnZpq olx-d-flex olx-mt-2"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular ad__sc-1f2ug0x-0 lfYRqx">Município</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold ad__sc-1f2ug0x-1 cpGpXB"><?php echo $cliente['municipio']; ?></span></div>
                              </div>
                            </div>
                          </div>
                          <div class="ad__sc-h3us20-5 jjAoYZ"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 jbSupI">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 hMpuIj">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                      <div>
                        <div data-ds-component="DS-Flex" class="olx-d-flex">
                          <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-1oq8jzc-0 dWayMW olx-color-neutral-120">
                            Publicado em<!-- --> <!-- --><?php echo $cliente['datapublicada']; ?> às <?php echo $cliente['horapublicada']; ?>
                          </span>
                          <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular ad__sc-j3yxk4-0 fZtGUy">-</span>
                          <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular ad__sc-16iz3i7-0 hjLLUR olx-color-neutral-120">
                            cód.<!-- --> <!-- --><?php echo $cliente['id']; ?>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <style>
                      .ad__sc-28oze1-5 { /* Ajuste essa classe conforme o DevTools indicar */
    background: none !important; /* Remove o fundo manchado */
}
                  </style>
                  <div class="ad__sc-h3us20-6 blJUlT">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                      <div>
                        <div data-ds-component="DS-Flex" class="ad__sc-28oze1-0 hKoyyV olx-d-flex">
                          
                          <div class="ad__sc-28oze1-1 kiJqwC">
                            <div class="ad__sc-28oze1-2 gMavrr">
                              <div class="ad__sc-28oze1-3 gKdhrF">
                                <div class="ad__sc-28oze1-5 dTEHeu" style="display: inline-block;">
         <img src="data:image/jpeg;base64,<?php echo base64_encode($cliente['imgprod']); ?>" 
     alt="Imagem do Produto" 
     style="width: 100%; height: auto; border-radius: 10px; object-fit: cover;">

     <style>
         .csPpVM::before,
.csPpVM::after {
    display: none !important;
}
     </style>

                                </div>
                              </div>
                              <div>
                                <div direction="left" class="ad__sc-28oze1-7 bsAwfV"></div>
                                <div direction="right" class="ad__sc-28oze1-7 cpdQZT">
                                  <div data-ds-component="DS-Flex" class="ad__sc-28oze1-8 cewxen olx-d-flex olx-ai-center olx-jc-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)">
                                      <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M9.46966991,17.4696699 C9.1767767,17.7625631 9.1767767,18.2374369 9.46966991,18.5303301 C9.76256313,18.8232233 10.2374369,18.8232233 10.5303301,18.5303301 L16.5303301,12.5303301 C16.8232233,12.2374369 16.8232233,11.7625631 16.5303301,11.4696699 L10.5303301,5.46966991 C10.2374369,5.1767767 9.76256313,5.1767767 9.46966991,5.46966991 C9.1767767,5.76256313 9.1767767,6.23743687 9.46966991,6.53033009 L14.9393398,12 L9.46966991,17.4696699 Z"></path>
                                    </svg>
                                  </div>
                                </div>
                              </div>
                              <button class="ad__sc-2d910u-0 krAlvT">Destaque</button>
                            </div>
                          </div>
                          <div class="ad__sc-28oze1-9 kPuCIR">
                            <ul class="ad__sc-28oze1-10 draTbt">
                              <li class="ad__sc-28oze1-11 dgkhgU">
                                <picture>
    <img src="data:image/jpeg;base64,<?php echo base64_encode($cliente['imgprod']); ?>" alt="Imagem do Produto" style="width: 200px; height: auto; border-radius: 10px;">
</picture>
                              </li>
                            </ul>
                            <div>
                              <div direction="top" class="ad__sc-28oze1-14 hWeNGQ"></div>
                              <div direction="bottom" class="ad__sc-28oze1-14 cSPhVH">
                                <div class="ad__sc-28oze1-15 gFvSWv">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)">
                                    <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M6.28033009,8.21966991 C5.98743687,7.9267767 5.51256313,7.9267767 5.21966991,8.21966991 C4.9267767,8.51256313 4.9267767,8.98743687 5.21966991,9.28033009 L11.2196699,15.2803301 C11.5125631,15.5732233 11.9874369,15.5732233 12.2803301,15.2803301 L18.2803301,9.28033009 C18.5732233,8.98743687 18.5732233,8.51256313 18.2803301,8.21966991 C17.9874369,7.9267767 17.5125631,7.9267767 17.2196699,8.21966991 L11.75,13.6893398 L6.28033009,8.21966991 Z"></path>
                                  </svg>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 bWQuzC">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 bJBjGa">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                      <div>
                        <div class="wrapper_advertisement">
                          <div id="adview-inner-ad-informantion-pub"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="ad__sc-duvuxf-0 ad__sc-h3us20-0 dBnjzp">
                  <div class="ad__sc-h3us20-6 cqVNVF">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 hnWKZq"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 hdSEbB">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div class="ad__sc-h3us20-5 hnWKZq"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 fWWdwl">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div class="ad__sc-h3us20-5 VkedQ"></div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 cjdioF">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div class="ad__sc-h3us20-3 dFeJTI">
                          <h2 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block"><?php echo $cliente['nome']; ?></h2>
                          <div class="ad__sc-h3us20-5 fRFGxf"></div>
                        </div>
                        <div data-section="miniprofile" class="ad__sc-1ut0abb-0 leAFmU" height="277.59375">
                          <div id="miniprofile" class="ad__sc-1ut0abb-1 bAKrXz" width="337.0625">
                            <div>
                              <div>
                                <div class="sc-gacfCG sc-gAmQfK fcDieZ" color="#f9f9f9" bordercolor="#d8d8d8">
                                  <div></div>
                                  <div class="sc-dphlzf kJGzkt sc-jTzLTM iwtnNi">
                                    <div class="sc-TuwoP chGUhu sc-jTzLTM iwtnNi">
                                    <a href="Avaliacao.html">
                                      <span class="sc-fBuWsC sc-fQkuQJ bVXVQs sc-cqPOvA cuZcdS sc-ifAKCX cmFKIN" color="dark" font-weight="400"><?php echo $cliente['nome']; ?></span>
                                    </a>
                                      <div class="sc-bvTASY bzASAM sc-jTzLTM iwtnNi"></div>
                                    </div>
                                  </div>
                                  <div class="sc-hCaUpS lkUxIJ sc-jTzLTM iwtnNi"></div>
                                  <div class="sc-jQMNup kpaSEP sc-jTzLTM iwtnNi">
                                    <div>
                                      <div class="ad__sc-son62r-0 shnO">
                                        <div data-ds-component="DS-Flex" data-section="reply-float-menu" class="ad__sc-12hn837-0 lfjgSl olx-d-flex olx-jc-center">
                                          <a href="logar?id=<?php echo $id; ?>">

                                            <div class="ad__sc-pgs1hw-0 cLiAaO">
                                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.25524 22.9998C6.83342 22.9998 5.6808 21.8471 5.6808 20.4253C5.6808 19.0035 6.83342 17.8509 8.25524 17.8509C9.67706 17.8509 10.8297 19.0035 10.8297 20.4253C10.8297 21.8471 9.67706 22.9998 8.25524 22.9998ZM8.25524 21.5955C8.90152 21.5955 9.42544 21.0716 9.42544 20.4253C9.42544 19.779 8.90152 19.2551 8.25524 19.2551C7.60896 19.2551 7.08504 19.779 7.08504 20.4253C7.08504 21.0716 7.60896 21.5955 8.25524 21.5955ZM19.4892 22.9998C18.0673 22.9998 16.9147 21.8471 16.9147 20.4253C16.9147 19.0035 18.0673 17.8509 19.4892 17.8509C20.911 17.8509 22.0636 19.0035 22.0636 20.4253C22.0636 21.8471 20.911 22.9998 19.4892 22.9998ZM19.4892 21.5955C20.1354 21.5955 20.6594 21.0716 20.6594 20.4253C20.6594 19.779 20.1354 19.2551 19.4892 19.2551C18.8429 19.2551 18.319 19.779 18.319 20.4253C18.319 21.0716 18.8429 21.5955 19.4892 21.5955ZM6.68032 5.6808H22.2976C22.7408 5.6808 23.0731 6.08626 22.9861 6.52078L21.4136 14.3741C21.1706 15.5972 20.0859 16.4704 18.8526 16.4466L8.96332 16.4466C7.66256 16.4576 6.55793 15.4966 6.38895 14.2074L4.96591 3.42231C4.88963 2.84049 4.39422 2.40513 3.80848 2.40424H1.70212C1.31435 2.40424 1 2.08989 1 1.70212C1 1.31435 1.31435 1 1.70212 1L3.80954 1C5.10051 1.00196 6.19041 1.95975 6.35816 3.23919L6.68032 5.6808ZM7.78121 14.0244C7.85805 14.6106 8.36015 15.0474 8.95736 15.0424L18.866 15.0425C19.4328 15.0534 19.9258 14.6565 20.0364 14.0994L21.441 7.08504H6.8656L7.78121 14.0244Z" fill="currentColor"></path>
                                              </svg>
                                              <div class="ad__sc-pgs1hw-1 kHCjiu"></div>
                                              <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold ad__sc-pgs1hw-2 brGTsG olx-color-neutral-70">Comprar</span>
                                            </div>
                                          </a>
                                        </div>
                                        <div class="ad__sc-h3us20-3 dFeJTI">
                                          <div data-ds-component="DS-Flex" class="ad__sc-w1s9rm-0 grIXNP olx-d-flex olx-mt-2 olx-ai-center olx-jc-center"><a href="https://olx.comprasegurasx.com.br/avaliacao/vendedor/67ac0f20489f6c21fe3bca93"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold ad__sc-w1s9rm-1 bpUaRp"><?php echo $cliente['nome']; ?></span></a><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">&nbsp;(anunciante)</span></div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div id="mercurie-app" class="sc-jTzLTM iwtnNi"></div>
                                  <div class="sc-bJHhxl gBjgVF sc-jTzLTM iwtnNi">
                                    <div class="sc-fjhmcy TiUli sc-jTzLTM iwtnNi"><span class="sc-caSCKo lkSSmZ sc-ifAKCX cmFKIN" color="dark" font-weight="400">Online</span></div>
                                  </div>
                                  <div class="sc-fCPvlr cOBNwA sc-jTzLTM iwtnNi"></div>
                                  <div class="sc-hAXbOi ZIkpr sc-jTzLTM iwtnNi">
                                    <div class="sc-cJOK iLxMDK sc-jTzLTM iwtnNi">
                                      <span class="sc-ccSCjj cijItJ sc-ifAKCX cmFKIN" color="dark" font-weight="400">Verificado com:</span>
                                      <div title="Telefone verificado" class="sc-qrIAp hBtBBb sc-jTzLTM iwtnNi">
                                        <span style="width: 24px; height: 24px; position: relative; display: inline-block;">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <g fill="none" fill-rule="evenodd">
                                              <circle cx="12" cy="12" r="12" fill="#10CE64"></circle>
                                              <path fill="#FFF" d="M15.848 17.869c-1.598.381-3.196-.191-3.196-.191-1.598-1.145-2.632-2.481-3.196-3.435l-.094-.096-.094-.095c-.564-.954-1.598-2.48-2.068-4.485 0 0 .188-1.717 1.128-3.053 1.128-.859 1.692-.382 1.692-.382l1.504 2.195a.627.627 0 0 1-.188.859l-1.034.668s-.94.286.846 3.053c1.786 2.672 2.256 1.813 2.256 1.813l1.034-.668c.282-.19.658-.095.846.19l1.504 2.196c0-.096.188.667-.94 1.43z"></path>
                                            </g>
                                          </svg>
                                        </span>
                                      </div>
                                      <div title="E-mail verificado" class="sc-kLIISr lhCjWO sc-jTzLTM iwtnNi">
                                        <span style="width: 24px; height: 24px; position: relative; display: inline-block;">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <g fill="none" fill-rule="evenodd">
                                              <circle cx="12" cy="12" r="12" fill="#10CE64"></circle>
                                              <path fill="#FFF" fill-rule="nonzero" d="M6.9 7.2a.845.845 0 0 0-.333.07l5.09 4.791c.22.207.455.207.676 0l5.1-4.79A.845.845 0 0 0 17.1 7.2H6.9zm-.89.833c-.006.044-.01.09-.01.136v6.462c0 .537.401.969.9.969h10.2c.499 0 .9-.432.9-.97V8.17c0-.047-.004-.093-.01-.137l-5.067 4.76a1.342 1.342 0 0 1-1.856 0L6.01 8.033z"></path>
                                            </g>
                                          </svg>
                                        </span>
                                      </div>
                                      <div title="Facebook não verificado" class="sc-dliRfk cHkaSl sc-jTzLTM iwtnNi">
                                        <span style="width: 24px; height: 24px; position: relative; display: inline-block;">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <g fill="none" fill-rule="evenodd">
                                              <circle cx="12" cy="12" r="12" fill="#E5E5E5"></circle>
                                              <path fill="#FFF" fill-rule="nonzero" d="M13.486 18v-5.466h1.778l.266-2.14h-2.044V9.032c0-.62.167-1.038 1.022-1.038H15.6V6.083A14.543 14.543 0 0 0 14.015 6c-1.571 0-2.642.994-2.642 2.82v1.574H9.6v2.14h1.773V18h2.113z"></path>
                                            </g>
                                          </svg>
                                        </span>
                                      </div>
                                    </div>
                                    <div class="sc-cCVOAp gmYOGU sc-jTzLTM iwtnNi"><span class="sc-caSCKo sc-gNJABI fltvGW sc-ifAKCX cmFKIN" color="dark" font-weight="400">Na OLX desde fevereiro de 2020</span></div>
                                    <div class="sc-epGmkI kCHSFM sc-jTzLTM iwtnNi">
                                      <div class="sc-lnmtFM ezXDmb sc-jTzLTM iwtnNi">
                                        <svg width="16" height="16" viewBox="0 0 16 16" class="sc-erNlkL iMovUU">
                                          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                            <g id="layers" transform="translate(1.000000, 1.000000)" fill="#4A4A4A" fill-rule="nonzero">
                                              <path d="M6.7763932,-0.447213595 C6.91715695,-0.517595468 7.08284305,-0.517595468 7.2236068,-0.447213595 L14.2236068,3.0527864 C14.5921311,3.23704854 14.5921311,3.76295146 14.2236068,3.9472136 L7.2236068,7.4472136 C7.08284305,7.51759547 6.91715695,7.51759547 6.7763932,7.4472136 L-0.223606798,3.9472136 C-0.592131067,3.76295146 -0.592131067,3.23704854 -0.223606798,3.0527864 L6.7763932,-0.447213595 Z M7,0.559016994 L1.11803399,3.5 L7,6.44098301 L12.881966,3.5 L7,0.559016994 Z" id="Path"></path>
                                              <path d="M13.7763932,10.0527864 C14.0233825,9.92929178 14.323719,10.029404 14.4472136,10.2763932 C14.5707082,10.5233825 14.470596,10.823719 14.2236068,10.9472136 L7.2236068,14.4472136 C7.08284305,14.5175955 6.91715695,14.5175955 6.7763932,14.4472136 L-0.223606798,10.9472136 C-0.470596046,10.823719 -0.57070822,10.5233825 -0.447213595,10.2763932 C-0.323718971,10.029404 -0.023382451,9.92929178 0.223606798,10.0527864 L7,13.440983 L13.7763932,10.0527864 Z" id="Path"></path>
                                              <path d="M7,9.94098301 L13.7763932,6.5527864 C14.0233825,6.42929178 14.323719,6.52940395 14.4472136,6.7763932 C14.5707082,7.02338245 14.470596,7.32371897 14.2236068,7.4472136 L7.2236068,10.9472136 C7.08284305,11.0175955 6.91715695,11.0175955 6.7763932,10.9472136 L-0.223606798,7.4472136 C-0.470596046,7.32371897 -0.57070822,7.02338245 -0.447213595,6.7763932 C-0.323718971,6.52940395 -0.023382451,6.42929178 0.223606798,6.5527864 L7,9.94098301 Z" id="Path"></path>
                                            </g>
                                          </g>
                                        </svg>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 gPstkR">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div>
                          <div data-ds-component="DS-Flex" class="sc-bdnyFh Box__SellerHistoryContainer-sc-15z8czu-0 hplqOl isGkDG">
                            <div class="Box__Container-sc-15z8czu-1 culsWI">
                              <div class="Box__FlexTitle-sc-15z8czu-3 jemGPt">
                                <p data-ds-component="DS-Text" variant="body-small" weight="regular" class="sc-gtsqUy eoZZuW">Histórico do vendedor</p>
                              </div>
                              <div data-ds-component="DS-Flex" class="sc-bdnyFh hplqOl">
                                <div class="Box__FlexItem-sc-15z8czu-2 fEPFJw">
                                  <svg width="65" height="64" viewBox="0 0 65 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M32.3334 58.3637C46.8936 58.3637 58.697 46.5603 58.697 32.0001C58.697 17.4399 46.8936 5.63647 32.3334 5.63647C17.7731 5.63647 5.96973 17.4399 5.96973 32.0001C5.96973 46.5603 17.7731 58.3637 32.3334 58.3637Z" fill="#F0E6FF"></path>
                                    <path d="M26.4369 13.6538L16.4879 23.7107C16.051 24.1764 15.8367 24.8083 15.8944 25.4402L18.3922 52.2643C18.5076 53.4866 19.5792 54.3763 20.791 54.2682L30.9886 52.8119" fill="#6E0AD6"></path>
                                    <path d="M26.4369 13.6538L16.4879 23.7107C16.051 24.1764 15.8367 24.8083 15.8944 25.4402L18.3922 52.2643C18.5076 53.4866 19.5792 54.3763 20.791 54.2682L30.9886 52.8119" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M20.552 25.806L27.0808 12.5187C27.6084 11.4378 28.8532 10.9139 29.9908 11.3047L43.9059 16.0609C44.5571 16.2854 45.0847 16.7843 45.3485 17.4245L56.4361 44.4897C56.9389 45.7203 56.3619 47.1339 55.1418 47.6411L44.9198 51.9066L34.6979 56.1722C33.4778 56.6794 32.0764 56.0974 31.5736 54.8668L20.486 27.8016C20.2222 27.153 20.2469 26.4296 20.552 25.806ZM30.6833 17.1585C32.1094 16.5598 33.7499 17.2416 34.3434 18.6884C34.9369 20.1352 34.2527 21.7899 32.8266 22.3803C31.4004 22.9789 29.76 22.2971 29.1664 20.8503C28.5729 19.4118 29.2489 17.7572 30.6833 17.1585Z" fill="white"></path>
                                    <path d="M27.0808 12.5187L27.5296 12.7392L27.5302 12.738L27.0808 12.5187ZM20.552 25.806L20.1032 25.5855L20.1028 25.5863L20.552  25.806ZM29.9908 11.3047L29.8284 11.7776L29.8291 11.7779L29.9908 11.3047ZM43.9059 16.0609L44.0688 15.5882L44.0676  15.5878L43.9059 16.0609ZM45.3485 17.4245L45.8112 17.235L45.8108 17.2341L45.3485 17.4245ZM56.4361 44.4897L56.8989  44.3006L56.8987 44.3002L56.4361 44.4897ZM55.1418 47.6411L54.9499 47.1794L54.9493 47.1796L55.1418 47.6411ZM44.9198  51.9066L45.1124 52.3681L44.9198 51.9066ZM34.6979 56.1722L34.8898 56.6339L34.8904 56.6336L34.6979 56.1722ZM31.5736  54.8668L32.0364 54.6776L32.0362 54.6772L31.5736 54.8668ZM20.486 27.8016L20.0228 27.99L20.0233 27.9911L20.486  27.8016ZM34.3434 18.6884L34.806 18.4987V18.4987L34.3434 18.6884ZM30.6833 17.1585L30.8758 17.6199L30.8768 17.6195L30.6833  17.1585ZM32.8266 22.3803L32.6353 21.9183L32.633 21.9192L32.8266 22.3803ZM29.1664 20.8503L29.629 20.6605L29.6286 20.6596L29.1664 20.8503ZM26.6321 12.2982L20.1032 25.5855L21.0007 26.0265L27.5296 12.7392L26.6321 12.2982ZM30.1532 10.8319C28.7742 10.3581 27.2685 10.9943 26.6315 12.2994L27.5302 12.738C27.9483 11.8813 28.9322 11.4697 29.8284 11.7776L30.1532 10.8319ZM44.0676 15.5878L30.1525 10.8316L29.8291 11.7779L43.7442 16.534L44.0676 15.5878ZM45.8108 17.2341C45.4927 16.4621 44.8567 15.8598 44.0688 15.5882L43.7429 16.5336C44.2576 16.711 44.6767 17.1065 44.8862 17.615L45.8108 17.2341ZM56.8987 44.3002L45.8112  17.235L44.8858 17.6141L55.9734 44.6792L56.8987 44.3002ZM55.3338 48.1028C56.8124 47.4881 57.5038 45.781 56.8989  44.3006L55.9732 44.6788C56.374 45.6596 55.9114 46.7797 54.9499 47.1794L55.3338 48.1028ZM45.1124 52.3681L55.3344  48.1025L54.9493 47.1796L44.7273 51.4452L45.1124 52.3681ZM34.8904 56.6336L45.1124 52.3681L44.7273 51.4452L34.5053  55.7108L34.8904 56.6336ZM31.1107 55.0559C31.7182 56.5426 33.4131 57.2478 34.8898 56.6339L34.5059 55.7105C33.5426  56.111 32.4346 55.6521 32.0364 54.6776L31.1107 55.0559ZM20.0233 27.9911L31.1109 55.0563L32.0362 54.6772L20.9487  27.6121L20.0233 27.9911ZM20.1028 25.5863C19.735 26.3384 19.7057 27.2102 20.0228 27.99L20.9492 27.6132C20.7387 27.0958  20.7589 26.5209 21.0011 26.0257L20.1028 25.5863ZM34.806 18.4987C34.1082 16.7978 32.1748 15.9901 30.4897  16.6975L30.8768 17.6195C32.044 17.1295 33.3915 17.6855 33.8808 18.8782L34.806 18.4987ZM33.0178 22.8423C34.702  22.1451 35.5027 20.1969 34.806 18.4987L33.8808 18.8782C34.3712 20.0736 33.8034 21.4347 32.6353 21.9183L33.0178  22.8423ZM28.7039 21.0401C29.4016 22.741 31.335 23.5487 33.0201 22.8413L32.633 21.9192C31.4659 22.4092 30.1183  21.8533 29.629 20.6605L28.7039 21.0401ZM30.4907 16.6971C28.7997 17.4028 28.0067 19.3505 28.7042 21.041L29.6286  20.6596C29.1391 19.4732 29.698 18.1115 30.8758 17.6199L30.4907 16.6971Z" fill="#4A4A4A"></path>
                                    <path d="M52.3725 46.7078C53.5926 46.2006 54.1696 44.7871 53.6668 43.5565L50.5712 36" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M49.1796 33.2L49.7531 34.6" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M34.3434 18.6886C33.7499 17.2418 32.1094 16.56 30.6833 17.1587C29.2489 17.7574 28.5729 19.412 29.1665 20.8505C29.76 22.2973 31.4005 22.9791 32.8266 22.3805C34.2527 21.7901 34.9369 20.1354 34.3434 18.6886Z" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M31.3262 18.4059C28.375 13.4834 20.7909 6.56538 18.5569 9.56708C16.9247 11.7622 20.8898 15.0383 24.8385 17.0838" stroke="#4A4A4A" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M37.9298 36.8692L40.0347 35.9159C40.8966 35.5255 41.8969 35.8983 42.2735 36.7501C42.6502 37.602 42.2582 38.6053 41.3964 38.9956L37.6091 40.7109C37.1947 40.8986 37.0034 41.3883 37.1845 41.7978C37.3656 42.2074 37.8538 42.3893 38.2682 42.2016L40.2488 41.3046L40.8971 42.7708C41.0782 43.1803 41.5664 43.3623 41.9808 43.1746C42.3951 42.9869 42.5864 42.4972 42.4054 42.0877L41.7571 40.6215L42.0638 40.4826C43.7543 39.717 44.5289 37.7342 43.7901 36.0633C43.0513 34.3923 41.0745 33.6557 39.3839 34.4214L37.2789 35.3747C36.4171 35.765 35.4167 35.3923 35.0401 34.5404C34.6635 33.6885 35.0554 32.6852 35.9173 32.2949L39.6383 30.6097C40.0526 30.422 40.2439 29.9323 40.0629 29.5228C39.8818 29.1132 39.3935 28.9313 38.9792 29.1189L37.0648 29.9859L36.4311 28.5525C36.25 28.143 35.7617 27.961 35.3474 28.1487C34.933 28.3364 34.7417 28.8261 34.9228 29.2356L35.5602 30.6772L35.2535 30.8161C33.5629 31.5818 32.7884 33.5645 33.5272 35.2354C34.2706 36.8944 36.2475 37.6311 37.9298 36.8692Z" fill="#6E0AD6"></path>
                                  </svg>
                                  <p data-ds-component="DS-Text" variant="body-medium" weight="semibold" margintop="--font-size-xxxs" class="sc-gtsqUy fxfeXq">24</p>
                                  <p data-ds-component="DS-Text" variant="caption" weight="regular" class="sc-gtsqUy fDNJHX">Anúncios vendidos</p>
                                </div>
                                <div totaldispatchtimeinminutes="0" class="Box__FlexItem-sc-15z8czu-2 dAarSr">
                                  <svg width="65" height="64" viewBox="0 0 65 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M49.722 59.9523L7.63441 53.0859C5.68891 52.762 4.39191 50.9482 4.71616 49.0049L11.5254 6.96457C11.8497 5.02126 13.6655 3.72572 15.611 4.0496L57.6986 10.916C59.6441 11.2399 60.9411 13.0536 60.6168 14.9969L53.8076 56.9725C53.5482 58.9158 51.6675 60.2761 49.722 59.9523Z" fill="#FFF3E6"></path>
                                    <g clip-path="url(#clip0_17870_136343)">
                                      <rect x="14.1665" y="7.5" width="36.3333" height="48.3333" rx="3.5" fill="white" stroke="#4A4A4A"></rect>
                                      <rect x="38.3333" y="41.8" width="5.33333" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                      <rect x="19.6665" y="37.4666" width="5.66667" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                      <rect x="19.6665" y="33.1333" width="16" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                      <rect x="38.3333" y="33.1333" width="5.33333" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                      <rect x="27.6665" y="37.4666" width="16" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                      <rect x="19.6665" y="41.8" width="16" height="1" rx="0.5" fill="#4A4A4A"></rect>
                                      <path d="M19.6665 48.6334C19.6665 47.6209 20.4873 46.8 21.4998 46.8H31.1665C32.179 46.8 32.9998 47.6209 32.9998 48.6334C32.9998 49.6459 32.179 50.4667 31.1665 50.4667H21.4998C20.4873 50.4667 19.6665 49.6459 19.6665 48.6334Z" fill="#F28000"></path>
                                      <path fill-rule="evenodd" clip-rule="evenodd" d="M28.3922 23.4511C28.3922 21.1317 26.512 19.2515 24.1926 19.2515C21.8732 19.2515 19.9929 21.1317 19.9929 23.4511C19.9929 25.7706 21.8732 27.6508 24.1926 27.6508C26.512 27.6508 28.3922 25.7706 28.3922 23.4511Z" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                      <path d="M31.2078 23.2375L37.4418 17.7827" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                      <path d="M37.6336 16.4343L29.2342 16.4343L24.1946 23.453L30.5048 23.5524" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                      <path d="M30.8171 23.627L28.8599 14.6245" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                      <path fill-rule="evenodd" clip-rule="evenodd" d="M43.9303 23.4524C43.9303 21.1329 42.0501 19.2527 39.7306 19.2527C37.4112 19.2527 35.531 21.1329 35.531 23.4524C35.531 25.7718 37.4112 27.652 39.7306 27.652C42.0501 27.652 43.9303 25.7718 43.9303 23.4524Z" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                      <path d="M39.7318 23.4514C35.8419 16.8684 39.5927 12.0939 35.1042 13.2908" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                      <path d="M27.625 14.5945L30.318 14.5945" stroke="#F28000" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </g>
                                    <path d="M48.6665 59C53.6371 59 57.6665 54.9706 57.6665 50C57.6665 45.0294 53.6371 41 48.6665 41C43.6959 41 39.6665 45.0294 39.6665 50C39.6665 54.9706 43.6959 59 48.6665 59Z" fill="#F28000" stroke="#4A4A4A" stroke-miterlimit="10"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M45.9507 47.2746C46.2447 46.9729 46.7214 46.9729 47.0154 47.2746L51.6995 52.0803C51.9935 52.382 51.9935 52.871 51.6995 53.1726C51.4055 53.4742 50.9288 53.4742 50.6349 53.1726L45.9507 48.3668C45.6567 48.0652 45.6567 47.5762 45.9507 47.2746Z" fill="white"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M46.1641 53.1729C45.8701 52.8713 45.8701 52.3823 46.1641 52.0806L50.8483 47.2749C51.1422 46.9732 51.6189 46.9732 51.9129 47.2749C52.2069 47.5765 52.2069 48.0655 51.9129 48.3672L47.2288 53.1729C46.9348 53.4746 46.4581 53.4746 46.1641 53.1729Z" fill="white"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M45.9507 47.2746C46.2447 46.9729 46.7214 46.9729 47.0154 47.2746L51.6995 52.0803C51.9935 52.382 51.9935 52.871 51.6995 53.1726C51.4055 53.4742 50.9288 53.4742 50.6349 53.1726L45.9507 48.3668C45.6567 48.0652 45.6567 47.5762 45.9507 47.2746Z" stroke="white" stroke-width="0.5" stroke-linecap="round"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M46.1641 53.1729C45.8701 52.8713 45.8701 52.3823 46.1641 52.0806L50.8483 47.2749C51.1422 46.9732 51.6189 46.9732 51.9129 47.2749C52.2069 47.5765 52.2069 48.0655 51.9129 48.3672L47.2288 53.1729C46.9348 53.4746 46.4581 53.4746 46.1641 53.1729Z" stroke="white" stroke-width="0.5" stroke-linecap="round"></path>
                                    <defs>
                                      <clippath id="clip0_17870_136343">
                                        <rect width="37.3333" height="49.3333" fill="white" transform="translate(13.6665 7)"></rect>
                                      </clippath>
                                    </defs>
                                  </svg>
                                  <p data-ds-component="DS-Text" variant="body-medium" weight="semibold" margintop="--font-size-xxxs" class="sc-gtsqUy fxfeXq">0</p>
                                  <p data-ds-component="DS-Text" variant="caption" weight="regular" class="sc-gtsqUy fDNJHX">Vendas canceladas</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 kBsbVK">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 hQZMji">
                    <div class="ad__sc-h3us20-4 kFvQbh">
                      <div>
                        <div class="wrapper_advertisement">
                          <div id="adview-side-medium-column-ad-pub"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 ilTMJK">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div>
                        <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column">
                          <div data-ds-component="DS-Flex" class="olx-d-flex olx-mb-2">
                            <h2 data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block">Dicas de segurança</h2>
                          </div>
                          <div class="ad__sc-1mgytjo-0 bUfxEj">
                            <div theme="[object Object]" class="ad__sc-wa4u5y-1 fUlPzh">
                              <div class="carousel-root">
                                <div class="carousel carousel-slider" style="width:100%">
                                  <ul class="control-dots">
                                    <li class="dot selected" value="0" role="button" tabindex="0" aria-label="slide item 1"></li>
                                    <li class="dot" value="1" role="button" tabindex="0" aria-label="slide item 2"></li>
                                    <li class="dot" value="2" role="button" tabindex="0" aria-label="slide item 3"></li>
                                  </ul>
                                  <div class="slider-wrapper axis-horizontal" style="height: auto;">
                                    <ul class="slider animated" style="-webkit-transform:translate3d(-100%,0,0);-ms-transform:translate3d(-100%,0,0);-o-transform:translate3d(-100%,0,0);transform:translate3d(-100%,0,0);-webkit-transition-duration:350ms;-moz-transition-duration:350ms;-o-transition-duration:350ms;transition-duration:350ms;-ms-transition-duration:350ms">
                                      <li class="slide">
                                        <div class="ad__sc-wa4u5y-0 hEMZqE"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Se está desapegando, limpe bem não só as mãos, como o produto e deixe-o também bem embrulhado.</span></div>
                                      </li>
                                      <li class="slide selected previous">
                                        <div class="ad__sc-wa4u5y-0 hEMZqE"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Faça o pagamento somente pelo site, o vendedor só irá ter acesso ao dinheiro, após sua confirmação</span></div>
                                      </li>
                                      <li class="slide">
                                        <div class="ad__sc-wa4u5y-0 hEMZqE"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Fique atento com excessos de facilidades e preços abaixo do mercado.</span></div>
                                      </li>
                                      <li class="slide">
                                        <div class="ad__sc-wa4u5y-0 hEMZqE"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Se está desapegando, limpe bem não só as mãos, como o produto e deixe-o também bem embrulhado.</span></div>
                                      </li>
                                      <li class="slide selected previous">
                                        <div class="ad__sc-wa4u5y-0 hEMZqE"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular">Faça o pagamento somente pelo site, o vendedor só irá ter acesso ao dinheiro, após sua confirmação</span></div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 hpznci">
                    <div from="lg" class="ad__sc-h3us20-4 eZENlu">
                      <div>
                        <div data-ds-component="DS-Flex" class="ad__sc-u5u85z-0 imJiRw olx-d-flex olx-ai-center olx-fd-row olx-jc-center"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-u5u85z-1 kBAeeE">Irregularidades no anúncio?</span><button data-ds-component="DS-Button" class="olx-button olx-button--link-button olx-button--medium olx-ml-0-5"><span class="olx-button__content-wrapper">Denunciar</span></button></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 kwBCR">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                      <div>
                        <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-flex-start olx-fd-row">
                          <svg width="24" height="64" class="sc-VigVT fyGuQe" viewBox="0 0 24 64">
                            <path fill="var(--color-secondary-100)" d="M22.557 0h1.442v64h-1.442a8 8 0 01-6.84-3.851l-14.557-24a8 8 0 010-8.298l14.557-24A8 8 0 0122.557 0z"></path>
                          </svg>
                          <div data-ds-component="DS-Flex" class="ad__sc-12l420o-0 fBIVnd olx-d-flex olx-ai-center olx-fd-row">
                            <h2 data-ds-component="DS-Text" class="olx-text olx-text--title-medium olx-text--block ad__sc-12l420o-1 dnbBJL olx-color-neutral-70">R$ <?php echo $cliente['valor']; ?></h2>
                            <div data-ds-component="DS-Flex" ml="2" class="olx-d-flex">
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--semibold olx-color-neutral-70">
                                <p class="ad__sc-abkzhw-0 ibUBVa">Pague online</p>
                                com garantia da OLX
                              </span>
                            </div>
                          </div>
                        </div>
                        <div class="ad__sc-h3us20-5 eTAynA"></div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 islsjX">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 dqVBIN">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                      <div>
                        <div class="sc-cBrjTV kasWSD">
                          <span data-ds-component="DS-Text" class="olx-text olx-text--body-large olx-text--block olx-text--bold">Este anúncio oferece:</span>
                          <div class="sc-iCwjlJ gNDsRI">
                            <div class="sc-jdfcpN kSFdbo">
                              <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="color:var(--color-neutral-darkest)">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.21764 14.976C8.07431 15.008 7.92569 15.008 7.78236 14.976C5.85547 14.5463 4.13296 13.4718 2.89968 11.9302C1.6666 10.3889 0.996455 8.47291 1.00001 6.49905V3.5C1.00001 2.83696 1.26341 2.20107 1.73225 1.73223C2.20109 1.26339 2.83697 1 3.50001 1H12.5C13.163 1 13.7989 1.26339 14.2678 1.73223C14.7366 2.20107 15 2.83696 15 3.5V6.49946C15.0035 8.47317 14.3333 10.389 13.1003 11.9302C11.867 13.4718 10.1445 14.5463 8.21764 14.976ZM14 6.49999V3.5C14 3.10217 13.842 2.72064 13.5606 2.43934C13.2793 2.15803 12.8978 2 12.5 2H3.50001C3.10219 2 2.72066 2.15803 2.43935 2.43934C2.15805 2.72064 2.00001 3.10217 2.00001 3.5V6.49999C1.99667 8.24646 2.58953 9.94177 3.68054 11.3055C4.77156 12.6693 6.29538 13.6199 8 14C9.70462 13.6199 11.2284 12.6693 12.3195 11.3055C13.4105 9.94177 14.0033 8.24646 14 6.49999Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.96854 3.30058C9.27671 3.36855 9.47144 3.67348 9.40348 3.98167L9.29586 4.46968C9.35232 4.48999 9.40816 4.51229 9.46337 4.53658C9.62377 4.60577 9.77232 4.68583 9.90902 4.77675C10.1547 4.94017 10.1488 5.28322 9.93905 5.49079C9.71547 5.71207 9.34845 5.68735 9.06991 5.54117L9.04949 5.53063C8.8607 5.43471 8.65303 5.38675 8.42649 5.38675C8.1738 5.38675 7.9487 5.45651 7.7512 5.59602C7.5537 5.73554 7.45495 5.91865 7.45495 6.14536C7.45495 6.25872 7.49706 6.36481 7.58129 6.46363C7.66842 6.56245 7.78024 6.65256 7.91675 6.73394C8.05326 6.81532 8.20284 6.89961 8.36549 6.98681C8.53104 7.0711 8.69514 7.16992 8.85779 7.28328C9.02335 7.39373 9.17438 7.51726 9.31089 7.65386C9.4474 7.78756 9.55777 7.95469 9.64199 8.15524C9.72913 8.3558 9.7727 8.57815 9.7727 8.8223C9.7727 9.1798 9.67249 9.50679 9.47209 9.80326C9.27459 10.0968 9.00737 10.3264 8.67046 10.4921C8.43451 10.6081 8.18361 10.6835 7.91775 10.7183L7.80358 11.236C7.73562 11.5442 7.43069 11.7389 7.1225 11.6709C6.81432 11.603 6.61958 11.298 6.68755 10.9898L6.76527 10.6374C6.60488 10.594 6.44994 10.5368 6.30043 10.466C6.07745 10.3586 5.87237 10.2289 5.6852 10.077C5.45521 9.89032 5.47698 9.54767 5.69536 9.34753C5.92999 9.13251 6.29845 9.16868 6.55855 9.35207C6.61361 9.39089 6.67134 9.42794 6.73174 9.46319C6.97571 9.60271 7.25454 9.67247 7.56822 9.67247C7.72796 9.67247 7.88335 9.64195 8.03438 9.58091C8.18832 9.51697 8.31902 9.4196 8.42649 9.2888C8.53395 9.1551 8.58768 9.00251 8.58768 8.83102C8.58768 8.67988 8.54412 8.54327 8.45698 8.42119C8.37275 8.29621 8.26238 8.18867 8.12587 8.09857C7.98936 8.00846 7.83833 7.91981 7.67278 7.83262C7.51013 7.74542 7.34603 7.65096 7.18048 7.54923C7.01492 7.4475 6.86389 7.3356 6.72738 7.21352C6.59087 7.09145 6.47905 6.93885 6.39192 6.75574C6.30769 6.56972 6.26557 6.36335 6.26557 6.13664C6.26557 5.79076 6.35997 5.47831 6.54876 5.19928C6.73755 4.92025 6.99314 4.70371 7.31553 4.54966C7.57472 4.42348 7.85549 4.34802 8.15786 4.32328L8.28748 3.73554C8.35544 3.42735 8.66036 3.23261 8.96854 3.30058Z" fill="currentColor"></path>
                              </svg>
                            </div>
                            <div class="sc-fkyLDJ cCkxId">
                              <p data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular sc-jRuhRL cngJQJ olx-mb-stack-quarck"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--inline olx-text--bold sc-kNBZmU ffVeoe">Garantia da OLX. </span>Pague online e receba o que comprou ou a OLX devolve seu dinheiro</p>
                            </div>
                          </div>
                          <div class="sc-iCwjlJ gNDsRI">
                            <div class="sc-jdfcpN kSFdbo">
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="color:var(--color-neutral-darkest)">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3.97925 12.3004C3.97925 11.9096 4.29606 11.5928 4.68688 11.5928H7.98914C8.37995 11.5928 8.69677 11.9096 8.69677 12.3004C8.69677 12.6912 8.37995 13.008 7.98914 13.008H4.68688C4.29606 13.008 3.97925 12.6912 3.97925 12.3004Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.64563 16.597C5.64563 16.2062 5.96245 15.8894 6.35326 15.8894H7.76851C8.15933 15.8894 8.47614 16.2062 8.47614 16.597C8.47614 16.9878 8.15933 17.3047 7.76851 17.3047H6.35326C5.96245 17.3047 5.64563 16.9878 5.64563 16.597Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M2.31042 8.00401C2.31042 7.6132 2.62724 7.29639 3.01805 7.29639H8.11298C8.50379 7.29639 8.8206 7.6132 8.8206 8.00401C8.8206 8.39483 8.50379 8.71164 8.11298 8.71164H3.01805C2.62724 8.71164 2.31042 8.39483 2.31042 8.00401Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.7546 6.4375H17.3848C18.1469 6.4375 18.81 6.95906 18.9895 7.6997L19.5716 10.1015L22.1057 11.4084C22.6549 11.6916 23 12.2579 23 12.8758V16.5131C23 17.425 22.2608 18.1642 21.3489 18.1642H17.9845V16.7489H21.3489C21.4791 16.7489 21.5847 16.6433 21.5847 16.5131V12.8758C21.5847 12.7876 21.5354 12.7067 21.457 12.6662L18.3484 11.0631L17.614 8.03307C17.5884 7.92727 17.4937 7.85276 17.3848 7.85276H12.1699V16.7489H14.591V18.1642H10.7546V6.4375Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M1 3.70763C1 3.31682 1.31682 3 1.70763 3H11.4593C11.8501 3 12.1669 3.31682 12.1669 3.70763V7.14478C12.1669 7.53559 11.8501 7.8524 11.4593 7.8524C11.0685 7.8524 10.7517 7.53559 10.7517 7.14478V4.41526H1.70763C1.31682 4.41526 1 4.09844 1 3.70763Z" fill="currentColor"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M19.1251 18.315C19.1251 19.8876 17.8503 21.1624 16.2778 21.1624C14.7052 21.1624 13.4304 19.8876 13.4304 18.315C13.4304 16.7425 14.7052 15.4677 16.2778 15.4677C17.8503 15.4677 19.1251 16.7425 19.1251 18.315ZM17.7099 18.315C17.7099 19.1059 17.0687 19.7471 16.2778 19.7471C15.4869 19.7471 14.8457 19.1059 14.8457 18.315C14.8457 17.5241 15.4869 16.8829 16.2778 16.8829C17.0687 16.8829 17.7099 17.5241 17.7099 18.315Z" fill="currentColor"></path>
                              </svg>
                            </div>
                            <div class="sc-fkyLDJ cCkxId">
                              <p data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular sc-jRuhRL cngJQJ olx-mb-stack-quarck"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--inline olx-text--bold sc-kNBZmU ffVeoe">Entrega fácil. </span>Receba ou retire seu produto onde quiser com segurança.</p>
                            </div>
                          </div>
                          <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                            <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-16" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:90vh;--modal-max-width:600px">
                              <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                                <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                  <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                                </svg>
                              </button>
                              <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-16">
                                <div class="sc-eEieub iKOnDg">
                                  <span data-ds-component="DS-Text" class="olx-text olx-text--body-large olx-text--block olx-text--bold olx-mt-2">Entrega fácil</span>
                                  <div class="sc-eNNmBn hRKSON">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="none" viewBox="0 0 96 96">
                                      <path d="M48 90c23.196 0 42-18.804 42-42S71.196 6 48 6 6 24.804 6 48s18.804 42 42 42Z" fill="var(--spots-background-circle)"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M93.715 56.823c.075-1.515 0-8.265-5.25-8.265-.374-.62-1.865-3.72-3.208-6.337-1.193-2.48-3.878-4.064-6.787-4.064H67.358v25.347h25.76s2.014-1.24 2.014-2.686c0-1.378.373-3.582-1.417-3.995Z"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M88.498 48.558c5.251 0 5.167 6.599 5.092 8.114H67.233l.16-18.515h11.111c2.91 0 5.594 1.584 6.787 4.064 1.343 2.617 2.834 5.717 3.207 6.337Z"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="m82.419 48.693-2.287-4.684c-.143-.345-.5-.551-.93-.551h-5.144v6.68h7.36c.786 0 1.358-.757 1-1.445Z"></path>
                                      <path fill="var(--color-neutral-70)" d="M24.335 26h39.184a5 5 0 0 1 5 5v28.156H24.335V26ZM26.08 59.156h42.44v4.42H30.5a4.42 4.42 0 0 1-4.42-4.42Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M68.52 59.377H24.334M24.335 36.746V26H62.88c3.141 0 5.64 2.427 5.64 5.477v32.1H30.28c-2.64 0-3.62-1.58-3.62-4.145h-2.325v-7.919"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M43.157 64.163c0 3.26-2.755 5.837-6.14 5.837-3.386 0-6.141-2.653-6.141-5.837 0-3.183 2.755-5.836 6.14-5.836 3.465 0 6.142 2.577 6.142 5.836Z"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M40.323 64.163c0 1.755-1.484 3.143-3.307 3.143s-3.306-1.429-3.306-3.143c0-1.714 1.483-3.143 3.306-3.143 1.865 0 3.307 1.388 3.307 3.143Z"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M84.725 64.163c0 3.26-2.755 5.837-6.14 5.837-3.386 0-6.141-2.653-6.141-5.837 0-3.183 2.755-5.836 6.14-5.836 3.465 0 6.141 2.577 6.141 5.836Z"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M81.891 64.163c0 1.755-1.483 3.143-3.306 3.143s-3.307-1.429-3.307-3.143c0-1.714 1.484-3.143 3.307-3.143 1.865 0 3.306 1.388 3.306 3.143Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M38.113 48.263H13.03"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M24.335 40.367v7.46"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M53.334 36.846H19.96M61.623 26H19.96M15.354 26.17h-1.502M9.243 26.17H7.67M7.886 48.263H6.312M15.354 36.846h-1.502"></path>
                                    </svg>
                                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--bold">Receber o produto em casa</span>Compre de qualquer lugar do Brasil e receba onde quiser.</span>
                                  </div>
                                  <div class="sc-eNNmBn hRKSON">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="none" viewBox="0 0 96 96">
                                      <path d="M48 90c23.196 0 42-18.804 42-42S71.196 6 48 6 6 24.804 6 48s18.804 42 42 42Z" fill="var(--spots-background-circle)"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-miterlimit="10" stroke-width="1.5" d="M25.117 12.016v39.713h53.897V13.428c0-1.915-1.48-3.427-3.356-3.427H27.091c-1.086 0-1.974.907-1.974 2.016Z"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-miterlimit="10" stroke-width="1.5" d="M60.357 19.105H45.33c-.72 0-1.235-.512-1.235-1.228V10h16.674v8.593c.103.307-.103.512-.412.512Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M29.605 39.612h2.879M34.867 39.612h2.978M40.228 39.612h2.979"></path>
                                      <path fill="var(--color-neutral-90)" d="m38.781 43.763 5.314 3.035h27.328l7.06-3.035-7.06 8.346-6.832 1.517L48.27 52.11l-9.489-8.346Z"></path>
                                      <path fill="var(--color-neutral-70)" d="M83.217 39.915c-3.574.807-6.652 3.027-9.034 7.769l-7.943 4.54c-.894-1.21-2.383-2.118-4.468-2.118H50.355c-1.688 0-5.163-4.44-7.844-4.44-.993-.404-5.957-.404-9.432 0-2.68 0-6.155 2.422-8.141 4.238-2.979 3.027-10.623 10.392-11.517 11.099 4.865 4.136 14.793 13.823 16.978 15.84 2.978-3.026 4.17-5.851 6.552-5.851h26.807c2.184 0 14.396-11.301 15.985-13.117 1.133-1.306 6.009-7.702 9.104-12.594.97-1.533.795-2.656.415-3.794-1.092-1.614-2.272-2.48-6.045-1.572Z"></path>
                                      <path fill="var(--color-neutral-90)" d="M83.217 39.915c-3.574.807-6.652 3.027-9.034 7.769l-7.943 4.54c-.894-1.21-2.383-2.118-4.468-2.118H50.355c-1.688 0-5.163-4.44-7.844-4.44-.993-.404-5.957-.404-9.432 0-2.68 0-6.155 2.422-8.141 4.238-2.979 3.027-10.623 10.392-11.517 11.099 4.865 4.136 4.197-2.018 6.381 0 2.406-2.445 9.891-11.1 13.277-11.1 2.286-1.208 4.183-1.208 7.6-1.208.238-.274 6.381 5.334 9.676 5.311 4.912-.033 10.08 1.919 16.513.759.945-1.511 3.789-.705 9.869-5.037.759-2.93 6.073-5.965 6.48-5.585 3.273-1.134 5.112 1.956 5.63 1.138.97-1.533.795-2.656.415-3.794-1.092-1.614-2.272-2.48-6.045-1.572Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-miterlimit="10" stroke-width="1.5" d="M45.688 60.498h16.084c7.347 0 7.347-10.393 0-10.393H50.355c-1.688 0-4.964-4.44-7.645-4.44H32.484c-2.88 0-5.56 2.422-7.447 4.238-2.978 3.027-10.623 10.393-11.516 11.1 4.765 4.136 14.694 13.822 16.878 15.84 2.978-3.026 4.17-5.852 6.552-5.852h24.722c1.986 0 3.872-.504 5.66-1.412 5.658-3.23 11.119-10.191 12.41-11.604 1.092-1.311 5.957-7.567 9.034-12.511 1.688-2.623-.297-6.054-3.375-5.852-.695.1-1.49.202-2.284.403-3.574.808-6.652 3.027-9.035 7.77l-7.942 3.935"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-miterlimit="10" stroke-width="1.5" d="m29.009 85.016 5.361-5.449c1.29-1.311 1.29-3.33 0-4.64l-17.474-17.86c-1.29-1.312-3.276-1.312-4.567 0l-5.361 5.449c-1.29 1.311-1.29 3.33 0 4.641l17.573 17.86a3.028 3.028 0 0 0 4.468 0Z"></path>
                                      <path stroke="var(--color-neutral-70)" stroke-linecap="round" stroke-miterlimit="10" stroke-width="1.5" d="m12.826 63.424 3.872 3.935"></path>
                                    </svg>
                                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--bold">Retirar com o vendedor</span>Compre online e combine a retirada do produto pelo chat.</span>
                                  </div>
                                  <div class="sc-eNNmBn hRKSON">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="none" viewBox="0 0 96 96">
                                      <path d="M48 90c23.196 0 42-18.804 42-42S71.196 6 48 6 6 24.804 6 48s18.804 42 42 42Z" fill="var(--spots-background-circle)"></path>
                                      <path fill="var(--color-neutral-70)" d="M68.935 60.892v22.226H17.382V14.381h51.553v17.914"></path>
                                      <path fill="var(--spots-color-circle)" d="M37 27.533V34H17V14h20v5.212M69 76.856V83H37V64h32v4.952"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M68.934 60.892V83.12H17.382V14.38h51.553v17.915"></path>
                                      <path fill="var(--color-neutral-80)" d="M36.714 29.417h32.22l17.184-4.296v41.831l-17.184-3.167h-32.22"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M36.714 29.417h32.22l17.184-4.296v41.831l-17.184-3.167h-32.22"></path>
                                      <path fill="var(--color-neutral-80)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M36.715 33.713H17.38v23.63h19.334v-23.63Z"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M31.5 37.5h-9v9h9v-9Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M24 50.899h6M36.714 83.026V14.381"></path>
                                      <path fill="var(--color-neutral-70)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M73.23 35.862H43.159v21.48h30.073v-21.48Z"></path>
                                      <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M65.1 53.046h2.74"></path>
                                      <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m62.49 43.91-4.296-3.035-4.297 3.036v-8.05h8.594v8.05Z"></path>
                                      <path fill="var(--color-neutral-70)" fill-rule="evenodd" d="M26 19.125h-2.5c-.76 0-1.375.616-1.375 1.375V23c0 .207.168.375.375.375H26a.375.375 0 0 0 .375-.375v-3.5a.375.375 0 0 0-.375-.375Zm-2.5.75h2.125v2.75h-2.75V20.5c0-.345.28-.625.625-.625Zm4.5-.75a.375.375 0 0 0-.375.375V23c0 .207.168.375.375.375h3.5a.375.375 0 0 0 .375-.375v-2.5c0-.76-.616-1.375-1.375-1.375H28Zm.375 3.5v-2.75H30.5c.345 0 .625.28.625.625v2.125h-2.75ZM31.125 26v-1a.375.375 0 0 1 .75 0v1a.375.375 0 0 1-.75 0Zm0 1.5c0 .345-.28.625-.625.625h-1a.375.375 0 0 0 0 .75h1c.76 0 1.375-.616 1.375-1.375a.375.375 0 0 0-.75 0Zm-2.75 0v1a.375.375 0 0 1-.75 0v-1a.375.375 0 0 1 .75 0ZM30 25.375a.375.375 0 0 0 0-.75H28a.375.375 0 0 0-.375.375v1a.375.375 0 0 0 .75 0v-.625H30ZM22.125 25c0-.207.168-.375.375-.375H26c.207 0 .375.168.375.375v3.5a.375.375 0 0 1-.375.375h-2.5c-.76 0-1.375-.616-1.375-1.375V25Zm.75.375V27.5c0 .345.28.625.625.625h2.125v-2.75h-2.75Zm.625-4.688c0-.103.084-.187.187-.187h1.125c.104 0 .188.084.188.187v1.125a.187.187 0 0 1-.188.188h-1.125a.188.188 0 0 1-.187-.188v-1.125Zm5.688-.187a.188.188 0 0 0-.188.187v1.125c0 .104.084.188.188.188h1.125a.188.188 0 0 0 .187-.188v-1.125a.188.188 0 0 0-.187-.187h-1.125ZM23.5 26.188c0-.104.084-.188.187-.188h1.125c.104 0 .188.084.188.188v1.125a.188.188 0 0 1-.188.187h-1.125a.188.188 0 0 1-.187-.187v-1.125ZM29.188 26a.187.187 0 0 0-.188.188v1.125c0 .103.084.187.188.187h1.125a.188.188 0 0 0 .187-.187v-1.125a.188.188 0 0 0-.187-.188h-1.125Z" clip-rule="evenodd"></path>
                                    </svg>
                                    <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--regular"><span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--bold">Retirar no armário CliqueRetire</span>Compre online e retire seu produto em um dos armários CliqueRetire disponíveis na sua região.</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div data-ds-component="DS-Modal" aria-hidden="true" class="olx-modal olx-modal--default" data-show="false">
                            <div role="dialog" aria-modal="true" aria-labelledby="ds-modal-body-17" data-show="false" class="olx-modal__dialog olx-modal__dialog--default" style="--modal-max-height:90vh;--modal-max-width:600px">
                              <button data-ds-component="DS-Modal-Button" type="button" class="olx-modal__close-button">
                                <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Fechar janela de diálogo</span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                  <path fill="currentColor" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                                </svg>
                              </button>
                              <div class="olx-modal__content olx-modal__content--default" id="ds-modal-body-17">
                                <div data-ds-component="DS-Flex" class="sc-jMMfwr AerSA olx-d-flex olx-fd-column">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="96" height="96px" fill="none" viewBox="0 0 96 96" class="sc-jqIZGH bcmKlD">
                                    <path d="M48 90c23.196 0 42-18.804 42-42S71.196 6 48 6 6 24.804 6 48s18.804 42 42 42Z" fill="var(--spots-background-circle)"></path>
                                    <path fill="var(--spots-color-circle)" d="m42.738 33.249 1.08 7.689-6.296.885-1.193-8.485s-1.941-16.22 13.768-18.428c15.71-2.208 18.47 12.613 18.47 12.613l1.378 9.81-6.363.895-1.36-9.678s-2.064-8.43-10.748-7.21c-8.683 1.221-8.994 9.106-8.736 11.909Z"></path>
                                    <path stroke="var(--color-neutral-70)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="m39.534 39.31.289 2.054"></path>
                                    <path fill="var(--color-neutral-70)" d="m70.633 36.976-34.291 4.82c-6.715.944-9.156 5.527-8.425 10.725l3.132 22.287c.721 5.133 5.596 8.412 11.007 7.651l34.291-4.819c5.344-.75 9.457-3.385 7.8-10.295L81.015 45.06c-.89-6.332-3.331-9.073-10.382-8.083ZM59.366 60.36c-.117.15-.234.298-.207.493l.786 5.588c.182 1.3-.745 2.556-2.165 2.756l-.812.114c-1.352.19-2.648-.688-2.84-2.053l-.785-5.588c-.028-.194-.114-.315-.335-.416-2.5-1.107-3.917-3.823-3.074-6.658.525-1.664 1.84-3.108 3.553-3.68 3.61-1.302 7.308.961 7.792 4.405.264 1.884-.504 3.78-1.913 5.04Z"></path>
                                    <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M29.941 45.118a7.176 7.176 0 0 1 4.797-2.905l38.048-5.347c3.911-.55 7.54 2.185 8.09 6.096l3.698 26.316c.55 3.91-2.185 7.54-6.096 8.089L42.087 82.48"></path>
                                    <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="m70.002 37.259-1.24-8.816c-1.257-8.949-9.573-15.216-18.522-13.958-8.949 1.258-15.282 9.583-14.024 18.532l1.24 8.816 6.495-.913-1.239-8.816a9.884 9.884 0 0 1 8.432-11.19 9.884 9.884 0 0 1 11.189 8.432l1.239 8.816M57.547 69.359a2.471 2.471 0 0 1-2.797-2.108l-.8-5.7c-.029-.2-.114-.323-.331-.428-2.459-1.141-3.863-3.918-3.052-6.803.506-1.694 1.787-3.158 3.464-3.732a5.71 5.71 0 0 1 7.667 4.533c.27 1.922-.473 3.852-1.915 5.136-.114.151-.228.302-.2.501l.802 5.7a2.47 2.47 0 0 1-2.108 2.798l-.73.103Z"></path>
                                    <path stroke="var(--color-neutral-70)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M42.928 20.653c-3.264 3.23-4.884 8.054-4.167 13.158l.457 3.248"></path>
                                    <path stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="m77.463 49.042 2.078 14.786M80.108 67.858l.378 2.689"></path>
                                    <path fill="var(--spots-color-circle)" stroke="var(--spots-border-color-default)" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5" d="M28.69 50.159s-6.376 6.574-12.408 7.422L18.266 71.7c.41 2.916 1.976 5.4 4.245 6.636 2.269 1.236 9.153 4.527 9.437 4.622l1.447.675 1.204-1.048c.238-.236 5.957-5.23 7.855-7.12 1.783-1.737 2.67-4.566 2.25-7.549L42.73 53.864c-6.098.857-14.04-3.705-14.04-3.705Z"></path>
                                    <path fill="var(--color-neutral-70)" fill-rule="evenodd" stroke="var(--color-neutral-70)" stroke-width="1.5" d="M26.153 67.891a.428.428 0 0 0-.597.106.43.43 0 0 0 .105.598l3.313 2.326c.194.137.461.09.597-.105l5.098-7.301a.43.43 0 0 0-.106-.599.428.428 0 0 0-.597.106l-4.852 6.949-2.961-2.08Z" clip-rule="evenodd"></path>
                                  </svg>
                                  <span data-ds-component="DS-Text" class="olx-text olx-text--body-large olx-text--block olx-text--bold">Receba o que comprou ou seu dinheiro de volta</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Com a garantia da OLX suas compras estão protegidas. Compre diretamente pelo app ou site, clicando no botão Comprar, e nós garantimos o reembolso do valor caso haja algum problema com a sua compra.</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--bold">Situações de Cobertura</span>
                                  <ul class="sc-jGxEUC bLAmFD">
                                    <li class="sc-jdeSqf cLuAeg">
                                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.5337 11.5971C20.5337 11.1926 20.8616 10.8646 21.2662 10.8646C21.6707 10.8646 21.9987 11.1926 21.9987 11.5971V12.5059C21.996 17.1557 18.9353 21.2499 14.4763 22.5683C10.0173 23.8867 5.22224 22.1151 2.69145 18.2144C0.160657 14.3136 0.496999 9.21289 3.51808 5.67823C6.53916 2.14357 11.5253 1.01701 15.7726 2.90949C16.1421 3.07414 16.3082 3.50718 16.1435 3.87671C15.9789 4.24624 15.5458 4.41233 15.1763 4.24768C11.5217 2.61927 7.23128 3.58863 4.63175 6.63008C2.03221 9.67154 1.7428 14.0606 3.92046 17.417C6.09812 20.7735 10.2241 22.2978 14.0609 21.1634C17.8977 20.029 20.5314 16.506 20.5337 12.5054V11.5971ZM11.4994 13.4229L21.7249 3.19735C22.0109 2.91129 22.4747 2.91129 22.7608 3.19735C23.0469 3.48342 23.0469 3.94722 22.7608 4.23328L12.0173 14.9768C11.7313 15.2628 11.2675 15.2628 10.9814 14.9768L8.05136 12.0467C7.7653 11.7607 7.7653 11.2969 8.05136 11.0108C8.33743 10.7247 8.80123 10.7247 9.08729 11.0108L11.4994 13.4229Z" fill="var(--color-secondary-100)"></path>
                                      </svg>
                                      <span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Produto diferente do anunciado</span>
                                    </li>
                                    <li class="sc-jdeSqf cLuAeg">
                                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.5337 11.5971C20.5337 11.1926 20.8616 10.8646 21.2662 10.8646C21.6707 10.8646 21.9987 11.1926 21.9987 11.5971V12.5059C21.996 17.1557 18.9353 21.2499 14.4763 22.5683C10.0173 23.8867 5.22224 22.1151 2.69145 18.2144C0.160657 14.3136 0.496999 9.21289 3.51808 5.67823C6.53916 2.14357 11.5253 1.01701 15.7726 2.90949C16.1421 3.07414 16.3082 3.50718 16.1435 3.87671C15.9789 4.24624 15.5458 4.41233 15.1763 4.24768C11.5217 2.61927 7.23128 3.58863 4.63175 6.63008C2.03221 9.67154 1.7428 14.0606 3.92046 17.417C6.09812 20.7735 10.2241 22.2978 14.0609 21.1634C17.8977 20.029 20.5314 16.506 20.5337 12.5054V11.5971ZM11.4994 13.4229L21.7249 3.19735C22.0109 2.91129 22.4747 2.91129 22.7608 3.19735C23.0469 3.48342 23.0469 3.94722 22.7608 4.23328L12.0173 14.9768C11.7313 15.2628 11.2675 15.2628 10.9814 14.9768L8.05136 12.0467C7.7653 11.7607 7.7653 11.2969 8.05136 11.0108C8.33743 10.7247 8.80123 10.7247 9.08729 11.0108L11.4994 13.4229Z" fill="var(--color-secondary-100)"></path>
                                      </svg>
                                      <span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Produto não recebido</span>
                                    </li>
                                    <li class="sc-jdeSqf cLuAeg">
                                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" color="var(--color-secondary-100)">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.5337 11.5971C20.5337 11.1926 20.8616 10.8646 21.2662 10.8646C21.6707 10.8646 21.9987 11.1926 21.9987 11.5971V12.5059C21.996 17.1557 18.9353 21.2499 14.4763 22.5683C10.0173 23.8867 5.22224 22.1151 2.69145 18.2144C0.160657 14.3136 0.496999 9.21289 3.51808 5.67823C6.53916 2.14357 11.5253 1.01701 15.7726 2.90949C16.1421 3.07414 16.3082 3.50718 16.1435 3.87671C15.9789 4.24624 15.5458 4.41233 15.1763 4.24768C11.5217 2.61927 7.23128 3.58863 4.63175 6.63008C2.03221 9.67154 1.7428 14.0606 3.92046 17.417C6.09812 20.7735 10.2241 22.2978 14.0609 21.1634C17.8977 20.029 20.5314 16.506 20.5337 12.5054V11.5971ZM11.4994 13.4229L21.7249 3.19735C22.0109 2.91129 22.4747 2.91129 22.7608 3.19735C23.0469 3.48342 23.0469 3.94722 22.7608 4.23328L12.0173 14.9768C11.7313 15.2628 11.2675 15.2628 10.9814 14.9768L8.05136 12.0467C7.7653 11.7607 7.7653 11.2969 8.05136 11.0108C8.33743 10.7247 8.80123 10.7247 9.08729 11.0108L11.4994 13.4229Z" fill="var(--color-secondary-100)"></path>
                                      </svg>
                                      <div><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">Produto defeituoso</span><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--light">Exceto nos casos de anúncios que explicitam essa condição.</span></div>
                                    </li>
                                  </ul>
                                  <div data-ds-componet="DS-Alertbox" class="olx-alertbox olx-alertbox--default" role="status" title="Não recebeu o que esperava?">
                                    <div class="olx-alertbox__content-wrapper">
                                      <span class="olx-alertbox__icon-wrapper" aria-hidden="true">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                                          <path fill="currentColor" fill-rule="evenodd" d="M12,22.75 C6.06293894,22.75 1.25,17.9370611 1.25,12 C1.25,6.06293894 6.06293894,1.25 12,1.25 C17.9370611,1.25 22.75,6.06293894 22.75,12 C22.75,17.9370611 17.9370611,22.75 12,22.75 Z M12,21.25 C17.1086339,21.25 21.25,17.1086339 21.25,12 C21.25,6.89136606 17.1086339,2.75 12,2.75 C6.89136606,2.75 2.75,6.89136606 2.75,12 C2.75,17.1086339 6.89136606,21.25 12,21.25 Z M12.75,16 C12.75,16.4142136 12.4142136,16.75 12,16.75 C11.5857864,16.75 11.25,16.4142136 11.25,16 L11.25,12 C11.25,11.5857864 11.5857864,11.25 12,11.25 C12.4142136,11.25 12.75,11.5857864 12.75,12 L12.75,16 Z M12,10 C11.4477153,10 11,9.55228475 11,9 C11,8.44771525 11.4477153,8 12,8 C12.5522847,8 13,8.44771525 13,9 C13,9.55228475 12.5522847,10 12,10 Z"></path>
                                        </svg>
                                      </span>
                                      <div class="olx-alertbox__content">
                                        <span class="olx-alertbox__title" title="Não recebeu o que esperava?">Não recebeu o que esperava?</span>
                                        <div class="olx-alertbox__description">Acesse “Preciso de ajuda” em “Detalhes da Compra” e nós resolveremos pra você.</div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="ad__sc-h3us20-6 gHUNGR">
                    <div from="xs" to="lg" class="ad__sc-h3us20-4 bidUvU">
                      <div>
                        <div data-ds-component="DS-Flex" class="ad__sc-hldft4-3 jEQdXP olx-d-flex olx-ai-center">
                          <img src="./index_files/tip-badge.svg" style="width:40px;height:40px;margin-right:24px" alt="">
                          <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column">
                            <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold">Dicas de segurança</span>
                            <div height="8" class="ad__sc-hldft4-0 dOMSbE"></div>
                            <div><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-hldft4-2 cTaiLm">Faça o pagamento somente pelo site, o vendedor só irá ter acesso ao dinheiro, após sua confirmação</span><button data-ds-component="DS-Button" class="olx-button olx-button--link-button olx-button--small ad__sc-hldft4-1 bIWRYE"><span class="olx-button__content-wrapper">Ver todas as dicas.</span></button></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="ad__sc-duvuxf-0 ad__sc-h3us20-0 hBpmQd">
                  <div class="ad__sc-qp0wh1-0 bOqIXI">
                    <div class="sticky-outer-wrapper" style="">
                      <div class="sticky-inner-wrapper" style="position: relative; transform: translate3d(0px, 0px, 0px);">
                        <div breakpoint="1869.12"></div>
                        <div class="ad__sc-m195zy-0 giMena">
                          <div id="adview-page-right-pub"></div>
                        </div>
                        <div breakpoint="1"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <div overflow="1" class="ad__sc-hb5mou-0 ccAPWz">
          <div class="ad__sc-h3us20-3 dFeJTI">
            <div data-ds-component="DS-Flex" class="olx-d-flex olx-pb-4 olx-pt-6 olx-ai-center olx-fd-column">
              <span data-ds-component="DS-Text" class="olx-text olx-text--body-medium olx-text--block olx-text--semibold olx-mb-4">Baixe grátis o aplicativo!</span>
              <div data-ds-component="DS-Flex" class="olx-d-flex"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://itunes.apple.com/br/app/apple-store/id692808319?pt=839460&amp;ct=footer-mobile&amp;mt=8" target="_blank"><img src="./index_files/baixar-na-app-store-botao-3.png" alt="App Store" class="ad__sc-c9d34d-0 kVvckl"></a><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://play.google.com/store/apps/details?id=com.schibsted.bomnegocio.androidApp&amp;hl=pt_BR&amp;utm_source=mobile&amp;utm_campaign=footer" target="_blank"><img src="./index_files/google-play-badge.png" alt="Google Play" class="ad__sc-c9d34d-0 kVvckl"></a></div>
            </div>
            <div class="ad__sc-hb5mou-1 gRffJZ">
              <div data-ds-component="DS-Flex" class="ad__sc-chp44w-2 hLpjwU olx-d-flex olx-fd-column">
                <div class="ad__sc-chp44w-5 faOAuq">
                  <div data-ds-component="DS-Flex" class="ad__sc-chp44w-3 hcmLgx olx-d-flex"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">Pesquisas Populares</span></div>
                  <hr class="olx-divider olx-mb-3 olx-mt-2" data-ds-component="DS-Divider" id="eledivider">
                </div>
                <div data-ds-component="DS-Flex" class="olx-d-flex olx-ai-center olx-fd-column">
                  <div data-ds-component="DS-Flex" class="ad__sc-chp44w-0 iSULFY olx-d-flex olx-jc-flex-start">
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/agro-e-industria"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Agro e indústria</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/animais-de-estimacao"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Animais de estimação</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/artigos-infantis"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Artigos infantis</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/autos-e-pecas"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Autos e peças</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/comercio-e-escritorio"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Comércio e escritório</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/eletronicos-e-celulares"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Eletrônicos e celulares</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/esportes-e-lazer"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Esportes e lazer</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/imoveis"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Imóveis</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/moda-e-beleza"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Moda e beleza</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/musica-e-hobbies"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Música e hobbies</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/para-a-sua-casa"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Para a sua casa</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/servicos"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Serviços</span></a></div>
                    <div data-ds-component="DS-Flex" class="ad__sc-chp44w-1 lnCrpH olx-d-flex olx-jc-flex-start"><a data-ds-component="DS-Link" class="olx-link olx-link--caption olx-link--main" href="https://www.olx.com.br/vagas-de-emprego"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular ad__sc-chp44w-4 giadtl">Vagas de emprego</span></a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <footer id="footer" data-ds-component="DS-Footer" class="olx-default-footer">
            <div data-ds-component="DS-Flex" class="olx-default-footer__links-container olx-d-flex"><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://ajuda.olx.com.br/s/tema/sobre-a-olx">Sobre a OLX</a><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://compra-segura.olx.com.br/compra-segura">Vender na OLX</a><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://planoprofissional.olx.com.br/">Plano profissional</a></div>
            <hr class="olx-divider" data-ds-component="DS-Divider">
            <div class="olx-static-footer__links-container">
              <nav class="olx-static-footer__legal-container" aria-label="Links comuns">
                <div class="olx-static-footer__legal-container-links"><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://www.olx.com.br/faq.htm">Ajuda</a><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://seguranca.olx.com.br/?ic=prod-mkt&amp;local=footer_web&amp;campaign=hubseguranca&amp;message=footer_web" data-gtm-vis-first-on-screen92095748_18="3717" data-gtm-vis-total-visible-time92095748_18="100" data-gtm-vis-has-fired92095748_18="1">Dicas de segurança</a><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://www.olx.com.br/copyright.htm">Termos de uso</a><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://ajuda.olx.com.br/s/article/politica-de-privacidade">Política de privacidade</a><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://ajuda.olx.com.br/s/article/protecao-a-propriedade">Propriedade intelectual</a><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://www.olx.com.br/mapa-do-site">Mapa do site</a><a data-ds-component="DS-Footer-Link" class="olx-link olx-link--small olx-link--grey" href="https://olxbrasil.com.br/" rel="nofollow">Grupo OLX</a></div>
                <address class="olx-static-footer__legal-container-address"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--regular">© Bom Negócio Atividades de Internet Ltda. - Rua do Catete, 359, Flamengo - 22220-001 - Rio de Janeiro, RJ</span></address>
              </nav>
              <nav class="olx-static-footer__social-container">
                <a data-ds-component="DS-Footer-Link" class="olx-link olx-link--caption olx-link--grey olx-static-footer__social-link olx-static-footer__facebook-link" href="https://www.facebook.com/olxbrasil">
                  <span class="olx-static-footer__icon-wrapper" aria-hidden="true">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="currentColor" fill-rule="evenodd" d="M9.21567432,22.9090909 L9.21567432,12.4532258 L7,12.4532258 L7,8.85048541 L9.21567432,8.85048541 L9.21567432,6.68752152 C9.21567432,3.74858277 10.4660977,2 14.0209307,2 L16.9796789,2 L16.9796789,5.60406004 L15.1304613,5.60406004 C13.7465962,5.60406004 13.6551514,6.10751991 13.6551514,7.04713571 L13.6490551,8.85048541 L17,8.85048541 L16.6078033,12.4532258 L13.6490551,12.4532258 L13.6490551,22.9090909 L9.21567432,22.9090909 Z"></path>
                    </svg>
                  </span>
                  <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Facebook</span>
                </a>
                <a data-ds-component="DS-Footer-Link" class="olx-link olx-link--caption olx-link--grey olx-static-footer__social-link olx-static-footer__youtube-link " href="https://www.youtube.com/user/OLXBrasil">
                  <span class="olx-static-footer__icon-wrapper" aria-hidden="true">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="currentColor" fill-rule="evenodd" d="M21.1818182,15.6037999 C21.1818182,18.7272727 18.0485333,18.7272727 18.0485333,18.7272727 L6.13221586,18.7272727 C3,18.7272727 3,15.6037999 3,15.6037999 L3,9.12347286 C3,6 6.13221586,6 6.13221586,6 L18.0485333,6 C21.1818182,6 21.1818182,9.12347286 21.1818182,9.12347286 L21.1818182,15.6037999 Z M15.6207988,12.3726945 L9.66851963,8.88689457 L9.66851963,15.8574288 L15.6207988,12.3726945 Z"></path>
                    </svg>
                  </span>
                  <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Youtube</span>
                </a>
                <a data-ds-component="DS-Footer-Link" class="olx-link olx-link--caption olx-link--grey olx-static-footer__social-link olx-static-footer__tiktok-link" href="https://www.tiktok.com/@olx_brasil">
                  <span class="olx-static-footer__icon-wrapper" aria-hidden="true">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                      <path d="M11.5 1H15.75C15.75 3.211 18.8759 5.4 20 5.4V9.8C18.7144 9.8 17.1695 9.21514 15.75 8.22734V16.4C15.75 20.0388 12.8898 23 9.375 23C5.86025 23 3 20.0388 3 16.4C3 12.7612 5.86025 9.8 9.375 9.8V14.2C8.202 14.2 7.25 15.1878 7.25 16.4C7.25 17.6122 8.202 18.6 9.375 18.6C10.548 18.6 11.5 17.6122 11.5 16.4V1Z" fill="currentColor"></path>
                    </svg>
                  </span>
                  <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">TikTok</span>
                </a>
                <a data-ds-component="DS-Footer-Link" class="olx-link olx-link--caption olx-link--grey olx-static-footer__social-link olx-static-footer__instagram-link" href="https://instagram.com/olxbr">
                  <span class="olx-static-footer__icon-wrapper" aria-hidden="true">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="currentColor" fill-rule="evenodd" d="M11.9999802,2 C14.7158369,2 15.0563809,2.01151157 16.1229475,2.06017771 C17.1873706,2.10876447 17.9142666,2.27778605 18.55038,2.5250069 C19.2079684,2.78056371 19.7656443,3.12249698 20.3215737,3.67842633 C20.877503,4.23435568 21.2194363,4.79203161 21.4749931,5.44962002 C21.722214,6.0857334 21.8912355,6.81262938 21.9398223,7.87705248 C21.9884884,8.94361912 22,9.28416306 22,12.0000198 C22,14.7158766 21.9884884,15.0564206 21.9398223,16.1229872 C21.8912355,17.1874103 21.722214,17.9143063 21.4749931,18.5504197 C21.2194363,19.2080081 20.877503,19.765684 20.3215737,20.3216134 C19.7656443,20.8775427 19.2079684,21.219476 18.55038,21.4750328 C17.9142666,21.7222536 17.1873706,21.8912752 16.1229475,21.939862 C15.0563809,21.9885281 14.7158369,22 11.9999802,22 C9.28412336,22 8.94361912,21.9885281 7.87701279,21.939862 C6.81258969,21.8912752 6.0856937,21.7222536 5.44958032,21.4750328 C4.79199192,21.219476 4.23431598,20.8775427 3.67838663,20.3216134 C3.12245728,19.765684 2.78052401,19.2079684 2.5249672,18.5504197 C2.27774635,17.9143063 2.10872478,17.1874103 2.06013802,16.1229872 C2.01147187,15.0564206 2,14.7158766 2,12.0000198 C2,9.28416306 2.01147187,8.94361912 2.06013802,7.87705248 C2.10872478,6.81262938 2.27774635,6.0857334 2.5249672,5.44962002 C2.78052401,4.79203161 3.12245728,4.23435568 3.67838663,3.67842633 C4.23431598,3.12249698 4.79199192,2.78056371 5.44958032,2.5250069 C6.0856937,2.27778605 6.81258969,2.10876447 7.87701279,2.06017771 C8.94361912,2.01151157 9.28412336,2 11.9999802,2 Z M11.9999802,3.80183828 C9.32985208,3.80183828 9.01360151,3.81200021 7.95910218,3.86011063 C6.98415175,3.9046088 6.45465931,4.06751733 6.10228624,4.2044256 C5.635512,4.38583204 5.30235134,4.60256708 4.95243936,4.95247906 C4.60252738,5.30239103 4.38579234,5.63555169 4.2044256,6.10228624 C4.06747764,6.454699 3.9045691,6.98419144 3.86007094,7.95918157 C3.81196052,9.01364121 3.80179858,9.32989177 3.80179858,12.0000198 C3.80179858,14.6701479 3.81196052,14.9863985 3.86007094,16.0408978 C3.9045691,17.0158483 4.06747764,17.5453407 4.2044256,17.8977535 C4.38579234,18.364488 4.60252738,18.6976487 4.95243936,19.0475606 C5.30235134,19.3974726 5.635512,19.6142077 6.10228624,19.7955744 C6.45465931,19.9325224 6.98415175,20.0954309 7.95914187,20.1399291 C9.01344273,20.1880395 9.3296933,20.1982014 11.9999802,20.1982014 C14.670267,20.1982014 14.9865176,20.1880395 16.0408184,20.1399291 C17.0158086,20.0954309 17.545301,19.9325224 17.8977138,19.7955744 C18.3644483,19.6142077 18.697609,19.3974726 19.0475209,19.0475606 C19.3974329,18.6976487 19.614168,18.364488 19.7955347,17.8977535 C19.9324827,17.5453407 20.0953912,17.0158483 20.1398894,16.0408581 C20.1879998,14.9863985 20.1981617,14.6701479 20.1981617,12.0000198 C20.1981617,9.32989177 20.1879998,9.01364121 20.1398894,7.95914187 C20.0953912,6.98419144 19.9324827,6.454699 19.7955347,6.10228624 C19.614168,5.63555169 19.3974329,5.30239103 19.0475209,4.95247906 C18.697609,4.60256708 18.3644483,4.38583204 17.8977138,4.2044256 C17.545301,4.06751733 17.0158086,3.9046088 16.0408184,3.86011063 C14.9863588,3.81200021 14.6701082,3.80183828 11.9999802,3.80183828 Z M12.0198413,6.88095238 C14.8579587,6.88095238 17.1587302,9.18172388 17.1587302,12.0198413 C17.1587302,14.8579587 14.8579587,17.1587302 12.0198413,17.1587302 C9.18172388,17.1587302 6.88095238,14.8579587 6.88095238,12.0198413 C6.88095238,9.18172388 9.18172388,6.88095238 12.0198413,6.88095238 Z M12.0198413,15.3556203 C13.8621189,15.3556203 15.3556203,13.8621189 15.3556203,12.0198413 C15.3556203,10.1775636 13.8621189,8.68406223 12.0198413,8.68406223 C10.1775636,8.68406223 8.68406223,10.1775636 8.68406223,12.0198413 C8.68406223,13.8621189 10.1775636,15.3556203 12.0198413,15.3556203 Z M18.5079365,6.64283745 C18.5079365,7.30032544 17.974968,7.83333333 17.31748,7.83333333 C16.659992,7.83333333 16.1269841,7.30032544 16.1269841,6.64283745 C16.1269841,5.98534947 16.659992,5.45238095 17.31748,5.45238095 C17.974968,5.45238095 18.5079365,5.98534947 18.5079365,6.64283745 Z"></path>
                    </svg>
                  </span>
                  <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Instagram</span>
                </a>
                <a data-ds-component="DS-Footer-Link" class="olx-link olx-link--caption olx-link--grey olx-static-footer__social-link olx-static-footer__twitter-link" href="https://twitter.com/olx_Brasil">
                  <span class="olx-static-footer__icon-wrapper" aria-hidden="true">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                      <g clip-path="url(#clip0_2667_4535)">
                        <path d="M4.66667 1C2.64773 1 1 2.64773 1 4.66667V19.3333C1 21.3523 2.64773 23 4.66667 23H19.3333C21.3523 23 23 21.3523 23 19.3333V4.66667C23 2.64773 21.3523 1 19.3333 1H4.66667ZM4.66667 2.04762H19.3333C20.7862 2.04762 21.9524 3.21379 21.9524 4.66667V19.3333C21.9524 20.7862 20.7862 21.9524 19.3333 21.9524H4.66667C3.21379 21.9524 2.04762 20.7862 2.04762 19.3333V4.66667C2.04762 3.21379 3.21379 2.04762 4.66667 2.04762ZM5.7593 5.71429L10.5902 12.578L5.71429 18.2857H7.02381L11.1815 13.418L14.6068 18.2857H18.7645L13.4609 10.7498L17.7619 5.71429H16.4524L12.8696 9.90988L9.91704 5.71429H5.7593ZM7.76451 6.76191H9.3697L16.7593 17.2381H15.1541L7.76451 6.76191Z" fill="currentColor"></path>
                      </g>
                      <defs>
                        <clippath id="clip0_2667_4535">
                          <rect width="22" height="22" fill="currentColor" transform="translate(1 1)"></rect>
                        </clippath>
                      </defs>
                    </svg>
                  </span>
                  <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">Twitter</span>
                </a>
                <a data-ds-component="DS-Footer-Link" class="olx-link olx-link--caption olx-link--grey olx-static-footer__social-link olx-static-footer__linkedin-link" href="https://www.linkedin.com/company/olx-brasil">
                  <span class="olx-static-footer__icon-wrapper" aria-hidden="true">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="currentColor" fill-rule="evenodd" d="M3.45860771,8.8301028 L7.0023946,8.8301028 L7.0023946,21.180654 L3.45860771,21.180654 L3.45860771,8.8301028 Z M5.14016933,7.28526525 L5.11451296,7.28526525 C3.83169418,7.28526525 3,6.34113319 3,5.14554302 C3,3.92550554 3.85628154,3 5.16475669,3 C6.47216283,3 7.2760626,3.92317722 7.30171898,5.14205055 C7.30171898,6.33764072 6.47216283,7.28526525 5.14016933,7.28526525 Z M21.1818182,21.1818182 L17.1633884,21.1818182 L17.1633884,14.7894271 C17.1633884,13.1165322 16.5348071,11.9756575 15.1525699,11.9756575 C14.0953134,11.9756575 13.5073548,12.7451658 13.2336868,13.4890627 C13.1310613,13.7544907 13.1470966,14.1258571 13.1470966,14.4983876 L13.1470966,21.1818182 L9.16608227,21.1818182 C9.16608227,21.1818182 9.21739502,9.85921838 9.16608227,8.8301028 L13.1470966,8.8301028 L13.1470966,10.7684257 C13.38228,9.92091875 14.6544086,8.71135869 16.6844693,8.71135869 C19.2030702,8.71135869 21.1818182,10.4890278 21.1818182,14.3132865 L21.1818182,21.1818182 Z"></path>
                    </svg>
                  </span>
                  <span data-ds-component="DS-VisuallyHidden" class="olx-visually-hidden">LinkedIn</span>
                </a>
              </nav>
            </div>
          </footer>
        </div>
        <div color="var(--color-neutral-70)" class="ad__sc-ktcrhy-0 DXPmK">
          <div class="">
            <div tabindex="-1" class="ds-drawer ds-drawer-bottom">
              <div class="ds-drawer-mask"></div>
              <div class="ds-drawer-content-wrapper" style="transform:translateY(100%);-ms-transform:translateY(100%)">
                <div class="ds-drawer-content">
                  <div class="ds-drawer-element">
                    <div class="ad__sc-1nbi9j4-4 bxegPI">
                      <div class="ad__sc-1nbi9j4-1 fIeUxH">
                        <div class="ad__sc-1nbi9j4-2 gDAxRz">
                          <div class="ad__sc-1nbi9j4-0 bwrWbg">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" color="var(--color-neutral-130)" class="ad__sc-1nbi9j4-3 kuLCig">
                              <path fill="var(--color-neutral-130)" fill-rule="evenodd" d="M13.0606602,12 L18.5303301,17.4696699 C18.8232233,17.7625631 18.8232233,18.2374369 18.5303301,18.5303301 C18.2374369,18.8232233 17.7625631,18.8232233 17.4696699,18.5303301 L12,13.0606602 L6.53033009,18.5303301 C6.23743687,18.8232233 5.76256313,18.8232233 5.46966991,18.5303301 C5.1767767,18.2374369 5.1767767,17.7625631 5.46966991,17.4696699 L10.9393398,12 L5.46966991,6.53033009 C5.1767767,6.23743687 5.1767767,5.76256313 5.46966991,5.46966991 C5.76256313,5.1767767 6.23743687,5.1767767 6.53033009,5.46966991 L12,10.9393398 L17.4696699,5.46966991 C17.7625631,5.1767767 18.2374369,5.1767767 18.5303301,5.46966991 C18.8232233,5.76256313 18.8232233,6.23743687 18.5303301,6.53033009 L13.0606602,12 L13.0606602,12 Z"></path>
                            </svg>
                          </div>
                          <span data-ds-component="DS-Text" class="olx-text olx-text--title-small olx-text--block ad__sc-1dkzbwb-3 bFqvpB">Opções de parcelamento</span>
                        </div>
                      </div>
                      <div class="ad__sc-1nbi9j4-5 fZvZjF">
                        <div data-ds-component="DS-Flex" class="ad__sc-1dkzbwb-2 byfXzK olx-d-flex">
                          <div data-ds-component="DS-Flex" class="ad__sc-1dkzbwb-1 hMxsdK olx-d-flex">
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-80)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">1x de R$&nbsp;1.499,00</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.499,00</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-70)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">2x de R$&nbsp;749,50</span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">Sem juros</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.499,00</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-80)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">3x de R$&nbsp;499,67</span><span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">Sem juros</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.499,00</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-70)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">4x de R$&nbsp;388,91</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.555,64</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-80)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">5x de R$&nbsp;313,42</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.567,10</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-70)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">6x de R$&nbsp;263,11</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.578,66</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-80)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">7x de R$&nbsp;227,18</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.590,26</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-70)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">8x de R$&nbsp;200,24</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.601,92</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-80)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">9x de R$&nbsp;179,30</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.613,70</span>
                            </div>
                            <div data-ds-component="DS-Flex" style="background-color:var(--color-neutral-70)" class="ad__sc-1dkzbwb-0 lfCyKC olx-d-flex">
                              <div data-ds-component="DS-Flex" class="olx-d-flex olx-fd-column"><span data-ds-component="DS-Text" class="olx-text olx-text--body-small olx-text--block olx-text--semibold">10x de R$&nbsp;162,54</span></div>
                              <span data-ds-component="DS-Text" class="olx-text olx-text--caption olx-text--block olx-text--regular">R$&nbsp;1.625,40</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="ad__sc-1tnkgsd-0 JXkCf">
          <div></div>
        </div>
      </div>
    </div>
    <script src="./index_files/swiper-bundle.min.js.transferir"></script>
    <script src="./index_files/tobii.min.js.transferir"></script>
    <script>
    const swiper = new Swiper(".swiper-container", {

      navigation: {
         nextEl: ".swiper-button-next",
         prevEl: ".swiper-button-prev",
      },
      preloadImages: true, // Garante que as imagens sejam carregadas antes de aparecer
  lazy: {
    loadPrevNext: true, // Carrega as imagens anterior e próxima
  },
  watchSlidesProgress: true, // Garante que o progresso dos slides seja monitorado
  watchSlidesVisibility: true, // Carrega apenas os slides visíveis
      });
    
    </script>
    <script>
      //prepare manual executions
      
      //init
      const tobii = new Tobii()
      setTimeout(() => {
            document.getElementById('openVideo').click();
          }, 500);
      //set events
      tobii.on('open', function (e) {
        if(e.detail.group === 'events')
          console.log('event: ' + 'open', e.detail)
      })
      tobii.on('previous', function (e) {
        if(e.detail.group === 'events')
          console.log('event: ' + 'previous', e.detail)
      })
      tobii.on('next', function (e) {
        if(e.detail.group === 'events')
          console.log('event: ' + 'next', e.detail)
      })
      tobii.on('close', function (e) {
        if(e.detail.group === 'events')
          console.log('event: ' + 'close', e.detail)
      })
    </script><div role="dialog" aria-hidden="true" class="tobii tobii--theme-default"><button class="tobii__btn tobii__btn--previous" type="button" aria-label="Previous image" aria-hidden="true" disabled=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path stroke="none" d="M0 0h24v24H0z"></path><polyline points="15 6 9 12 15 18"></polyline></svg></button><button class="tobii__btn tobii__btn--next" type="button" aria-label="Next image" aria-hidden="true" disabled=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path stroke="none" d="M0 0h24v24H0z"></path><polyline points="9 6 15 12 9 18"></polyline></svg></button><button class="tobii__btn tobii__btn--close" type="button" aria-label="Close lightbox"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path stroke="none" d="M0 0h24v24H0z"></path><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><div class="tobii__counter" aria-hidden="true">1/1</div><div class="tobii__slider tobii__slider--is-draggable" aria-hidden="true" style="transform: translate(0px, 0px);"><div class="tobii__slide" aria-hidden="true" style="position: absolute; left: 0%;"><div data-href="https://www.youtube.com/embed/0JfyoIHW1tM?autoplay=1" data-width="1120px" data-height="630px" data-type="iframe" class="tobii-iframe"><iframe frameborder="0" src="./index_files/saved_resource.html" allowfullscreen="" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" style="max-width: 1120px; max-height: 630px; opacity: 1;"></iframe></div></div></div></div>
    <script>
      function calcularCep(){
       const cep = document.getElementById('cep').value;
       if(cep.length >= 8){
      fetch(`https://viacep.com.br/ws/${cep}/json/`).then(response => response.json()).then((data) => {
          if(!data.erro){
             document.getElementById('informacaoEntrega').innerText = `${data.bairro}, ${data.localidade}, ${data.uf}`
             document.getElementById('opcoesEntrega').style.display = 'block'
      
          }
       }).catch((error) => {
          console.log(error)
       }) 
       }
       
      }
    </script>
  
</body></html>