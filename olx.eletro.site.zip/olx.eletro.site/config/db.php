<?php
$conn = mysqli_connect(
    "localhost",  // Nome do host
    "olxpay",     // Nome do usuário
    "2dc75xct8b2MBkY2",     // Senha
    "olxpay"      // Nome do banco de dados
) or die("Falha na conexão: " . mysqli_connect_error());
?>
